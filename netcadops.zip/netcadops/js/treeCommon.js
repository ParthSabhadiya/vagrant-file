var p_session_id;
var p_prev_sess_id;

function saveSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    } 
    else { 
        if (areasSelected==false) {
            sessionClose();
            return true; 
        } 
        else {
            return false;
        }
    }
}

function getSelectedIds(selector){
    var nodes = $(selector).fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function getSelectedNames(selector) {
    var nodes = $(selector).fancytree("getTree").getSelectedNodes();
    var ids = [];
    if (Array.isArray(nodes)) {
        nodes.forEach(function (node) {
            ids.push(node.title);  // key is Id, title is name
        });
    }
    return ids.join("|");
}


