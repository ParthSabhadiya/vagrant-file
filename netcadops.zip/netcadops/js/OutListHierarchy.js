function AssignOutage(mesg1,problemNo) {
    var table = $("#subarea-outage-table").DataTable();
        if (table.rows('.selected').data().length != 1)
        {
            alert(mesg1);
            return false;
        }
        var sessionId = getUrlParameter("p_session_id");
        var outageNo = table.rows('.selected').data()[0][2];
              var vURL = "OutLists.AssignOutage?p_outage_no="+outageNo+"&p_problem_no=" +problemNo  +"&p_session_id="+ sessionId;
              document.location.href = vURL;
    }
    
    
    
    