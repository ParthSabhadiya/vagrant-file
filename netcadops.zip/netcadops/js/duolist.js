	//DuoList
	//Functions to move list options back and forth between two lists

	function addOption(selectObject, val, text) {
		for (var i=0; i<selectObject.length; i++) {
			if (selectObject.options[i].value.length == 0) {
				count = i;
				break;
			}
		}
		selectObject.options[count].value = val;
		selectObject.options[count].text = text;
	}
	
	function removeOption(selectObject, val) {
		var j = 0;
		var l = selectObject.length;
		for (var i=0; i<l; i++) {
			if (selectObject.options[i].value.length == 0) break;
			if (selectObject.options[i].value != val) {
				selectObject.options[j].value = selectObject.options[i].value;
				selectObject.options[j].text = selectObject.options[i].text;
				j++;
			}
		}
		for (var i=j; i<l; i++) {
			selectObject.options[i].value = "";
			selectObject.options[i].text = "                              ";
		}
	}
	
	function moveAll(fromObject, toObject) {
		// get count in toObject
		var count;
		count = toObject.length;
		for (var i=0; i<toObject.length; i++) {
			if (toObject.options[i].value.length == 0) {
				count = i;
				break;
			}
		}	
		// insert into toObject, remove from fromObject;
		for (var i=0; i<fromObject.length; i++) {
			if (fromObject.options[i].value.length > 0) {
				toObject.options[count].value = fromObject.options[i].value;
				toObject.options[count].text = fromObject.options[i].text;
				fromObject.options[i].value = "";
				fromObject.options[i].text = "                              ";
				count++;
			}
		}
	
		// no items selected
		fromObject.selectedIndex = -1;
	}
	
	function moveOne(fromObject, toObject) {
		if (fromObject.selectedIndex > -1) {
			// insert new item
			var val = fromObject.options[fromObject.selectedIndex].value;
			var text = fromObject.options[fromObject.selectedIndex].text;
			addOption(toObject, val, text);
	
			//	remove moved item
			removeOption(fromObject, val);
	
			// no items selected
			fromObject.selectedIndex = -1;
		}
	}
	
	function enlarge(fromObject, toObject) {
	//remove the dummy line inserted in order to enlarge the width of the list (Netscape!)
		eval(fromObject + ".options[" + fromObject + ".length - 1].text='                              ';"); 
		eval(toObject + ".options[" + toObject + ".length - 1].text='                              ';");
	}
