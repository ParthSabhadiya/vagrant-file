// Notifications List  : CSR:notifications

// Function to set call method for selected customers
function setMethod(form, button, trans_11, trans_215, trans_216, trans_217, trans_555, v_meth_m, v_meth_a)
{
    var vURL = "", param = "", v_acct_no = "", v_plout_no = ""; 
	var table = $("#trrpts-table").DataTable();
	if (table.rows('.selected').data().length == 0)
	{
        // trans_215 txt_trans_tbl(215) = 'Please select a customer or customers from the list.' 
		alert(trans_215);
		return false;
	}

	if (table.rows('.selected').data().length>1) 
	{
		alert(trans_215);
		return false;
	}
	for (var i=0; i<table.rows('.selected').data().length; i++) 
	{
		v_plout_no = table.rows('.selected').data()[i][1]; // job no in column 1
		v_acct_no = table.rows('.selected').data()[i][12];
        param = param + v_plout_no + "|" + v_acct_no + "|";   // get plout_no and acct_no string
	}

	var sessionId = getUrlParameter("p_session_id");

    // 06 / 10 / 02 JH: Internationalization 
    // txt_trans_tbl(555) = 'Please enter M for manual or A for automatic.'      
    message = trans_555;
    var v_method = prompt(message, "") + "";  
    v_method = v_method.toUpperCase();  

    if (v_method == "NULL") { 
        // 06 / 10 / 02 JH: Internationalization 
        // txt_trans_tbl(216) = 'Set Call Method for Selected Customers'      
        button.value = trans_216;  
        return;  
    } 
	else if (v_method !== v_meth_m && v_method !== v_meth_a)  {
        // 08 / 22 / 02 EK Translate values entered by user
        // else if (v_method != "M"   jsand || ' v_method != "A")  
        // 06 / 10 / 02 JH: Internationalization 
        // txt_trans_tbl(217) = 'Please enter M for manual or A for automatic and try again.'      
        // txt_trans_tbl(216) = 'Set Call Method for Selected Customers'      
        alert(trans_217);  
        button.value = trans_216;  
        return;
    }

	/*
    var ridAsString, ridArr = new Array(), customerAsString, customerArr = new Array(); 
    ridAsString = document.gridapplet.getSelectedID();  // get row id string
    ridAsString = ridAsString + "";  

    // 06 / 10 / 02 JH: Internationalization 
    // txt_trans_tbl(11) = 'Working...' 
    button.value = trans_11;
    if (ridAsString.length === 0) {
        // 06 / 10 / 02 JH: Internationalization 
        // txt_trans_tbl(215) = 'Please select a customer or customers from the list.' 
        // txt_trans_tbl(216) = 'Set Call Method for Selected Customers' 
        alert(trans_215);
        button.value = trans_216;  
        return;
   }

    ridAsString = ridAsString.substring(0, ridAsString.lastIndexOf("|")); 
    ridAsString = ridAsString+""; 
    ridArr = ridAsString.split("|");  // get row id array

    for (var i = 0; i < ridArr.length; i++)  { // js loop through selected rows
        customerAsString = document.gridapplet.getRow(ridArr[i]);  // get customer string
        customerAsString = customerAsString + "";  
        customerAsString = customerAsString.substring(0, customerAsString.lastIndexOf("|")); 
        customerAsString = customerAsString + "";  
        customerArr = customerAsString.split("|");   // get customer array
        v_plout_no = customerArr[0];   // get plout_no
        v_acct_no = customerArr[11];   // get acct_no
        param = param + v_plout_no + "|" + v_acct_no + "|";   // get plout_no and acct_no string
    }
	*/

    vURL = "netcPlanned.ApplyMethod?p_session_id="+ sessionId + "&p_par=" + escape(param) + "&p_method=" + v_method;
    callURL(form, "butSetMethod", vURL, trans_11);
    //popWin(vURL, "netCADOPSpop", 600, 300);
    //popWin(vURL);
    //popWinBackground(vURL);
}
