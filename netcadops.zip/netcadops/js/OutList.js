
var areasSelected = false
var v_PrevSessID = null;
var p_session_id;
var p_prev_sess_id;

function setSessionIds( sessionId, prevSessionId){
    p_session_id =  sessionId;
    v_PrevSessID = prevSessionId;
}

function getSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getUrlParameter("p_session_id");
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    } 
    else { 
        if (areasSelected==false) {
            sessionClose();
            return true; 
        } 
        else {
            return false;
        }
    }
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all){
    getSessionIds();

    areasSelected = true;

    var listIDs = "";
    if ( all == 0 ){
       listIDs = getSelectedIds();
       console.log(listIDs);
       if ( listIDs == ""){
           alert( "'" + txt_trans(908) + "'");
           return;
       }
    }
    else  {
        listIDs = "||";
    }

    console.log( "listIDs is " + listIDs);

    if ( top.hiddenFrame){
        var vURL = "NetcMenu.UpdateUserDistricts?p_districts=" + listIDs + '&p_session_id=' + p_session_id;
        var baseframeURL = "NetcMenu.WhoAmI?p_session_id=" + p_session_id ;
        var treeframeURL = "NetcMenu.MenuGen?p_session_id=" + p_session_id;
        top.treeframe.location.href=treeframeURL;
        top.hiddenframe.location.href=vURL;
        top.baseframe.location.href=baseframeURL;
    }
    else {
        var vURL = "NetcMenu.SetUser?p_districts=" + listIDs 
        + "&p_session_id=" + p_session_id 
        + "&p_prev_sess_id=" + p_prev_sess_id
        + "&p_timezone=" + encodeURIComponent(jstz.determine().name());

        document.location.href=vURL;
    }
}

function getSelectedIds(){
    var nodes = $("#outtree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all){
    getSessionIds();

    areasSelected = true;

    var listIDs = "";
    if ( all == 0 ){
       listIDs = getSelectedIds();
       console.log(listIDs);
       if ( listIDs == ""){
           alert( "'" + txt_trans(908) + "'");
           return;
       }
    }
    else  {
        listIDs = "||";
    }

    console.log( "listIDs is " + listIDs);

    if ( top.hiddenFrame){
        var vURL = "NetcMenu.UpdateUserDistricts?p_districts=" + listIDs + '&p_session_id=' + p_session_id;
        var baseframeURL = "NetcMenu.WhoAmI?p_session_id=" + p_session_id ;
        var treeframeURL = "NetcMenu.MenuGen?p_session_id=" + p_session_id;
        top.treeframe.location.href=treeframeURL;
        top.hiddenframe.location.href=vURL;
        top.baseframe.location.href=baseframeURL;
    }
    else {
        var vURL = "NetcMenu.SetUser?p_districts=" + listIDs 
            + "&p_session_id=" + p_session_id 
            + "&p_prev_sess_id=" +p_prev_sess_id
            + "&p_timezone=" + encodeURIComponent(jstz.determine().name());
        document.location.href=vURL;
    }
}

function parseNodeOnfo(nodeStr){
    var nodesInfo = nodeStr.split("|");
    var noOfNodes = nodesInfo.length/3;

    var currentParentByLevel = {};
    var data = [];
    for ( var i = 0; i < noOfNodes; i++){
        var level = nodesInfo[3*i];
        var intLevel = parseInt(level.substring(1));
        var id = nodesInfo[3*i+1];
        var name = nodesInfo[3*i+2];
        var node = {
            title: name,
            key: id,
            level: level,
            children: [],
        };
        if ( intLevel <= 2) node.expanded = true;
        currentParentByLevel[intLevel] = node;
        if ( intLevel == 1 ){
            data.push(node);
            node.folder = true;
            //node.icon = "/images/folder.png";
        }
        else {
            var currentParent = currentParentByLevel[intLevel-1];
            if (currentParent){
                currentParent.children.push(node);
                currentParent.folder = true;
                //currentParent.icon = "images/folder.png";
            }
        }
    }
    return data;
}


$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseNodeOnfo( $('param').attr('value') );
    $("#outtree").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});
