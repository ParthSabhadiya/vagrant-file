//           +-----------------------------------------------+
//           |                                               |
//           |               COPYRIGHT (c) 1990-2019         |
//           |                                               |
//           |       ABB Network Management SYSTEMS          |
//           |                                               |
//           |               All rights reserved             |
//           |                                               |
//           +-----------------------------------------------+
//  Java script file for project of replacing java applets with jqeury
//  MODIFICATION HISTORY
//  000     26-Aug-2019  Ind/AS    Initial version
//  001     27-Aug-2019  AV        B-168141 DMS 9.1.0.X_Ora122Java11 Netcadops Applet replacement with jquery
// -----------------------------------------------------------------------------

function isBlank(s) {
	// returns true if string is empty or undefined or null
	// In javascript null values and empty strings equals to false (i.e. null == false)
	return( (s === undefined) || (s === null) || (s.length === 0) || (s.trim().length === 0) )
}

// returns a map of string=>list of strings by selecting some PARAM elements in the document. The PARAM elements selected for this map
// must have the name attribute value start with namePrefix.
function getParamsWithPrefix(namePrefix){
    var result = {};
    var selector = "PARAM[NAME^=" + namePrefix + "]";
    $(selector).each(function(){
        var name = $(this).attr("NAME");
        var value = $(this).attr("value");
        var values = value.split("|");
        result[name] = values;
    });
    return result;
}

function getUrlPrefix(){
    return $("PARAM[name=urlprefix]").attr("value");
}

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

function getSessionId(){
    return getUrlParameter("p_session_id");
}

function parseTreeNodeInfo(nodeStr) {
	if (nodeStr === undefined || nodeStr == null)
		nodeStr = "";
    // If input begins with pipe symb  | then discard it
    nodeStr = (nodeStr && nodeStr.length > 0 && nodeStr[0] == '|') ? nodeStr.slice(1) : nodeStr;

    var nodesInfo = nodeStr.split("|");
    var noOfNodes = nodesInfo.length/3;

    var currentParentByLevel = {};
    var data = [];
    for ( var i = 0; i < noOfNodes; i++){
        var level = nodesInfo[3*i];
        var intLevel = parseInt(level.substring(1));
        var id = nodesInfo[3*i+1];
        var name = nodesInfo[3*i+2];
        var node = {
            title: name,
            key: id,
            level: level,
            children: [],
        };
        if ( intLevel <= 2) node.expanded = true;
        currentParentByLevel[intLevel] = node;
        if ( intLevel == 1 ){
            data.push(node);
            node.folder = true;
        }
        else {
            var currentParent = currentParentByLevel[intLevel-1];
            if (currentParent){
                currentParent.children.push(node);
                currentParent.folder = true;
            }
        }
    }
    return data;
}


//--06 / 15 / 03 EK  Function to call group / ungroup procedure in package netcGrouping
//--Same function in outLstHierarchy.js and in outageHistory.js (netchist.pkb)
// Used in both Area Outages and Outage History screens
function groupOutage(vAction) {
	var trans798 = $("#trans798").attr("value");
	var trans797 = $("#trans797").attr("value");
	var trans808 = $("#trans808").attr("value");
	var trans801 = $("#trans801").attr("value");
	var trans809 = $("#trans809").attr("value");
	var trans802 = $("#trans802").attr("value");
	var tblname  = "#" + $("#tblname").attr("value");

    var vList = ""; var vMasterNo = ""; var vMasterFound = 0; var vMasterIncluded = 0;
    var vOutIndx = " v_OutageOrder ";
    var vMasterOutIndx = " v_MasterOutageOrder ";

    //var table = $("#subarea-outage-table").DataTable();
    var table = $(tblname).DataTable();
    if (table.rows('.selected').data().length < 1) {
        alert('Please select a outage');
        return false; // No outages selected for grouping / ungrouping
    }
    if (table.rows('.selected').data().length < 2 && vAction === "G") {
        alert(trans798); // Please select more than one outage for grouping
        return false; // No outages selected for grouping / ungrouping
    }
    var sessionId = getUrlParameter("p_session_id");

    for (var ii = 0; ii < table.rows('.selected').data().length; ii++) {
        var outageNo = table.rows('.selected').data()[ii][2];
        if (outageNo === "" || parseInt(outageNo) < 1 || isNaN(parseInt(outageNo)) ) {
            alert(trans797); // Only outages can be grouped
            return false;
        }

		vList = vList + "|" + outageNo;

        var masteroutageNo = table.rows('.selected').data()[ii][3];
        if (masteroutageNo != "") {
            if (masteroutageNo === outageNo)
                vMasterIncluded = 1;

            if (vMasterFound == 0) {
                vMasterNo = masteroutageNo;
                vMasterFound = 1;
            } else {
                if (masteroutageNo != vMasterNo) {
                    alert(trans808); // Only one master outage may be included
                    return false;
                }
            }
        }
        if (vAction == "U" && masteroutageNo === "") {
            alert(trans802 + outageNo); // Selected outage does not belong to a group
            return false;
        }
    }

    // confirmation to destroy the group
    if (vMasterNo != "" && vAction === "U" && vMasterIncluded === 1) {
        var conf_msg = trans801 + vMasterNo + " ?";  // Do you want to destroy the group for master

        if (!confirm(conf_msg))
            return false;
    }

    if (vAction === "G")
        var vURL = "netcGrouping.GroupOutages?p_session_id=" + sessionId + "&p_list=" + vList + "&p_master_outage_no=" + vMasterNo;
    else
        var vURL = "netcGrouping.UnGroupOutages?p_session_id=" + sessionId + "&p_list="
            + vList + "&p_master_outage_no=" + vMasterNo + "&p_err_msg=" + escape(trans809);

    popWin(vURL, "netCADOPSpop", 850, 600, "Y", 10, 10, "menubar=0,scrollbars=1,titlebar=1,resizable=1");
}
