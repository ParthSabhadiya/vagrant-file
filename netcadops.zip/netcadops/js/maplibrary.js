//Library of client-side map functions and event-handling

function getLayers(mapref) {
    return mapref.getMapLayersEx();
}

/*function doGetKey() {
    var map = getMap();
    if (map.getSelection().getNumObjects() == 0) {
        alert("Make selection first");
        return;
    }
    var sel = map.getSelection();
    var objs = sel.getMapObjectsEx(null);
    var cntObjects = objs.size();
    var msg = "Keys of selected features are:\n";
    var i;
    for (i=0; i < cntObjects; i++) {
        var obj = objs.item(i);
        var key = objs.getKey();
        msg = msg + obj.getMapLayer().getName() + " " + key + "\n";
    }
    alert(msg);
}

function doGetCoordinates(layerName) {
    var map = getMap();
    if (map.getSelection().getNumObjects() == 0) {
        alert("Make selection first");
        return;
    }
    var sel = map.getSelection();
    var layer = sel.getMapLayer(layerName);
    if (layer == null) {
        alert("No <"+layerName+ "> layer found on this map!");
        return;
    }
    if ( (sel.getNumObjects() > 1) || (sel.getNumObjects() == 0) || (sel.getMapObjectsEx(layer).size() == 0) )
    {
        alert("Select only one object");
        return;
    }
    var obj = sel.getMapObjectsEx(layer).item(0);
    var vertices = map.createObject("MGCollection");
    var cntVertices = map.createObject("MGCollection");
    var res = obj.getVertices(vertices, cntVertices);
    if (res == 0) {
        alert("No access to coordinate information");
        return;
    }
    msg = "Object:" + obj.getKey() + "\n";
    msg = msg + "Coordinates in MCS unit\n";
    for (var i = 0; i < cntVertices.item(0); i++)
    {
        var pnt = vertices.item(i);
        msg = msg + pnt.getX() + "," + pnt.getY() + "\n";
    }
    alert(msg);
}
*/

function zoomAndHighlight(map, layer, object) {
    var mapSel = map.getSelection();
    var mapLayer = map.getMapLayer(layer);
    var mapObjects = map.createObject("MGCollection");
    var mapObj = mapLayer.getMapObject(object);
    if (mapObjects != null) {
        mapObjects.add(mapObj);
    }
    mapSel.clear();
    if (mapObjects.size() > 0) {
        mapSel.addObjectsEx(mapObjects, false);
    }
}

//TIMER for autoRefresh
var timerID;
var timerRunning = false;
var timerInterval = 10000;
var targetFrame = null;
var mapPointer = null;
var netcSessionId = null;
//Initialize Map Components
function initMap(mapRef, redirTarget, sessionId)
{
    registerObservers(mapRef);
    targetFrame = redirTarget;
    mapPointer = mapRef;
    netcSessionId = sessionId; 
    //alert("Target frame set to <"+targetFrame.location.href+">");
    //mapRef.setIntermediateUpdatesEnabled(true);
}

//Generic EVENT HANDLER Implementations
function registerObservers(mapRef) {
    if (navigator.appName == "Microsoft Internet Explorer")
    {
        //alert("Internet Explorer is being used.\n Registering observers...");
        initVB(mapRef);
    }
}


function enableAutomaticUpdate(interval)
{
    timerInterval = interval;
    autoRefreshOn();
}

function disableAutomaticUpdate()
{
    autoRefreshOff();
}

//Timer for dynamic map updating
function autoRefreshOn()
{
	timerID = setTimeout("throwTimeOut()", timerInterval);
	timerRunning = true;
}

function autoRefreshOff()
{
	if (timerRunning)
	{
		clearTimeout(timerID);
		timerRunning = false;
	}
}

function throwTimeOut()
{
	autoRefreshOff();
        mapPointer.refresh();
	autoRefreshOn();
}

function setDynamicLayerRebuildFlags(map)
{
    var msg = "";
    var layers = getLayers(map);
    for (var i=0; i<layers.size(); i++)
    {
        msg = msg + layers.item(i).getName() + "\n";
        switch (layers.item(i).getName()) {
            case "Outage" :
                layers.item(i).setRebuild(true);
                msg = msg + " <"+layers.item(i).getRebuild() + "> \n";
                break;
            case "Crew" :
                layers.item(i).setRebuild(true);
                msg = msg + " <"+layers.item(i).getRebuild() + "> \n";
                break;
            case "Non Customer Call" :
                layers.item(i).setRebuild(true);
                msg = msg + " <"+layers.item(i).getRebuild() + "> \n";
                break;
            case "Grid" :
                layers.item(i).setRebuild(true);
                msg = msg + " <"+layers.item(i).getRebuild() + "> \n";
                break;
            default :
                msg = msg + " <"+layers.item(i).getRebuild() + "> \n";
                break;
        }
    }
    //alert(msg);
    return;
}

function getLayerRebuildFlags(map)
{
    var msg = "";
    var layers = getLayers(map);
    for (var i=0; i<layers.size(); i++)
    {
        msg = msg + layers.item(i).getName() + " Flag <"+layers.item(i).getRebuild() + "> \n";
        switch (layers.item(i).getName()) {
            case "Outage" :
                layers.item(i).setRebuild(true);
                break;
            case "Crew" :
                layers.item(i).setRebuild(true);
                break;
            case "Non Customer Call" :
                layers.item(i).setRebuild(true);
                break;
            case "Grid" :
                layers.item(i).setRebuild(true);
                break;
            default :
                layers.item(i).setRebuild(false);
                break;
        }
    }
    return msg;
}

function initVB(mapRef)
{
    ver = parseFloat(mapRef.getApiVersion());
    if (ver >= 1.2)
    {
        document.write('<SCRIPT LANGUAGE="VBScript">\n');

        document.write('Sub map_onSelectionChanged(map)\n');
        document.write('    onSelectionChanged map\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDoubleClickObject(mapObj)\n');
        document.write('    mapObj.DoubleClickHandled = onDoubleClickObject(mapObj)\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDigitizedPoint(map, point)\n');
        document.write('    onDigitizedPoint map, point\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDigitizedPolygon(map, numPoints, points)\n');
        document.write('    onDigitizedPolygon map, numPoints, points\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDigitizedPolyline(map, numPoints, points)\n');
        document.write('    onDigitizedPolyline map, numPoints, points\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDigitizedCircle(map, units, center, radius)\n');
        document.write('    onDigitizedCircle map, units, center, radius\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onAddMapLayer(url, mapLayer)\n');
        document.write('    onAddMapLayer url, mapLayer\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onViewChanged(map)\n');
        document.write('    onViewChanged map\n');
        document.write('End Sub\n\n');
    }
    if (ver > 1.2)
    {
        document.write('Sub map_onBusyStateChanged(map, isBusy)\n');
        document.write('    onBusyStateChanged map, isBusy\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onDigitizedRectangle(map, anchorPt, endPt)\n');
        document.write('    onDigitizedRectangle map, anchorPt, endPt\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onViewChanging(map)\n');
        document.write('    onViewChanging map\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onMapLoaded(map)\n');
        document.write('    onMapLoaded map\n');
        document.write('End Sub\n\n');

        document.write('Sub map_onViewedDistance(map, totalDistance, distances, units)\n');
        document.write('    onViewedDistance map, totalDistance, distances, units\n');
        document.write('End Sub\n\n');
    }

    if (ver >= 1.2)
    {
        document.write('<\/SCRIPT>\n');
    }
}

// The following JavaScript functions process events from both the ActiveX Control
// Control and the Plug-In. The ActiveX Control events are forwarded to these
// functions via VBScript, and the Plug-In events are forwarded to these
// functions via the MapGuideObserver Java applet.

function onSelectionChanged(map)
{
    return;
    //alert("onSelectionChanged");
}

function onDoubleClickObject(mapObj)
{
    //alert("onDoubleClickObject => KEY <"+mapObj.getKey()+"> \n Name <"+mapObj.getName()+"> \n Layer <"+mapObj.getMapLayer().getName()+">");
    if (mapObj.getMapLayer().getName() == "Outage") {
        targetFrame.location.href = "NETCMAPS.Detail?p_session_id="+netcSessionId+"&p_obj_type=O&p_obj_id="+mapObj.getKey();
    } else if (mapObj.getMapLayer().getName() == "Crew") {
        targetFrame.location.href = "NETCMAPS.Detail?p_session_id="+netcSessionId+"&p_obj_type=C&p_obj_id="+mapObj.getKey();
    } else if (mapObj.getMapLayer().getName() == "Non Customer Call") {
        targetFrame.location.href = "NETCMAPS.Detail?p_session_id="+netcSessionId+"&p_obj_type=N&p_obj_id="+mapObj.getKey();
    } else if (mapObj.getMapLayer().getName() == "Service Call") {
        targetFrame.location.href = "NETCMAPS.Detail?p_session_id="+netcSessionId+"&p_obj_type=S&p_obj_id="+mapObj.getKey();
    } else if (mapObj.getMapLayer().getName() == "Trouble Call") {
        targetFrame.location.href = "NETCMAPS.Detail?p_session_id="+netcSessionId+"&p_obj_type=T&p_obj_id="+mapObj.getKey();
    } else {
        return;
    }
}

function onDigitizedPoint(map, point)
{
    return;
    //alert("onDigitizedPoint");
}

function onDigitizedPolygon(map, numPoints, points)
{
    return;
    //alert("onDigitizedPolygon");
}

function onDigitizedCircle(map, units, point, r)
{
    return;
    //alert("onDigitizedCircle");
}

function onDigitizedPolyline(map, numPoints, points)
{
    return;
    //alert("onDigitizedPolyline");
}

function onAddMapLayer(url, mapLayer)
{
    return;
    //alert("onAddMapLayer");
}

function onDigitizedRectangle(map, anchorPt, endPt)
{
    return;
    //alert("onDigitizedRectangle");
}

function onBusyStateChanged(map, bIsBusy)
{
    return;
    //alert("onBusyStateChanged");
}

function onViewChanged(map)
{
    autoRefreshOn();
    return;
    //alert("onViewChanged");
}

function onMapLoaded(map)
{
    //alert("onMapLoaded");
    map.setAutoRefresh(false);
    //alert("busy state? "+map.isBusy());
    setDynamicLayerRebuildFlags(map);
    enableAutomaticUpdate(60000);
    map.setAutoRefresh(true);
    return;
}

function onViewChanging(map)
{
    //alert("onViewChanging");
    autoRefreshOff();
    setDynamicLayerRebuildFlags(map);
    //alert(getLayerRebuildFlags(map));
    return;
}

function onViewedDistance(map, totalDistance, distances, units)
{
    return;
    //alert("onViewedDistance");
}

