// Crew specific Javascript functions

// applyCrew() to Assign Selected Crews or to List Selected Crew Activity
function applyCrew(action, trans646, trans864) {
    var sessionId = getUrlParameter("p_session_id");

    var table = $("#stormcrew-table").DataTable();
    var sel_obj = table.rows('.selected').data();
    if (sel_obj === undefined || sel_obj.length < 1) {
     	//txt_trans_tbl(646) = Please select a Crew from the list.
        alert(trans646);
        return false;
    }

	var list = "";
	for (var ii = 0; ii < sel_obj.length; ii++) {
    	crewid = sel_obj[ii][1];  // second column
     	list += crewid + "|";
	}

/*
	var list="", ridAsString, ridArr=new Array(), crewAsString, crewid;
    ridAsString = document.gridapplet.getSelectedID(); 
    ridAsString = ridAsString + "";
    ridAsString = ridAsString.substring(0, ridAsString.lastIndexOf("|")); 
    ridAsString = ridAsString+""; 
    ridArr = ridAsString.split("|"); 

    for (var i = 0; i < ridArr.length; i++) {
		crewAsString = document.gridapplet.getRow(ridArr[i]);
		//crewid = crewAsString.substring(crewAsString.indexOf("|")+1, crewAsString.indexOf("|", crewAsString.indexOf("|")+1)); 
    	crewid = crewAsString.substring(crewAsString.indexOf("|"), 0, crewAsString.indexOf("|")); // --10 / 04 / 02 EK Switched two columns
     	list = list + crewid + "|";
	}
	*/
	list = list.substring(0, list.lastIndexOf("|"));  // for using LibPL.StringToArray

	if (action === "A") {  
		var v_hidStatus = $("#hidStatus").attr("value");
		// Assign Selected Crews
		if (v_hidStatus === "") { 
			alert(trans864); // Please select the crew status.
		   	return false;
		}

		var v_p_ass_no = $("#p_ass_no").attr("value");
		var v_p_ass_class = $("#p_ass_class").attr("value");
		var vURL = "StormCrew.CrewDispatchFooter?p_session_id=" + sessionId + "&p_list=" + escape(list) 
			+ "&p_ass_no=" + v_p_ass_no + "&p_ass_class=" 
			+ v_p_ass_class + "&p_status=" + v_hidStatus; // 11 / 25 / 03 EK  Get selected status

		vURL = stringReplace(vURL, " ", "%20");
	} else {
		// Crew Activity
		var vURL = "StormCrew.CrewActUpdate?p_session_id=" + sessionId + "&p_list=" + escape(list);
	}

	document.location.href = vURL;
}

// 02 / 20 / 03 SQL * : Crew Log Report(getRows function is in the js / applet.js)
function getCrewLog(trans907) 
{
    var table = $("#stormcrew-table").DataTable();
    var sel_obj = table.rows('.selected').data();
    if (sel_obj === undefined || sel_obj.length != 1) {
		// trans907 = Please select one row
        alert(trans907);
        return false;
    }

    var crewid = ""; 
	for (var ii = 0; ii < sel_obj.length; ii++) {
    	crewid = sel_obj[ii][1];  // second column
	}

    if (crewid === "")
		return false;

    var sessionId = getUrlParameter("p_session_id");

    var vURL = "netccrewlog.ViewLog?p_session_id=" + sessionId + "&p_crew_id=" + escape(crewid);
    popWin(vURL,"netCADOPSPop", 1000, 600, "Y", 10, 10, "toolbar=no,location=no,directories=no,status=no,menubar=no" ); 
}

// --02 / 08 / 04 EK  Added function to open the customized lists prefs pop - up
function showPref() 
{
    var sessionId = getUrlParameter("p_session_id");
	var vURL="NetcOptions.CallPrefs?p_session_id=" + sessionId + "&p_content=netcoptions.prefs?P_CAT=NETC.CUST_LISTS%26p_session_id=" + sessionId;
	popWin(vURL,"netCADOPSpop",900,400); 
}

// --Added function to toggle filter icon 06 / 09 / 05 DS
function toggleFilterImg(image) 
{
    formCrews.filterImg.src = image;
}
