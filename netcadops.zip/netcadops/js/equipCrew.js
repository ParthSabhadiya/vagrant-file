// These functions called in crewmgmtdet.pkb:Equipment()
// Used to Add Equipment to crew in netc:StormRoom:Crew Mgmt:Equipment:Add
//
function addTo(what, txt_trans_10200, txt_trans_10225, txt_trans_10226, g_oncrew, g_avail, g_busy) {
    var equiplist = "", xfmr = "";

    document.formEqu.h_sync_crew_id.value = ""; //  to force refresh of this page after CrewMgmt.Apply
    var table = $("#equipment-table").DataTable();

    if (table.rows('.selected').data().length == 0) {
        alert(txt_trans_10200); // "Please select a Equipment from the list");
        return false;
    }

    for (var i = 0; i < table.rows('.selected').data().length; i++) {
        xfmr = table.rows('.selected').data()[i][1];
        if (what == "A" || what == "REMOVE") {
            equiplist = equiplist + xfmr + "]";  // We use sq-bracket ] as the delimiter for multiple employees selected
        }
        //alert('Debug: xfmr = ' + xfmr + ' total rows = ' + table.rows('.selected').data().length + ' equiplist = ' + equiplist);
    }

    var crewform = parent.crew.document.formCrew;
    if (what == "A") { // Add
        crewform.h_equ_list.value = crewform.h_equ_list.value + equiplist;
        alert(txt_trans_10225 + crewform.h_equ_list.value); // Equipment selected to be added, click on Apply to save.\n\nSelection is:
        //alert('Debug:  crewform.h_equ_list.value =  ' + crewform.h_equ_list.value + ' equiplist = ' + equiplist);
    }
    if (what == "REMOVE") {
        crewform.h_equ_remove.value = crewform.h_equ_remove.value + equiplist;
        alert(txt_trans_10226 + crewform.h_equ_remove.value); // Equipment selected to be removed, click on Apply to save.\n\nSelection is:
    }
}

function applyChange(but, txt_trans_11, txt_trans_37, txt_trans_10337) {
    if (self.parent.frames.length != 0) {
        but.value = txt_trans_11; //  "Working..."
        parent.crew.applyChange(parent.crew.document.formCrew, "butApply", "U"); // calls the crewmgmt.pkb:CrewInfo()
        but.value = txt_trans_37; // "Apply"
    } else {
        alert(txt_trans_10337); // "Cannot find the parent frame."
    }
}
