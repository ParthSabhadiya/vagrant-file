//
// AddEmployee: Param who is : M = Member, L = Leader, REMOVE = Remove the member
// We are building a "]" separated string of non-leader emp IDs to send it to the CrewInfo hidden field h_emp_list.
//
function addEmp(who, mesg) {
    var emplist = "", xfmr = "";
    document.formEmp.h_sync_crew_id.value = "";
    var table = $("#employee-list").DataTable();

    if (table.rows('.selected').data().length == 0) {
        alert(mesg);
        return false;
    }

    for (var i = 0; i < table.rows('.selected').data().length; i++) {
        xfmr = table.rows('.selected').data()[i][1];
        if (who == "M" || who == "REMOVE") {
            emplist = emplist + xfmr + "]";  // We use sq-bracket ] as the delimiter for multiple employees selected
        }
        //alert('Debug: xfmr = ' + xfmr + ' total rows = ' + table.rows('.selected').data().length + ' emplist = ' + emplist);

        //		if (who=="L" || who=="M") {
        //			document.gridapplet.setRowBgColor(ridArr[i], "' || LibHTML.g_oncrew || '");
        //		}
        //		if (who=="REMOVE") {
        //			document.gridapplet.setRowBgColor(ridArr[i], "' || LibHTML.g_avail || '");
        //		}
    }

    var crewform = parent.crew.document.formCrew;

    if (who == "M") {
        crewform.h_emp_list.value = crewform.h_emp_list.value + emplist;
        alert('Employee selected to be added, click on Apply to save.\n\nSelection is: ' + crewform.h_emp_list.value);
        //alert('Debug:  crewform.h_emp_list.emp_list =  ' + crewform.h_emp_list.value);
    }
    else if (who == "REMOVE") {
        crewform.h_emp_remove.value = crewform.h_emp_remove.value + emplist;
        alert('Employee selected to be removed, click on Apply to save.\n\nSelection is: ' + crewform.h_emp_remove.value);
    }
    else if (who == "L") {
        crewform.h_crew_leader.value = table.rows('.selected').data()[0][1];
        crewform.crew_leader.value = table.rows('.selected').data()[0][1];
        crewform.leader_name.value = table.rows('.selected').data()[0][2];
        parent.crew.document.getLeader(table.rows('.selected').data()[0][1]);
        alert('Leader selected, click on Apply to save');
    }
}
