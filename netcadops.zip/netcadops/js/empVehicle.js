function addEmp(mesg1,mesg2) {
  
  
  var done = "0";
  var table = $("#employee-vehicle-list").DataTable();
  if (table.rows('.selected').data().length == 0)
		{
			alert(mesg1);
          	return false;
    }

  var form = parent.veh.document.formVeh;
    done="1";
  for (var i=0; i<form.elements.length; i++) {
   if (form.elements[i].name.substring(0,5)=="chbox"&& form.elements[i].checked) {
    form.elements[i+5].value = table.rows('.selected').data()[0][1];
    form.elements[i+6].value = table.rows('.selected').data()[0][2];
    done="1";
    }
   }
    if (done=="0") {alert(mesg2);}
  }
