/* -----------------------------------------------------------------------------
-- # 
-- #           +-----------------------------------------------+
-- #           |                                               |
-- #           |               COPYRIGHT (c) 1990-2012         |
-- #           |                                               |
-- #           |       ABB Network Management SYSTEMS          |
-- #           |                                               |
-- #           |               All rights reserved             |
-- #           |                                               |
-- #           +-----------------------------------------------+
-- # 
-- # +
-- # File Name: applet.js
-- # This java script is responsible to call the netCADOPS appletes.
-- # -
-- # MODIFICATION HISTORY
-- # 
-- # 000     20-Dec-2012     MS     Changed copyright notice as per coding-std doc
-- # 001     20-Dec-2012     MS     DMS 7.1 defect 124632 Merged code chnage for 116310.
-- #                                This applet.js has code in it that checks for a specific 
-- #                                version of java (1.4.2_03).  
-- #                                Code modified to make this code independent of the java code.
******************************************************************************/

//GLOBAL VARIABLES
var g_applet_height;
var g_applet_width;
var ignoreScroll = false;
var ignoreResize = false;
var ignoreFocus = false;


//GLOBAL EVENT CAPTURE
//for future use only

function calcSize(size,delta)
{
   var calc;
   if (delta.indexOf("-") > -1) 
   {			
	   calc = size + parseInt(delta); 
   }
   else 
   {
      if (delta.indexOf("%") > -1) 
      {			
         calc = size/100 * parseInt(delta); 
      }
      else 
      {
         calc = delta;
      }
   }
   return calc;
}

function getAppletTag(name, code, codebase, archive, width, height) 
{
   // height and width can be passed as offsets (e.g. -150) or percentages (e.g. 40%)

   var calc_width, calc_height, applet_str;

   // msoft only...
   if (window.innerHeight) { 
      calc_height=window.innerHeight;
      calc_width=window.innerWidth;
   }
   else if (document.documentElement && document.documentElement.clientHeight) {
      calc_height=document.documentElement.clientHeight;
      calc_width=document.documentElement.clientWidth;
   }     
   else {
      calc_height=document.body.clientHeight;
      calc_width=document.body.clientWidth;
   }

   calc_height = calcSize(calc_height,height);
   calc_width = calcSize(calc_width,width);
   var adjustment;
			
   // 10/28/03 JH:  GridApplets now expand to the width of the body in the browser.
   //Set initial applet dimensions.
   if (navigator.appName.indexOf("Microsoft") != -1)
   {
      adjustment = 20;
      g_applet_width = document.body.clientWidth - adjustment;
      g_applet_height = document.body.clientHeight - adjustment;
   }
   else
   {
      adjustment = 15;
      g_applet_width = window.innerWidth - adjustment;
      g_applet_height = window.innerHeight - adjustment;
   }
   if (name == "gridapplet" || name == "graphapplet")
   {
      calc_width=g_applet_width;
   }

// 10/28/03 JH:  Applets now expand to the width of the body in the browser.
// 03/03/03 JH:  Applets will now be instantiated with the OBJECT tag
// Note: The classid/codebase/type object parameters will need to be updated for future Java plugin versions required by netCadops applets.

   var appletTag;

   if (navigator.appName.indexOf("Microsoft") != -1)
   {
   	  // static versioning of java - version is hard-coded and does EXACT match of version
      //appletTag = "<OBJECT id="+name+" classid = \"clsid:CAFEEFAC-0014-0002-0003-ABCDEFFEDCBA\"";
      //appletTag += " codebase = \"http://java.sun.com/products/plugin/autodl/jinstall-1_4_2_03-windows-i586.cab#Version=1,4,2,03\"";

	  // dynamic versioning of java - version is whatever max version available at sun site and whatever
	  // lower minor-version of 1.6 if on PC will be used. 
      appletTag = "<OBJECT id="+name+" classid = \"clsid:8AD9C840-044E-11D1-B3E9-00805F499D93\"";
	  appletTag += " codebase = \"http://java.sun.com/update/1.6.0/jinstall-6u24-windows-i586.cab#Version=1,6,0,0\"";
	  //appletTag += " codebase = \"http://java.sun.com/products/plugin/autodl/jinstall-1_6-windows-i586.cab#Version=1,6,0,0\"";
   }
   else
   {
      appletTag = "<OBJECT id="+name+" type=\"application/x-java-applet;version=1.6\"";
      appletTag += " pluginspage=\"http://java.sun.com/products/plugin/index.html#download\"";
	  //appletTag += " pluginspage=\"http://java.sun.com/j2se/1.5.0/download.html\"";
	  //appletTag += " pluginspage=\"http://java.sun.com/update/1.6.0/jinstall-6u24-windows-i586.cab#Version=1,6,0,0\"";
      //appletTag += " pluginspage=\"http://www.oracle.com/technetwork/java/javase/downloads/index.html\"";
   }

   // Mozilla browsers only not IE - version= versus jpi-version=
   // With version= form, the highest installed JRE that supports the MIME type 
   // is invoked to run the applet. If a JRE with a version number equal to or greater than 
   // the version number specified is installed locally, then that JRE is invoked. Otherwise 
   // the user is directed to the URL specified as the value of the pluginspage attribute.
   //
   // With jpi-version= form, a JRE with the exact version given by the the value of jpi-version 
   // is invoked to run the applet. Otherwise the user is directed to the URL specified 
   // as the value of the pluginspage attribute.
   appletTag += " width="+calc_width+" height="+calc_height+">"  
    + "<PARAM NAME = CODEBASE VALUE = "+codebase+">" 
    + "<PARAM NAME = CODE VALUE = "+code+">" 
    + "<PARAM NAME = ARCHIVE VALUE = "+archive+">"
    //+ "<PARAM NAME = type VALUE = \"application/x-java-applet;jpi-version=1.4.2.03\">" 
    + "<PARAM NAME = type VALUE = \"application/x-java-applet;version=1.6.0.0\">" 
    + "<PARAM NAME = scriptable VALUE = \"false\">";

	return appletTag;
}

// Function to calculate the applet size and call it, using the code, codebase and archive sent in.
function callApplet(name, code, codebase, archive, width, height) 
{
   var appletTag = getAppletTag(name, code, codebase, archive, width, height);
   document.write(appletTag);

   // get correct firefox events to refresh applet...
   if (navigator.appName.indexOf("Microsoft") == -1)
   {
      document.addEventListener("onScroll", appletUpdateAll, true); 
      document.addEventListener("onFocus", appletUpdateAll, true); 
      document.addEventListener("onResize", appletUpdateAll, true); 
      document.addEventListener("onload", appletUpdateAll, true); 
   }

}
// otherparams is like "<PARAM NAME= something VALUE=some-value>"
// can repeat and send several params vars in otherparams.
function callAppletParams(name, code, codebase, archive, width, height, otherparams) 
{
	var appletTag = getAppletTag(name, code, codebase, archive, width, height);
	//alert("otherparams = " + otherparams);
	if (otherparams !== null) { // if not null
		// otherparams is like "<PARAM NAME= something VALUE=some-value>"
		// can repeat and send several params vars in otherparams.
		appletTag += otherparams;	
	}
	//alert("appletTag = " + appletTag);
   document.write(appletTag);
}


// 04/10/03 EK  Function that returns ids of the selected rows in the grid applet.
// array of row ids ridArr
// array of key ids pidArr (if one row)
// vMsg is either Please select one row, or Please select at least one row.
// Example: 
// htp.p( 'if (!getRows(0,"' || txt_trans_tbl(908) || '")) return false;' );
function getRows(vOne, vMsg) 
{
   var ridAsString = document.gridapplet.getSelectedID()+"";
   if (ridAsString.length == 0) 
   {
      alert(vMsg);
      return false;
   }

   ridAsString = ridAsString.substring(0, ridAsString.lastIndexOf("|"))+"";
   ridArr = ridAsString.split("|");
   if (vOne==1) 
   {
      if (ridArr.length>1) 
      {
         alert(vMsg);
         return false;
      }
   }

   for (var i=0; i<ridArr.length; i++) 
   {
      pidAsString = document.gridapplet.getRow(ridArr[i]);
      pidArr = pidAsString.split("|");
   }

   return true;
}


// 10/17/03 JH Function calls resize method in Applet whenever browser window/page is
//             resized.
function resize() 
{
   var v_new_width, v_new_height;
   var v_max_width = g_applet_width;
   var v_max_height = g_applet_height;

   var adjustment;

   if (navigator.appName.indexOf("Microsoft") != -1)
   {
      adjustment = 20;
      v_new_width = document.body.clientWidth - adjustment;
      v_new_height = document.body.clientHeight - adjustment;
   }
   else
   {
      adjustment = 15;
      v_new_width = window.innerWidth - adjustment;
      v_new_height = window.innerHeight - adjustment;
   }

   //document.gridapplet.setSize(parseInt(v_new_width), parseInt(v_new_height));
   if (document.gridapplet)
   {
      document.gridapplet.width=v_new_width;
   }
   if (document.graphapplet)
   {
      document.graphapplet.width=v_new_width;
   }
   if (document.Graph)
   {
      document.Graph.width=v_new_width;
   }
   repaint();
   ignoreResize = false;
}


// 10/27/03 JH:
// Called from eventCaptures in netcadops procedures
function appletUpdate(e)
{
   // try to retrofit for Firefox, only call for IE...
   if (window.event)
   {
      appletUpdateAll();
   }
}

function appletUpdateAll(e)
{
   if (document.gridapplet || document.graphapplet || document.Graph) 
   {
      var ename;
      if (window.event)
      {
         ename = window.event.type;
      }
      else
      {
         ename = e.type;
      }
      if ("load"==ename || "resize"==ename)
      {
         if(!ignoreResize)
         {
            // Set timer for resize/repaint
            setTimeout("resize()",1000);
            //ignore subsequent resize events until timeout.
            ignoreResize = true;
         }
      }
      else if ("scroll"==ename)
      {
         if(!ignoreScroll)
         {
            setTimeout("repaint()",1000);
            //ignore subsequent onscroll events until timeout.
            ignoreScroll = true;
         }
      }
      else if ("focus"==ename)
      {
         if(!ignoreFocus)
         {
            setTimeout("repaint()",1000);
            //ignore subsequent onfocus events until timeout.
            ignoreFocus = true;
         }
      }
      //Future additional events
      else { }
   }
}

// 10/27/03 JH:
// Called from delayedPaint to repaint the applet
function repaint()
{
   //ignore subsequent onscroll events until timeout.
   //document.gridapplet.repaint();
   if (document.gridapplet)
   {
      document.gridapplet.repaint();
   }
   if (document.graphapplet)
   {
      document.graphapplet.repaint();
   }
   if (document.Graph)
   {
      document.Graph.repaint();
   }
   ignoreScroll = false;
   ignoreFocus = false;
}


function oAppSelector(select,applet) {

   // private vars

   var selectedRecords = {};
   var initialRecords = {};
   var listObject = applet;
   var selectionObject = select;
   var skipTag = "-101";

   // private methods

   var Selections = function () {
      var listID = listObject.getSelectedItemIDs() + '';
      var listNames = listObject.getSelectedItemNames() + '';

      listID = listID.substring(0, listID.lastIndexOf("|"));
      listNames = listNames.substring(0, listNames.lastIndexOf("|"));

      var ids = listID.split("|");
      var names = listNames.split("|");

      var sels = {};

      for (var i = 0; i < ids.length; i++) {
         if (ids[i]!=skipTag) {
            sels[ids[i]] = names[i];
         }
      }

      return sels;
   }

   var AddRecord = function (code,name) {

      // add, or select if exists
      if (!selectedRecords[code]) {
         selectedRecords[code] = name;
         var count = selectionObject.length;
         selectionObject.options[count] = new Option(name,code);
         selectionObject.options[count].selected = true;
         selectionObject.options[count].id = selectionObject.id + code;
      }
      else {
         var o = document.getElementById(selectionObject.id + code);
         o.selected = true;
      }
   }

   var RemoveRecord = function (code) {
      // can't really remove...
      selectedRecords[code] = null;
   }


   // public methods

   this.AddInitRecord = function (code,name) {
      initialRecords[code] = name;
      AddRecord(code,name);
   }


   this.AddOptions = function () {
      var sels = Selections();

      // clear already chosen list
      for (var i=selectionObject.length -1; i>=0; --i) {
         selectionObject.options[i].selected = false;
      }

      for (var id in sels) {
         if (id) {
            AddRecord(id,sels[id]);
         }
      }
   }


   this.RemoveOptions = function () {
      var sels = {};

      for (var i=selectionObject.length -1; i>=0; --i) {
         if (selectionObject.options[i].selected) {
            sels[selectionObject.options[i].value] = selectionObject.options[i].text;
            selectionObject.options[i] = null;
         }
      }

      for (var id in sels) {
         RemoveRecord(id);
      }
   }

   this.GetAdditions = function () {
      var parlist = new Array;
      
      for (var id in selectedRecords) {
         if (!initialRecords[id]) {
            parlist.push(id);
         }
      }
      return parlist;
   }

   this.SetSkip = function (tag) {
      skipTag = tag;
   }

   this.GetSubtractions = function () {
      var parlist = new Array;
      
      for (var id in initialRecords) {
         if (!selectedRecords[id]) {
            parlist.push(id);
         }
      }
      return parlist;
   }

} // oAppSelector
