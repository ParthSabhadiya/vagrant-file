

//  --htp.print( '<script language="JavaScript">');
//  -- function to get list of selected nodes
//  --htp.p( 'function getList(form, all) {' ||
//  --   'var v_rid2=""; var v_tree="TREE";' ||
//  --   'if (all==0) {' ||
//   --     'var v_rid2 = document.treeapplet.getSelectedItemIDs();' ||
//   --     '}' ||
//   -- else v_rid2 stays null
//   --  '' ||
//   --  'var vURL = "outformscause.LowestLevelOutages?p_session_id='||p_session_id||chr(38)||'p_list="+escape(v_rid2)+"'||chr(38)||'p_page="+v_tree+"' || '";' ||
//   --  'document.location.href = vURL;' ||
//   --  '}' );

// Called when the form buttons are clicked. Saves session ids by caling saveSessionIds at the beginning.
function formSubmitted(form, all)
{
    saveSessionIds();

    var listIDs = "";
    var listNames = "";
    if ( all == 0 ){ // Few areas picked by user
       listIDs = getSelectedIds(treeSelector);
       listNames = getSelectedNames(treeSelector);
       console.log("listIDs = " + listIDs + " listNames = " + listNames);
       if ( listIDs == ""){
           alert( "You must select at least one item to proceed.");
           return;
       }
    }
    form.selAreaNo.value=listIDs;
    var vURL = "OutFormsCasue.LowestLevelOutages?p_session_id=" + p_session_id + "&p_list=" +listIDs + "&p_page=TREE";
    document.location.href=vURL;
}


// -------------------------------

function removeCause()
{
	var selob = $("#added_causes");
	var v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple") + " datanative = " + selob.attr("data-native-menu");
	console.log(v_msg);
	//var v_opts = $("#added_causes option"); // if you want all that are selected
	var v_opts = $("#added_causes option:selected"); // If you only want the ones that are selected
	var v_names = $.map(v_opts ,function(ele) {
    	return ele.text;
	});
	console.log("names = " + v_names);
	var v_values = $.map(v_opts ,function(ele) {
    	return ele.value;
	});
	//var v_vals = v_opts.each(function(name, val) { 
	//		var opt = val.text; 
	//	});
	//var v_namearr = v_opts.map(function() { return $(this).text(); }).get();
	//var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	//var v_valarr = v_values.split(","); // string to array
	//console.log("values = " + v_values + " valarr = " + v_valarr + " names = " + v_names + " namearr = " + v_namearr);
	v_opts.remove();

}

function addCause(form, all, who, trans639, g_oncrew, g_busy) 
{
    saveSessionIds();

    var listIDs = "";
    var listNames = "";
    if ( all == 0 ){ // Few areas picked by user
       listIDs = getSelectedIds(treeSelector);
       listNames = getSelectedNames(treeSelector);
		console.log("listIDs = " + listIDs + " listNames = " + listNames);
       if ( listIDs == ""){
           //alert( "You must select at least one item to proceed.");
			//-- txt_trans_tbl(639) = Please select a cause category from the list.
			alert(trans639);
           return;
       }
    }
    //form.selAreaNo.value=listIDs;
    //var vURL = "OutFormsCasue.LowestLevelOutages?p_session_id=" + p_session_id + "&p_list=" +listIDs + "&p_page=TREE";
    //document.location.href=vURL;



	var emplist = "";
	/*
    var ridAsString; var empidAsString; var idAsString; 
    var ridArr = new Array(); var empidArr = new Array(); empidArr[0] = ""; empidArr[1] = "";
    ridAsString = document.gridapplet.getSelectedID() + "";
    //-- 06/10/02 JH: Internationalization
    //-- txt_trans_tbl(639) = Please select a cause category from the list.
    if (ridAsString.length == 0) { alert("+trans639+"); return; }

    idAsString = ridAsString.substring(0, ridAsString.lastIndexOf("|")); // -- remove the last separator
    idAsString = idAsString + "";
    ridArr = idAsString.split("|");
    for (var i = 0; i < ridArr.length; i++) { // -- js loop through selected rows
        empidAsString = document.gridapplet.getRow(ridArr[i]);
        empidAsString = empidAsString + "";
        empidArr = empidAsString.split("|");
        if (who == "M" || who == "REMOVE") {
            emplist = emplist + empidArr[0] + "]";
        }
        // -- Set colors
        if (who == "L" || who == "M") {
            document.gridapplet.setRowBgColor(ridArr[i], g_oncrew);
        }
        if (who == "REMOVE") {
            document.gridapplet.setRowBgColor(ridArr[i], g_busy);
        }
    } //-- end js loop
	*/

    //-- Save selected values
    var crewform = document.formCause;
    if (who == "M") { // -- Add cause
        crewform.h_cause_list.value = crewform.h_cause_list.value + emplist;
    }
    if (who == "REMOVE") { // -- Remove cause
        crewform.h_cause_remove.value = crewform.h_cause_remove.value + emplist;
    }

	addToListPanel(listIDs, listNames);
}

// Add a given list of options to the select box - list box
// Pipe delimited vars strings optIDs like '1|2|3|'  and optNames like 'name1|name2|name3'
function addToListPanel(optIDs, optNames) 
{
	var selob = $("#added_causes");
	var v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple") + " datanative = " + selob.attr("data-native-menu");
	//alert(v_msg);
	console.log(v_msg);
	var v_opts = $("#added_causes option");
	//var v_opts_picked = $("#added_causes option:selected"); // If you only want the ones that are selected
	var v_names = $.map(v_opts ,function(ele) {
    	return ele.text;
	});
	console.log("names = " + v_names);
	var v_values = $.map(v_opts ,function(ele) {
    	return ele.value;
	});
	//var v_vals = v_opts.each(function(name, val) { 
	//		var opt = val.text; 
	//	});
	var v_namearr = v_opts.map(function() { return $(this).text(); }).get();
	var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	//var v_valarr = v_values.split(","); // string to array
	console.log("values = " + v_values + " valarr = " + v_valarr + " names = " + v_names + " namearr = " + v_namearr);
	selob.remove();


	/* 
	 * Dynamic adding of options below is not working because it is not enabling the MULTIPLE attribute
	 * Hence, use the full html append in next section below:
	// Before doing push into options and changing it, set the attributes
	selob.attr("multiple", "multiple");
	//selob.attr("data-native-menu", "false");
	selob.attr("data-role", "none");
	selob.attr("size", "35");

	// Add to the Cause Categories list box
	var options = [];
	// Clear the options first   
	// selob.each(function(index, option) {
	//	$(option).remove();
	//});
	//options.push("<option value=''>Choose</option>");
	//options.push("<option value='" + "mytest" + "'>" + "mytest" + "</option>");
	options.push("<option value=1>1</option>");
	selob.append(options.join("")).selectmenu();
	v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple");
	//alert(v_msg);
	console.log(v_msg);
	//selob.attr("size").change();  change is not function error
	selob.selectmenu().change();
	selob.selectmenu('enable');
	selob.selectmenu("refresh");
	*/

	/* 
	 * Dynamic adding of options is not working because it is not enabling the MULTIPLE attribute
	 * Hence, use the full html append in the section below:
	*/
	var v_txt;
	//v_txt= "<h1>Text.</h1>"; // Create element with HTML
	//$("#outformscause-list").append(txt1);
	
	// Create element with HTML - select option list box
	v_txt = "<div class='jl' id='outformscause-list'> \
			<select name='added_causes' id='added_causes' \
				multiple='multiple' \
				size='35' \
			>";

	// Add the existing cause categories
	for (ii = 0; ii < v_namearr.length; ii++) {
		v_txt += "<option value=" + v_valarr[ii] + ">"+ v_namearr[ii] + "</option>";
	}

	// Add the currently user picked cause categories from right panel
    var pick_arr = optIDs.split('|');
    var names_arr = optNames.split('|');
	//v_txt += " <option value=1>one</option> \
	//		  <option value=2 selected='selected'>Two</option> \
	//		</select> ";
	for (ii = 0; ii < names_arr.length; ii++) {
	    if (isBlank(pick_arr[ii])) // if null or empty string skip
			continue; 
		if (v_valarr.indexOf(pick_arr[ii]) != -1) 
			continue; // if item already exists in the left panel then ignore
		if (pick_arr[ii] === "0") 
			continue; // Ignore top level nodes like Animals, Equipment, Thirdparty which have 0
		v_txt += " <option value=" + pick_arr[ii] + ">" + names_arr[ii] + "</option>";
	}
	v_txt += " </select> </div> ";
	console.log("v_txt = " + v_txt);
	$("#outformscause-list").append(v_txt);
	//$("#outformscause-list").append(v_txt).trigger('create');
	//$("outformscause-list").change();
	//alert("done 1");
}

function applyChange(form, but, trans11, p_display_type) 
{
    saveSessionIds(); // will set the session_id

	// session_id is got from global var
	console.log("p_session_id = " + p_session_id + " trans11 = " + trans11 + " p_display_type = " + p_display_type);

	// The par_val is like this: 
	// p_par  -  three pipe (|) delimited strings are contained in this procedure,
	// very first is the string of outage_cause_validation_time
	// second is the string of causes to add (delimited by ]) like  Aa]Bbb]Cccc]
	// third string of causes to remove (delimited by ]) like  Aa]Bbb]Cccc]
	// fourth is outage number or trouble_rpt no, non cust call no.
	// For example:  p_par = outage_cause_validation_time|causes to add| causes to remove  | outage_no or trouble rpt no |

    var par_val = ""; 
	/*
	var sel_name; var eltype; but.value = trans11;
    for (var i = 0; i < form.elements.length; i++) {
        eltype = form.elements[i].name.substring(0, 3);
        if (eltype != "but" && eltype != "sel" && eltype != "rad") {
            par_val = par_val + form.elements[i].value + "|";
        }
        if (eltype == "sel") {
            sel_name = "form." + form.elements[i].name;
            eval("v=" + sel_name + ".options[" + sel_name + ".selectedIndex].value;");
            par_val = par_val + v + "|";
        }
    }
	*/

	// For example value of par_val:
	//par_val = "<cause_date>|cause_no1]cause_no2]cause_no3]|removecause_no1]remove_cause_no2]|trouble_rpt_no or outage_no or ncc_no|";
	//par_val = "|1700]800]805]||936062|";


	var cause_date = $("#txtCAUSDate").attr("value");
	var h_out_no = $("#h_out_no").attr("value");  // This has the outage_no or trouble_rpt_no, or ncc number

	var cause_cat_no = "";
	//var selob = $("#added_causes");
	var v_opts = $("#added_causes option");
	//var v_opts_picked = $("#added_causes option:selected"); // If you only want the ones that are selected
	var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	for (ii = 0; ii < v_valarr.length; ii++) {
		cause_cat_no += v_valarr[ii] + "]";  // cause cat numbers are delimited with character ] 
	}

	// The remove-cause-numbers are empty hence ||
	par_val = cause_date + "|" + cause_cat_no + "||" + h_out_no + "|" ;

    //-- 04/08/05 EK  Added session id parameter
    var vURL = "OutFormsCause.Apply?p_par=" + escape(par_val) + "&p_session_id=" + p_session_id + "&p_display_type=" + p_display_type;
    document.location.href = vURL
}


/*
var myData = [
    {
        id: 0,
        title: 'Item 1 '
    }, {
        id: 1,
        title: 'Item 2',
        subs: [
            {
                id: 10,
                title: 'Item 2-1'
            }, {
                id: 11,
                title: 'Item 2-2'
            }, {
                id: 12,
                title: 'Item 2-3'
            }
        ]
    }, {
        id: 2,
        title: 'Item 3'
    },
    // more data here
];
*/

// Gets the previous saved causes from the oracle database and displays in left panel
function retrieveSavedCauses() 
{
	var display_type = $("#display_type").attr("value");
	var cause_arr;
	// Get all the elements whose id is starting with "db_r"
	var optIDs = "", optNames = "";
	var prev_causes = $("[id^=db_r]"). each(function() {
		// db_r will be like - "801| |Jumper|OH Conductor| |"
		cause_arr = $(this).attr("value").split('|');
		for (ii = 0; ii < cause_arr.length; ii++) {
			if (ii === 0) {
				v_val = cause_arr[0]
			} else if (ii === 2) {
				v_name = cause_arr[2]
				optIDs += v_val + "|";
				optNames += v_name + "|";
				v_val = ""; // reset
			}
		}
	});

	addToListPanel(optIDs, optNames);
}

//var listSelector = "#outformscause-list"
var treeSelector = "#outformscause-tree"
$(document).ready(function () 
{
    // create  the tree data  structure
    
    var treeOrFlat = $('paramTreeOrFlat').attr('VALUE'); // is tree or flat
    var treeData = parseTreeNodeInfo($('paramTreeList').attr('VALUE'));
    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true, // Show check boxes
        selectMode: 2, // 1:single, 2:multi, 3:multi-hier
        autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        expanded: false, // do not collapse 
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        } , 

        // Fancytree events sample: https://github.com/mar10/fancytree/blob/master/demo/sample-events.html
        // beforeExpand 	function 
        // data.node is about to be collapsed/expanded. Current status is data.node.isExpanded(). Return false to prevent default processing.
        beforeExpand: function (event, data) {
            //logEvent(event, data, "current state=" + data.node.isExpanded());
            // return false to prevent default behavior (i.e. expanding or collapsing)
            if (treeOrFlat === "flat") {
                return false; // about to be collapsed/expanded
            } else {
                return true; // about to be collapsed/expanded
            }
        }

    });

    //var tree = $(treeSelector).fancytree("getTree");
    //tree.expandAll = false;
    //alert("We have " + tree.count() + " nodes.");
    //tree.reload();

    // Expand all tree nodes
    //tree.visit(function (node) {
     //   node.setExpanded(true);
    //});
    

    $(treeSelector).fancytree("getRootNode").visit(function (node) {
        if (treeOrFlat === false) {
            node.setExpanded(true);
        } else {
            node.setExpanded(false);
        }

    });

	retrieveSavedCauses();

    /*
    $('#example').comboTree({
        source: myData,
        isMultiple: true,
        cascadeSelect: false
    });
    */


});
