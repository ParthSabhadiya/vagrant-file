// ----------------------------------------------------------------------------
// 
//     +---------------------------------+
//     |  Copyright (c) 2015             |
//     |  ABB Network Management Systems |
//     |  All rights reserved            |
//     +---------------------------------+
// 
// Modification History
// 2015-03-04  RW  SPR137615 - Set all cookies to use the path "/" to resolve an 
//                 issue with mod_netcadops_enc internal redirection
// 2015-04-21  NM  SPR 137827 - msg variable should be declared outside the function.
// 2015-06-30  alv SPR 137827 - Rework SPR. The netCADOPS - Session not timing out.
//                              The mins variable should be declared outside the function.
// 2018-03-01  AV  Bug 94456    OCC scan change the methods and code to avoid conflict of copy rights.
//                              Change method names and variables to avoid occ scan from reporting                  
// ----------------------------------------------------------------------------

var debug = 0;
var msg = 0;
var mins = 0;

function CheckSession(message, sessionID) {
   if (getValidationFrame()!=null) {
       getValidationFrame().location.href = "NETCMENU.ValidateSessionDB?p_session_id="+sessionID;
       return;
       }
   else {
       return;
       }
}

function InitTimer(message) {
    // Set the length of the timer, in seconds
    msg = message;
    mins = init_time;
    StopTimer();
    StartTimer();
}

function ResetTimer() {
    if (getSessionFrame()) {
        getSessionFrame().mins = getSessionFrame().init_time;
        return;
    } else {
        return;
    }
}

function StopTimer() {
    if(timerRunning) {
        clearTimeout(timerID);
    }
    timerRunning = false;
}

function StartTimer() {
    if (mins==0) {
        StopTimer();
        var session_id = getSessionFrame().sessionID;
        SetCookie("NetcLogged_"+session_id,"N");
        DeleteCookie("NetcLogged_"+session_id);
        alert(msg);
        getSessionFrame().sessionClose();
    }
    else {
        mins = mins - 1
        timerRunning = true
        timerID = self.setTimeout("StartTimer()", delay);
    }
}

function SetCookie(ckname, set_val) {
    var arg_vv = SetCookie.arguments;
    var arg_cc = SetCookie.arguments.length;
    var is_dead = (arg_cc > 2) ? arg_vv[2] : null;
    var location = (arg_cc > 3) ? arg_vv[3] : "/";
    var domain = (arg_cc > 4) ? arg_vv[4] : null;
    var secure = (arg_cc > 5) ? arg_vv[5] : false;
    document.cookie = ckname + "=" + escape(set_val) +
    ((is_dead == null) ? "" : ("; expires=" + is_dead.toGMTString())) +
    ((location == null) ? "" : ("; path=" + location)) +
    ((domain == null) ? "" : ("; domain=" + domain)) +
    ((secure == true) ? "; secure" : "");
}

function DeleteCookie(name) {
    var dt = new Date();
    dt.setTime(dt.getTime() - 1);
    // This cookie is history  	
    var cval = GetCookie(name);
    document.cookie = name + "=" + cval + "; expires=" + dt.toGMTString();
}


function GetCookie(in_arg) {
    var aa = in_arg + "=";
    var bb_leng = aa.length;
    var cc_leng = document.cookie.length;
    var ii = 0;
    while (ii < cc_leng) {
        var jj = ii + bb_leng;
        if (document.cookie.substring(ii, jj) == aa)
            return getCookieVal(jj);
        ii = document.cookie.indexOf(" ", ii) + 1;
        if (ii == 0) break;
    }
    return null;
}


function getCookieVal(in_value) {
    var tailstr = document.cookie.indexOf(";", in_value);
    if (tailstr == -1)
        tailstr = document.cookie.length;
    return unescape(document.cookie.substring(in_value, tailstr));
}

function getSessionFrame() {
 try {
   if (top.sessionframe) {
      if (debug == 1) alert("1 LEVEL [getSessionFrame]");
      return top.sessionframe;
   } else if (top.opener) if (top.opener.sessionframe) {
      if (debug == 1) alert("2 LEVEL [getSessionFrame]");
      return top.opener.sessionframe;
   } else if (top.opener.top) if (top.opener.top.sessionframe) {
      if (debug == 1) alert("3 LEVEL [getSessionFrame]");
      return top.opener.top.sessionframe;
   } else if (top.opener.top.opener) if (top.opener.top.opener.sessionframe) {
      if (debug == 1) alert("4 LEVEL [getSessionFrame]");
      return top.opener.top.opener.sessionframe;
   } else if (top.opener.top.opener.top) if (top.opener.top.opener.top.sessionframe) {
      if (debug == 1) alert("5 LEVEL [getSessionFrame]");
      return top.opener.top.opener.top.sessionframe;
   } else if (top.opener.top.opener.top.opener) if (top.opener.top.opener.top.opener.sessionframe) {
      if (debug == 1) alert("6 LEVEL [getSessionFrame]");
      return top.opener.top.opener.top.opener.sessionframe;
   } else if (top.opener.top.opener.top.opener.top) if (top.opener.top.opener.top.opener.top.sessionframe) {
      if (debug == 1) alert("7 LEVEL [getSessionFrame]");
      return top.opener.top.opener.top.opener.top.sessionframe;
   } else {
      if (debug == 1) alert("getSessionFrame - TOO MANY LEVELS");
      return null;
   }
 }
 catch (e) {
   return null;
 }
}

function getValidationFrame() {

 try {
   if (top.validationframe) {
      if (debug == 1) alert("1 LEVEL [getValidationFrame]");
      return top.validationframe;
   } else if (top.opener) if (top.opener.validationframe) {
      if (debug == 1) alert("2 LEVEL [getValidationFrame]");
      return top.opener.validationframe;
   } else if (top.opener.top) if (top.opener.top.validationframe) {
      if (debug == 1) alert("3 LEVEL [getValidationFrame]");
      return top.opener.top.validationframe;
   } else if (top.opener.top.opener) if (top.opener.top.opener.validationframe) {
      if (debug == 1) alert("4 LEVEL [getValidationFrame]");
      return top.opener.top.opener.validationframe;
   } else if (top.opener.top.opener.top) if (top.opener.top.opener.top.validationframe) {
      if (debug == 1) alert("5 LEVEL [getValidationFrame]");
      return top.opener.top.opener.top.validationframe;
   } else if (top.opener.top.opener.top.opener) if (top.opener.top.opener.top.opener.validationframe) {
      if (debug == 1) alert("6 LEVEL [getValidationFrame]");
      return top.opener.top.opener.top.opener.validationframe;
   } else if (top.opener.top.opener.top.opener.top) if (top.opener.top.opener.top.opener.top.validationframe) {
      if (debug == 1) alert("7 LEVEL [getValidationFrame]");
      return top.opener.top.opener.top.opener.top.validationframe;
   } else {
      if (debug == 1) alert("getValidationFrame - TOO MANY LEVELS");
      return null;
   }
 }
 catch (e) {
   return null;
 }
}


