
// -----------------------------------------------------------------------------
//
//           +-----------------------------------------------+
//           |                                               |
//           |               COPYRIGHT (c) 1990-2010         |
//           |                                               |
//           |       ABB Network Management SYSTEMS          |
//           |                                               |
//           |               All rights reserved             |
//           |                                               |
//           +-----------------------------------------------+
//
// +
//  Java script file to do basic validations. Such as validateTextField, Is digit,
//  Etc. As part of system message changes added validateFieldContent() function. 
// 
// -
//   MODIFICATION HISTORY
//
//        000     27-Dec-2010     MS     Added the header
//        001     27-Dec-2010     MS     NGRID System Messages Requirement.
//                                       WO ABB2010 - 108477
// -----------------------------------------------------------------------------

//GLOBAL FLAGS
var paste = false;


function isEmpty(s) {
	// returns true if string is empty
	return((s==null) || (s.length==0))
}

function isDigit(c) {
	return ((c >= "0") && (c <= "9"))
}

function isInteger(s) {
	var i;
	if (isEmpty(s)) return false;
	for (i = 0; i < s.length; i++ )
	{	var c = s.charAt(i);
		if (!isDigit(c)) return false;
	}
	return true;
}

function isIntegerInRange(s, a, b) {
	if (isEmpty(s)) return false;
	if (!isInteger(s, false)) return false;
	if (s=="08") s=8; if (s=="09") s=9;
	var num = parseInt(s);
	return((num >= a) && (num <= b));
}

function isYear(s) {
	// returns true if the year is a 4 digit number
	if (isEmpty(s)) return false;
	if (!isInteger(s)) return false;
	return((s.length == 4));
}

function isMonth(s) {
	if (isEmpty(s)) return false;
	return isIntegerInRange (s, 1, 12);
}

function isDay(s) {
	if (isEmpty(s)) return false;
	return isIntegerInRange (s, 1, 31);
}

function isDate(year, month, day) {
	if (! ( isYear(year) && isMonth(month) && isDay(day))) return false;
	return true;
}

function validateFieldSize(element_ref, maxSize, message) {
   
   if(event.type == "keypress") 
   {
      if (element_ref.value.length >= maxSize) 
      {
         event.returnValue=false;
         return;
      }
      else
      {
         return;
      }
   }
   else if (event.type == "change")
   {
      if (element_ref.value.length > maxSize)
      {
         alert(message);
         element_ref.value = element_ref.value.substring(0,maxSize);
         return;
      }
      else
      {
         return;
      }
   }
      if(event.type == "paste") 
      {
         if (element_ref.value.length >= maxSize) 
         {
         alert(message);
         element_ref.value = element_ref.value.substring(0,maxSize);
         return;
         }
         else
         {
            return;
         }
   }
}

function validateFieldContent(element_ref,  message) {
	  	if (element_ref.value.length != 0) {
	  		var re_patt=new RegExp("[^a-z-A-Z0-9!#$%&''()*+,-./:;=?@^_`{}|~\\]\\[\\s\\n\\0\\r]");
	  		if (re_patt.test(element_ref.value) == true) {
	    			alert(message);
	    			form.element_ref.focus();
	    			return;
	  		}
	}

}


//The character set checked should match the regexp pattern rule defined in 
//mod_security.conf file as shown below.  
//SecRule ARGS "<(.|\n)+>" 						"id:300003,phase:2,log,deny"
//SecRule ARGS "<.+>" 							"id:300005,phase:2,log,deny"
//Shown above are regexp patterns to catch text starting with < and ending with >.  
//This is the pattern used by modsecurity to intercept and deny URL requests.  
//So if the pattern is changed for these entries in mod_security.conf then the checks 
//may need to be added/changed to ensure that the checks are consistent with 
//the changed pattern.
//sql injection relevant checks from libutil.filterXss:
//Also add the condition check from libutil.filterXss to ensure that the requests
//from the netC forms do not hang because of reserved character check in filterXss.
//
//Please note that if the checks are changed in filterXSS then the same should be done here
//after considering it does not conflict with the regexpr in mod_security.conf.
//So for example if < and > are commented out in libutil.filterXSS we should NOT comment them
//out here since the < and > are part of the regexp pattern match as defined in mod_security.conf.

function validateString(s) {

  if(!s || s.length==0)
     return true;

  if(
 	   s.indexOf("<")    > -1       ||
       s.indexOf(">")    > -1       ||
       s.indexOf("\\\\")   > -1       ||
       s.indexOf("\"")   > -1       ||
       s.indexOf("'")    > -1       ||
       s.indexOf("`")    > -1       ||
       s.indexOf("(")    > -1       ||
       s.indexOf(")")    > -1       ||
       s.indexOf("{")    > -1       ||
       s.indexOf("}")    > -1       ||
       s.indexOf("?")    > -1       ||
       s.indexOf("|")    > -1       ||
       s.indexOf(";")    > -1

	)	
  {
    return false;
  }
 
 return true;
}



