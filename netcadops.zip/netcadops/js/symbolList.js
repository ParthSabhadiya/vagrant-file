function changeSymbol(change)
   {
    var sessionId = getUrlParameter("p_session_id");

    var vURL="", param="";
    var ridAsString="", SymbolFposAsString="";
    var table = $("#symbol-list").DataTable();


    if (change == "N")
    {
     vURL = "AstatusTables.NewSymbol?p_session_id="+ sessionId;
     popWin(vURL, "netCADOPSpop", 850, 530);
    }
    else
    {
     ridAsString = table.rows('.selected').data();
     
     if (ridAsString.length == 0)
     {
       alert("Please select a Symbol from the list.");
       return;
     }
     
     for (var i = 0; i < table.rows('.selected').data().length; i++) 
     {
      
      SymbolFposAsString = table.rows('.selected').data()[i][3];
      param = param + SymbolFposAsString + "|"; 
       
     }
     if (change == "U")      {
      vURL = "AstatusTables.UpdateSymbol?p_session_id="+ sessionId+"&p_par="+escape(param); 
      popWin(vURL, "netCADOPSpop", 850, 530);
     }
     else
     {
      vURL = "AstatusTables.ApplySymbol?p_session_id="+ sessionId+"&p_par="+escape(param)+"&p_act="+change; 
      document.location.href = vURL;
     }
    }
   };
