// Functions to support drag&drop
//nn = (document.layers) ? 1:0;
//ie = (document.all) ? 1:0;
var nn=0; var ie=0;
if (document.layers) nn=1;
if (document.all) ie=1;

var targetName;
var targetX;
var targetY;

//function init() {
	// initialize objects
	//silver = new dragDiv("silver",null,1);
	//gold = new dragDiv("gold",null,1);	
//}

// initialize events
	document.onmousedown = mouseDown;
	document.onmousemove = mouseMove;
	document.onmouseup = mouseUp;
	if (nn) document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP);

dragActive = 0;
dragObject = null;
dragArray = new Array();
dragLayerX = 0;
dragLayerY = 0;
dragLayerZ = 0;

function mouseDown(e) {
	if ((nn && e.which == 1) || ie) {
		if (nn) {var x=e.pageX; var y=e.pageY;}
		if (ie) {var x=event.x; var y=event.y;}
		for (var i=dragArray.length-1;i>=0;i--) {
			if (x>=dragArray[i].x && x<=dragArray[i].x+dragArray[i].w && y>=dragArray[i].y && y<=dragArray[i].y+dragArray[i].h) {
				dragObject = dragArray[i];
				dragLayerX = x-dragObject.x;
				dragLayerY = y-dragObject.y;
				dragActive = 1;
				break;
			}
		}
		if (dragActive) {
			// Put the active layer on top of the others and re-arrange dragArray
			dragObject.css.zIndex = dragLayerZ++;
			for (var j=i;j<=dragArray.length-2;j++) dragArray[j] = dragArray[j+1];
			dragArray[dragArray.length-1] = dragObject;
			// starting a drag
			targetName = dragObject.name;
		}
	}
}
function mouseMove(e) {
	if (nn) {var x=e.pageX; var y=e.pageY;}
	if (ie) {var x=event.x; var y=event.y;}
	if (dragActive) {
		dragObject.moveTo(x-dragLayerX,y-dragLayerY);
		return false;
	}
}
function mouseUp(e) {
	if (nn) {var x=e.pageX; var y=e.pageY;}
	if (ie) {var x=event.x; var y=event.y;}
	dragActive = 0;
	// finishing a drag
	//alert (x + " " + y);
	targetX = x;
	targetY = y;
	//alert (targetName + targetX + targetY);
}

function dragDiv(id,nestref,drag) {
	if (nn) {
		if (nestref) {
			this.css = eval("document." + nestref + ".document." + id);
			this.ref = eval("document." + nestref + ".document." + id + ".document");
		}
		else {
			this.css = document.layers[id];
			this.ref = document.layers[id].document;
		}
		this.x = this.css.left;
		this.y = this.css.top;
		this.w = this.css.clip.width;
		this.h = this.css.clip.height;
	}
	else if (ie) {
		this.css = document.all[id].style;
		this.ref = document;
		this.x = this.css.pixelLeft;
		this.y = this.css.pixelTop;
		this.w = this.css.pixelWidth;
		this.h = this.css.pixelHeight;
	}
	this.obj = id + "Object";
	eval(this.obj + "=this;");
	this.name=id;

	this.moveBy = dragDivMoveBy;
	this.moveTo = dragDivMoveTo;
	this.show = dragDivShow;
	this.hide = dragDivHide;
	if (drag) {
		dragArray[dragArray.length] = this;
		dragLayerZ++;
	}
}
function dragDivMoveBy(x,y) {
	this.x += x;
	this.css.left = this.x;
	this.y += y;
	this.css.top = this.y;
}
function dragDivMoveTo(x,y) {
	this.x = x;
	this.css.left = this.x;
	this.y = y;
	this.css.top = this.y;
}
function dragDivShow() {
	if (nn) this.css.visibility = "show";
	else if (ie) this.css.visibility = "visible";
}
function dragDivHide() {
	if (nn) this.css.visibility = "hide";
	else if (ie) this.css.visibility = "hidden";
}