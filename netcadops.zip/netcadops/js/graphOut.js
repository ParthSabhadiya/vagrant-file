//           +-----------------------------------------------+
//           |                                               |
//           |               COPYRIGHT (c) 1990-2019         |
//           |                                               |
//           |       ABB Network Management SYSTEMS          |
//           |                                               |
//           |               All rights reserved             |
//           |                                               |
//           +-----------------------------------------------+
//  Java script file for project of replacing java applets with jquery
//  graphOut.js : Will draw graph for number of outages/calls over Time axis (day, hour, min)
//
//  Usage example:
/* 
<script src="/js/Chart.js/Chart.min.js"></script>
<script src="/js/graphOut.js"></script>
<body>
	<div style="width:80%;">
		<canvas id="canvas"></canvas>
	</div>
	<br>
		<button id="randomizeData">Randomize Data</button>
	<br>
	<br>
	<script>
		window.onload = function() {
			var ctx = document.getElementById('canvas').getContext('2d');
			labelsArr = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'some'];
			data1Arr = [ 21, 22, 23, 24, 25, 22, 23 ];
			data2Arr = [ 31, 32, 33, 34, 33, 32, 30 ];
			titleArr = ['My first dataset', 'My Second dataset'];
			colorArr = [ window.chartColors.blue, window.chartColors.red];
			header = "my chart header line";
			var config = initConfigVar(header, titleArr, labelsArr, data1Arr, data2Arr, colorArr);
			window.myLine = new Chart(ctx, config);
		};
	</script>
</body>
*/
//  
//  MODIFICATION HISTORY
//  001     02-Sep-2019  AV        B-168141 DMS 9.1.0.X_Ora122Java11 Netcadops Applet replacement with jquery
// -----------------------------------------------------------------------------

window.chartColors = {
	cyan: 'rgb(0, 255, 255)',
	magenta: 'rgb(255, 0, 255)',
	pink: 'rgb(255, 192, 203)',
	red: 'rgb(255, 99, 132)',
	orange: 'rgb(255, 159, 64)',
	yellow: 'rgb(255, 205, 86)',
	green: 'rgb(75, 192, 192)',
	blue: 'rgb(54, 162, 235)',
	purple: 'rgb(153, 102, 255)',
	grey: 'rgb(201, 203, 207)'
};

// Returns the chart context config variable
function initConfigVar(headline, titleArr, labelsArr, data1Arr, data2Arr, colorArr) {
    //alert("initConfigVar()  headline = " + headline);
	var config = {
		type: 'line',
		data: {
			labels: labelsArr,
			datasets: [{
				label: titleArr[0],
				fill: false,
				backgroundColor: window.chartColors.red,
				borderColor: window.chartColors.red,
				data: data1Arr,
			}, {
				label: titleArr[1],
				fill: false,
				backgroundColor: window.chartColors.blue,
				borderColor: window.chartColors.blue,
				data: data2Arr,
			}]
		},
		options: {
			responsive: true,
			title: {
				display: true,
				text: headline
			},
			tooltips: {
				mode: 'index',
				intersect: false,
			},
			hover: {
				mode: 'nearest',
				intersect: true
			},
			scales: {
				xAxes: [{
					display: true,
					scaleLabel: {
						display: true,
						labelString: 'Time'
					}
				}],
				yAxes: [{
					display: true,
					ticks: {
						beginAtZero: true
					},
					scaleLabel: {
						display: true,
						labelString: 'Value'
					}
				}]
			}
		}
	};

	return config;
}

// Returns the chart context config variable
function initConfigVar_2222sample(titleArr, labelsArr, data1Arr, data2Arr, colorArr) {
	//var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

	var config = {
		type: 'line',
		data: {
			labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
			datasets: [{
				label: 'My First dataset',
				backgroundColor: window.chartColors.red,
				borderColor: window.chartColors.red,
				data: [
					22,
					22,
					22,
					22,
					22,
					22,
					22
				],
				fill: false,
			}, {
				label: 'My Second dataset',
				fill: false,
				backgroundColor: window.chartColors.blue,
				borderColor: window.chartColors.blue,
				data: [
					33,
					33,
					33,
					33,
					33,
					33,
					33
				],
			}]
		},
		options: {
			responsive: true,
			title: {
				display: true,
				text: 'Chart.js Line Chart'
			},
			tooltips: {
				mode: 'index',
				intersect: false,
			},
			hover: {
				mode: 'nearest',
				intersect: true
			},
			scales: {
				xAxes: [{
					display: true,
					scaleLabel: {
						display: true,
						labelString: 'Month'
					}
				}],
				yAxes: [{
					display: true,
					ticks: {
						beginAtZero: true
					},
					scaleLabel: {
						display: true,
						labelString: 'Value'
					}
				}]
			}
		}
	};

	return config;
}
