function compare( crew_id, v_MessageArray, v_entered, index, maxValue, v_earlier, v_later, v_crew ){
   var Datedifference = 0;
   var v_index = 0;
   var Message = "";
   for ( v_index=0; v_index<=index-1;v_index++){
      if ( v_entered[ v_index ] != "" ){
         prevDateValue = v_entered[ v_index ];
         if ( prevDateValue != "" ){
            fromDate = new Date( prevDateValue );
            toDate = new Date( v_entered[ index] );
            Datedifference = toDate- fromDate ;
            if ( Datedifference < 0 ){
               Message = Message + v_MessageArray[ index ] + ": " + v_entered[ index ] +  " " + v_earlier + " " +
               v_MessageArray[ v_index ] + ": " + v_entered[ v_index ] + ". " + v_crew + " : " + crew_id + "\n";
               return Message;
            }
         }
      }
   }
   v_index = parseInt( index )+1;
   for ( v_index; v_index<=maxValue;v_index++){
      if ( v_entered[ v_index ] != "" ){
         prevDateValue = v_entered[ v_index ];
         if ( prevDateValue != "" ){
            fromDate = new Date( v_entered[ index] );
            toDate = new Date( prevDateValue );
            Datedifference = toDate- fromDate ;
            if ( Datedifference < 0 ){
               Message = Message + v_MessageArray[ v_index ] + ": " + v_entered[ v_index ] +  " " + v_earlier + " " +
               v_MessageArray[ index ] + ": " + v_entered[ index ] + ". " + v_crew + " : " + crew_id + "\n";
               return Message;
            }
         }
      }
   }
   return Message;
}


function crewTMValidate( crew_id,dateString, index, v_globalData, v_CrewMessageArr, v_earlier, v_later, v_crew ){
   var Message = "";
   var v_index = 0;
   var v_entered = dateString.split( "|" );
   var v_crewRead  = new Array();
   var v_readCount = 0;
   var v_tempIndex = 0;
   var v_MessageArray = new Array();
   var v_tempArray = new Array();
   var maxValue = 0;
   for ( v_index=0; v_index <= v_globalData.length-1; v_index++ ){
      if (  v_globalData[v_index][0]== crew_id ){
         v_crewRead[ v_readCount ] = v_globalData[v_index][1];
         v_readCount++;
      }
   }
   for ( v_index=0;v_index<=v_entered.length-1;v_index++){
      if ( v_entered[ v_index ] == "" ){
         if ( v_index != 1 )
            v_entered[ v_index ] = v_crewRead[ v_index ];
      }
   }
   v_MessageArray[0] = v_CrewMessageArr[0];
   v_MessageArray[1] = v_CrewMessageArr[2];
   v_MessageArray[2] = v_CrewMessageArr[3];
   v_MessageArray[3] = v_CrewMessageArr[4];
   v_tempArray[0] = v_entered[0];
   v_tempArray[1] = v_entered[2];
   v_tempArray[2] = v_entered[3];
   v_tempArray[3] = v_entered[4];
   if ( index < 5 ){
      if ( index != 1 ){
         v_tempIndex = index;
         if ( v_tempIndex > 1  )
            v_tempIndex--;
         maxValue = 3;
         Message = compare( crew_id, v_MessageArray, v_tempArray, v_tempIndex, maxValue, v_earlier, v_later, v_crew );
         if ( Message != "" )
            return Message;
      }
      if ( index < 3 ){
         v_tempIndex = index;
         if ( v_tempIndex == 2 )
            v_tempIndex = 1;
         else if ( v_tempIndex == 1 )
            v_tempIndex = 2;
         v_MessageArray = new Array();
         v_tempArray = new Array();
         v_MessageArray[0] = v_CrewMessageArr[0];
         v_MessageArray[1] = v_CrewMessageArr[2];
         v_MessageArray[2] = v_CrewMessageArr[1];
         v_tempArray[0] = v_entered[0];
         v_tempArray[1] = v_entered[2];
         v_tempArray[2] = v_entered[1];
         maxValue = 2;
         Message = compare( crew_id, v_MessageArray, v_tempArray, v_tempIndex, maxValue, v_earlier, v_later, v_crew );
         return Message;
      }
   }
   return Message;
}