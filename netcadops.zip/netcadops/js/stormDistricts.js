
// Called when the form buttons are clicked. Saves session ids by caling saveSessionIds at the beginnig.
function formSubmitted(form, all){
    saveSessionIds();

    var listIDs = "";
    var listNames = "";
    if ( all == 0 ){ // Few areas picked by user
       listIDs = getSelectedIds(treeSelector);
       listNames = getSelectedNames(treeSelector);
       console.log("listIDs = " + listIDs + " listNames = " + listNames);
       if ( listIDs == ""){
           alert( "You must select at least one item to proceed.");
           return;
       }
    }
    else  {  // ALL areas is picked by user
        listIDs = "||";
    }

    // Default formName is NetcMenu
    if ( top.hiddenFrame){
        var vURL = "NetcMenu.UpdateUserDistricts?p_districts=" + listIDs + '&p_session_id=' + p_session_id;
        var baseframeURL = "NetcMenu.WhoAmI?p_session_id=" + p_session_id ;
        var treeframeURL = "NetcMenu.MenuGen?p_session_id=" + p_session_id;
        top.treeframe.location.href=treeframeURL;
        top.hiddenframe.location.href=vURL;
        top.baseframe.location.href=baseframeURL;
    }
    else {
        var vURL = "NetcMenu.SetUser?p_districts=" + listIDs 
            + "&p_session_id=" 
            + p_session_id 
            + "&p_prev_sess_id=" +p_prev_sess_id 
            + "&p_timezone=" + encodeURIComponent(jstz.determine().name());
        document.location.href=vURL;
    }
}


var treeSelector = "#storm-districts-tree"
$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});


