

function createDataTableData(){
    var dataSet = [];

    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( name in rows ){
        if ( pattern.test(name)){
            // Set the first data to a button linked to outage detail
            var outageId = rows[name][2];
            rows[name][0] = "<input type='button' onclick='detailButtonClicked(event)' data-outage-id='" + outageId + "' class='detailBtn' value='...'/>";
            dataSet.push(rows[name]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}

function detailButtonClicked(ev){
    var sessionId = getUrlParameter("p_session_id")
    var outageId = $(ev.target).data("outage-id");
    window.location.href = "OutForms.OutSummaryFrame?p_session_id=" + sessionId + "&p_out_no=" + outageId + "&p_archive=N&p_storm=N";
}

$(document).ready(function(){
    var table = $("#outage-history-table").DataTable({
        columns: createDataTableColumns(),
        data: createDataTableData(),
        select: true,
        scrollX: true,
        scrollY: 500,
        "lengthMenu": [[20, 30, 40, 50, -1], [20, 30, 40, 50, "All"]],
        columnDefs: [
            { className: "tdbold", targets: "_all" }, // make all cells bold font
        ]
    });
});