function callUpdateXFMR(mesg1,mesg2,v_position) {
        var vlist="";
        var table = $("#cust-outage").DataTable();
        if (table.rows('.selected').data().length == 0)
        {
            alert(mesg1);
            return false;
        }
        var v_callType =table.rows('.selected').data()[0][2];
        if (v_callType == "NON-CUSTOMER") {
          alert(mesg2); 
          return false; 
        }
        var position  = parseInt( v_position )+1;
            for (var i = 0; i < table.rows('.selected').data().length; i++)
            {
               
                vlist=vlist + "|" + table.rows('.selected').data()[i][position];
            }
            var sessionId = getUrlParameter("p_session_id");
            var vURL="netcMgmt.CustomerTransformer?p_session_id="+ sessionId +"&p_account="+vlist;
        document.location.href=vURL;
        }

        function createDataTableData(){
            var dataSet = [];
            var rows =  getParamsWithPrefix("r");
            var pattern = /^r[0-9]+$/
            var length;
            for ( param in rows ){
                if ( pattern.test(param)){
                    length = rows[param].length;
                    var vURL = rows[param][length-2];
                    rows[param][0] = "<input type='button' onclick='detailButtonClicked(event)' data-vurl='" + vURL + "' class='detailBtn' value='...'/>";
                    dataSet.push(rows[param]);
                }
            }
            console.log( "Number of rows:" + dataSet.length);
            return dataSet;
        }
        
        function detailButtonClicked(ev){
            var vURL = $(ev.target).data("vurl");
            popWin(vURL, "netCADOPSpop", 990, 500);
           }
        function callLog(mesg1) {
            var table = $("#cust-outage").DataTable();
            if (table.rows('.selected').data().length == 0)
                {
                    alert(mesg1);
                    return false;
                }
                var sessionId = getUrlParameter("p_session_id");
                var outageNo = table.rows('.selected').data()[0][1];
                var vURL="netcOutageLog.wrapper?p_session_id="+ sessionId +"&p_outage_no="+outageNo+"&p_type=CUST";
                popWin(vURL,"netCADOPSpop",900,600);
            }