function createDataTableData(){
    var dataSet = [];

    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( param in rows ){
        if ( pattern.test(param)){
            // Set the first data to a button linked to outage detail
            var outageId = rows[param][2];
            rows[param][0] = "<input type='button' disabled class='detailBtn' value='...'/>";
            dataSet.push(rows[param]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}
