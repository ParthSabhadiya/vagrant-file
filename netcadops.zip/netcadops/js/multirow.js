//applyChange()
//Function to build the string of parameters for a multi-row form.
//Calls validateForm() and commitChange(), which need to be defined on the calling page.

function applyChange(form, change, no_fields, alerttext) {
var par_val="";
if (!validateForm(form, change)) return false;
if (change=="D") {
	for (var i=0; i<form.elements.length; i++) {
		if (form.elements[i].name.substring(0,5)=="chbox" && form.elements[i].checked && form.elements[i].value.length>0) {
			par_val=par_val+form.elements[i+1].value +"|" 
			}
		}
	if (par_val=="") {
                 if(arguments.length == 4) {
                    alert(alerttext); return;
                 } else {
                    alert("No rows have been selected for delete."); return;
                 }
	      }
	}
if (change=="U") {
	for (var i=0; i<form.elements.length; i++) {
		if (form.elements[i].name.substring(0,5)=="chbox" && form.elements[i].checked && form.elements[i].value.length>0) {
			//par_val=par_val+form.elements[i+1].value +"|"+ form.elements[i+2].value +"|";
			for (var j=1; j<no_fields+1; j++) {
				par_val=par_val+form.elements[i+j].value +"|";
				}
			}
		}
		if (par_val=="") {
                        if(arguments.length == 4) {
                          alert(alerttext); return;
                        } else {
                          alert("No rows have been selected for update."); return;
                        }
			}
	}
if (change=="I") {
	for (var i=0; i<form.elements.length; i++) {
		if (form.elements[i].name.substring(0,5)=="chbox" && form.elements[i].value.length==0 && form.elements[i+1].value != 0) {
			//par_val=par_val+form.elements[i+1].value +"|"+ form.elements[i+2].value +"|";
			for (var j=1; j<no_fields+1; j++) {
				par_val=par_val+form.elements[i+j].value +"|";
				}
			}
		}
		if (par_val=="") {
                        if(arguments.length == 4) {
                          alert(alerttext); return;
                        } else {
                          alert("No rows have been added for insert."); return;
                        }
			}
	}
commitChange(form, change, par_val);
}
