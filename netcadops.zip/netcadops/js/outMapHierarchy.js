//           +-----------------------------------------------+
//           |                                               |
//           |               COPYRIGHT (c) 1990-2019         |
//           |                                               |
//           |       ABB Network Management SYSTEMS          |
//           |                                               |
//           |               All rights reserved             |
//           |                                               |
//           +-----------------------------------------------+
//  Java script file for project of replacing java applets with jquery
//  MODIFICATION HISTORY
//  001     27-Aug-2019  AV        B-168141 DMS 9.1.0.X_Ora122Java11 Netcadops Applet replacement with jquery
// -----------------------------------------------------------------------------

var p_session_id;
var p_prev_sess_id;

function saveSessionIds() {
    if (p_prev_sess_id !== p_session_id) {
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id) {
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide();
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    }
    else {
        if (areasSelected == false) {
            sessionClose();
            return true;
        }
        else {
            return false;
        }
    }
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all) {
    saveSessionIds();

    areasSelected = true;

    var listIDs = "";
    var listNames = "";
    if (all == 0) { // Few areas picked by user
        listIDs = getSelectedIds();
        listNames = getSelectedNames();
        console.log("listIDs = " + listIDs + " listNames = " + listNames);
        if (listIDs == "") {
            alert("Please select at least one row.");
            return;
        }

		var ii = listIDs.split('|');
		if (ii.length > 1) {
			//listIDs = listIDs.replace(/\|/g, ","); // replace pipe with comma
			//listNames = listNames.replace(/\|/g, ","); // replace pipe with comma
            alert("Please select only one area.");
            return;
		}
    }
    else {  // ALL areas is picked by user
        listIDs = "||";
    }

    var vURL = "OutMapHierarchy.CallDistMap?p_session_id=" + p_session_id + "&p_dist_no=" + listIDs + "&p_dist_name=" + listNames;
    document.location.href = vURL;
}

function getSelectedIds() {
    var nodes = $("#tree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if (Array.isArray(nodes)) {
        nodes.forEach(function (node) {
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function getSelectedNames() {
    var nodes = $("#tree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if (Array.isArray(nodes)) {
        nodes.forEach(function (node) {
            ids.push(node.title);  // key is Id, title is name
        });
    }
    return ids.join("|");
}

$(document).ready(function () {
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo($('param').attr('VALUE'));
    $("#tree").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});
