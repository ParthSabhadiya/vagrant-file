

//  --htp.print( '<script language="JavaScript">');
//  -- function to get list of selected nodes
//  --htp.p( 'function getList(form, all) {' ||
//  --   'var v_rid2=""; var v_tree="TREE";' ||
//  --   'if (all==0) {' ||
//   --     'var v_rid2 = document.treeapplet.getSelectedItemIDs();' ||
//   --     '}' ||
//   -- else v_rid2 stays null
//   --  '' ||
//   --  'var vURL = "OutLstHierarchy.LowestLevelOutages?p_session_id='||p_session_id||chr(38)||'p_list="+escape(v_rid2)+"'||chr(38)||'p_page="+v_tree+"' || '";' ||
//   --  'document.location.href = vURL;' ||
//   --  '}' );

// Called when the form buttons are clicked. Saves session ids by caling saveSessionIds at the beginning.
function formSubmitted(form, all){
    saveSessionIds();

    var listIDs = "";
    var listNames = "";
    if ( all == 0 ){ // Few areas picked by user
       listIDs = getSelectedIds(treeSelector);
       listNames = getSelectedNames(treeSelector);
       console.log("listIDs = " + listIDs + " listNames = " + listNames);
       if ( listIDs == ""){
           alert( "You must select at least one item to proceed.");
           return;
       }
    }
    form.selAreaNo.value=listIDs;
    var vURL = "OutLstHierarchy.LowestLevelOutages?p_session_id=" + p_session_id + "&p_list=" +listIDs + "&p_page=TREE";
    document.location.href=vURL;
}


var treeSelector = "#outLst-hierarchy-tree"
$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});
