//CrewAct.js
//Functions to handle the Exclude option on the Crew Activity page and read
//crew activity data

//togChecked() Toggle the value of the check box Complete, Deassigned, Rejected
//input: form name, button name.
 function togChecked(fname, bname) {
	eval ("var val=document." + fname + "." + bname + ".value;");
	if (val=="C" || val=="D" || val=="R") {
		eval ("document." + fname + "." + bname + ".value='';");
	}
	else {
		eval("document." + fname + "." + bname + ".value='" + bname.substring(4,5) + "';");
	}
}
	
//savePref() Call OutFormsGlobal.UpdateCrewActPrefs
// target value is sent to UpdateCrewActPrefs to refresh the target page after the new
// prefs are saved in the database.  UpdateCrewActPrefs executes in the same document
// where crew activities are displayed.  This makes the crew activities page dissapear
// for a moment, then it reappears with new prefs being used.
// The target parameter is set initially on the page that displays the crew activity,
// and passed through OutFormsGlobal.DispCrewActButtons, then this javascript function to
// OutFormsGlobal.UpdateCrewActPrefs, which saves the prefs and refreshes the page specified
// in the target parameter.
function savePref(form, target, sessionID) {
	var val = form.exclC.value + form.exclR.value;
	var vURL="OutFormsGlobal.UpdateCrewActPrefs?p_session_id=" + sessionID +
                 "&p_val=" + val + "&p_url=" + target;
	document.location.href = vURL;
}

//Function to read the selected rows of crew activity data.
//optionsToList()
function optionsToList (form) {
	var listArr = new Array();
	var list = "";
	var j = 0;
	for (var i=0; i<form.length; i++) {
		if (form.elements[i].name.indexOf("chbox")>-1 && form.elements[i].checked) {
			listArr[j] = form.elements[i+2].value; j++; //crew activity id
			listArr[j] = form.elements[i+3].value; j++; //crew id
			listArr[j] = form.elements[i+4].options[form.elements[i+4].selectedIndex].value; j++; //status
			listArr[j] = form.elements[i+5].value; j++; //dates start at this line
			listArr[j] = form.elements[i+6].value; j++;
			listArr[j] = form.elements[i+7].value; j++;
			listArr[j] = form.elements[i+8].value; j++;
			listArr[j] = form.elements[i+9].value; j++;
			listArr[j] = form.elements[i+10].value; j++;
                        listArr[j] = form.elements[i+11].value; j++; //Deassigned Date
			listArr[j] = form.elements[i+12].value; j++; //12/11/02 SQL* Added Comments field.

	validateComments(form.elements[i+12].value, form, form.elements[i+12].name); //10/28/03 EK  Prevent | in comments.
		}
	}
	list = listArr.join("|");
	return(list);
}

//Function to validate comments: reserved character | not allowed
function validateComments(val, form, elem) {
   if (val.indexOf("|") > -1) {
      form.hiderror.value=form.name+"."+elem;
      }
   else {
      if (form.hiderror.value==form.name+"."+elem) form.hiderror.value="";
      }
}

