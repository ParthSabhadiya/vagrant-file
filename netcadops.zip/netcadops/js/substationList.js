function changeSubstation(change)
   {
    var sessionId = getUrlParameter("p_session_id");

    var vURL="", param="", paramall="";
    var ridAsString="", substationIdAsString="", substationNameAsString="", substationDistrictAsString="", substationBottomAsString="";
    var table = $("#substation-list").DataTable();


    if (change == "N")
    {
     vURL = "OutTables.NewSubstation?p_session_id="+ sessionId;
     popWin(vURL, "netCADOPSpop", 850, 530);
    }
    else
    {
     ridAsString = table.rows('.selected').data();
     
     if (ridAsString.length == 0)
     {
       alert("Please select a Substation from the list.");
       return;
     }
     
  
     //UpdateSubstation proc calls UpdateSubstationCont proc. So build the params as expected by UpdateSubstationCont proc.
     for (var i = 0; i < table.rows('.selected').data().length; i++) 
     {      
      substationIdAsString = table.rows('.selected').data()[i][1];
      paramall = paramall + substationIdAsString + "|"; 
      substationNameAsString = table.rows('.selected').data()[i][2];
      paramall = paramall + substationNameAsString + "|"; 
      substationDistrictAsString = table.rows('.selected').data()[i][3];
      paramall = paramall + substationDistrictAsString + "|";
      substationBottomAsString = table.rows('.selected').data()[i][4];
      paramall = paramall + substationBottomAsString + "|";
      
      param = param + substationIdAsString + "|";       
     }
     if (change == "U")      {
      vURL = "OutTables.UpdateSubstation?p_session_id="+ sessionId+"&p_par="+escape(paramall); 
      popWin(vURL, "netCADOPSpop", 850, 530);
     }
     else
     {
      vURL = "OutTables.ApplySubstation?p_par="+escape(param)+"&p_session_id="+ sessionId+"&p_act="+change; 
      document.location.href = vURL;
     }
    }
   };
