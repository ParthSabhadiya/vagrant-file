
function validateForm(form) {
    var beginDate = form.begin_date.value;
    var endDate = form.end_date.value;
    if( !beginDate || !endDate ){
        alert( "Begin or end date must be entered");
        if (!beginDate) form.begin_date.focous();
        else if (!endDate) form.end_date.focous();
        return false;
    }
    return true;
}

// Called when the form buttons are clicked. Saves session ids by caling saveSessionIds at the beginnig.
function formSubmitted(form, all){
    saveSessionIds();
    var listIDs = "";
    var listNames = "";

    if ( all == 0 ){ 
       listIDs = getSelectedIds(treeSelector);
       listNames = getSelectedNames(treeSelector);
       //console.log("listIDs = " + listIDs + " listNames = " + listNames);
       if ( listIDs == ""){
           alert( "You must select at least one item to proceed.");
           return;
       }
    }

    if ( validateForm(form)){
        var beginDate = form.begin_date.value;
        var endDate = form.end_date.value;
        var vUrl = "NetcHist.OutHistDetailTree?p_session_id=" + p_session_id 
        + "&p_beginDate=" + beginDate 
        + "&p_EndDate=" + endDate 
        + "&p_list=" + listIDs 
        + "&p_serv=" + v_pref_serv 
        + "&p_refr=" + v_pref_refr 
        + "&p_archive=" + p_archive;
        document.location.href = vUrl;
    }
}


var treeSelector = "#outage-history-tree"
$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

	});
});
