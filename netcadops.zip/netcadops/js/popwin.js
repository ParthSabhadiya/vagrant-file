//popWin
//Open a pop-up window
// (p_URL     in  varchar2,
// p_name     in  varchar2 default 'netCADOPSpop',
// p_width    in  number   default 600,
// p_height   in  number   default 400,
// p_centered in  char     default 'y',
// p_left     in  number   default 100,
// p_top      in  number   default 50)      

//var popwin;
var debug = 0;

// This function can take many args : arg1 = p_name, arg2 = width, arg3 = height, ... so on
function popWin(p_URL)
{
   //default values
   var argv = arguments;
   var argc = arguments.length;
   var p_name = (argc > 1) ? argv[1] : "netCADOPSpop";
   var p_width = (argc > 2) ? argv[2] : 600;
   var p_height = (argc > 3) ? argv[3] : 400;
   var p_centered = (argc > 4) ? argv[4] : "N";
   var p_left = (argc > 5) ? argv[5] : 5;
   var p_top = (argc > 6) ? argv[6] : 5;
   // The toolbar is ON because operator should be able to do back button
   var p_att = (argc > 7) ? argv[7] : "toolbar=yes,location=no,directories=no,status=no,menubar=no,resizable=yes,copyhistory=no";

   var xOffset = 100;
   var yOffset =  50;

   //calculate position
   if (p_centered == "Y")
   {

      var xMax = 640, yMax = 480;

      if (self.innerHeight) // all except Explorer
      {
         xMax = self.innerWidth;
         yMax = self.innerHeight;
      }
      else if (document.documentElement && document.documentElement.clientHeight)
            // Explorer 6 Strict Mode
      {
         xMax = document.documentElement.clientWidth;
         yMax = document.documentElement.clientHeight;
      }
      else if (document.body) // other Explorers
      {
         xMax = document.body.clientWidth;
         yMax = document.body.clientHeight;
      }

      xOffset = (xMax - p_width) / 2;
      yOffset = (yMax - p_height) / 2;
   }
   else
   {
      xOffset = p_left;
      yOffset = p_top;
   }   

   /* // stop renaming for now
   if (popWinGetSessionFrame())
   {
      p_name = p_name+popWinGetSessionFrame().popWinCount;
   }
   else
   {
      var now = new Date();
      p_name = p_name+ now.valueOf();
   }
   */
   //pop-up goes the window
   var popwin=window.open(p_URL,p_name,p_att + 
      ",top=" + yOffset + ",left=" + xOffset + ",width=" + p_width + 
      ",height=" + p_height + ",scrollbars=yes,resizable=yes");

   //   if (!popwin.opener) popwin.opener=self;

   //Register the popup window
   if (popWinGetSessionFrame()) {
      popWinGetSessionFrame().popWinArray[popWinGetSessionFrame().popWinCount] = popwin;
      popWinGetSessionFrame().popWinCount += 1;
   } else {
      return;
   }
}

function popWinGetSessionFrame() {

    if (top.sessionframe) {
      if (debug == 1) alert("1 LEVEL [popWinGetSessionFrame]");
      return top.sessionframe;
   } else if (top.opener) if (top.opener.sessionframe) {
      if (debug == 1) alert("2 LEVEL [popWinGetSessionFrame]");
      return top.opener.sessionframe;
   } else if (top.opener.top) if (top.opener.top.sessionframe) {
      if (debug == 1) alert("3 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.sessionframe;
   } else if (top.opener.top.opener) if (top.opener.top.opener.sessionframe) {
      if (debug == 1) alert("4 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.sessionframe;
   } else if (top.opener.top.opener.top) if (top.opener.top.opener.top.sessionframe) {
      if (debug == 1) alert("5 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.sessionframe;
   } else if (top.opener.top.opener.top.opener) if (top.opener.top.opener.top.opener.sessionframe) {
      if (debug == 1) alert("6 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.opener.sessionframe;
   } else if (top.opener.top.opener.top.opener.top) if (top.opener.top.opener.top.opener.top.sessionframe) {
      if (debug == 1) alert("7 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.opener.top.sessionframe;
   } else {
      if (debug == 1) alert("popWinGetSessionFrame - TOO MANY LEVELS");
      return null;
   }
}

function popWinGetValidationFrame() {

    if (top.validationframe) {
      if (debug == 1) alert("1 LEVEL [popWinGetSessionFrame]");
      return top.validationframe;
   } else if (top.opener) if (top.opener.validationframe) {
      if (debug == 1) alert("2 LEVEL [popWinGetSessionFrame]");
      return top.opener.validationframe;
   } else if (top.opener.top) if (top.opener.top.validationframe) {
      if (debug == 1) alert("3 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.validationframe;
   } else if (top.opener.top.opener) if (top.opener.top.opener.validationframe) {
      if (debug == 1) alert("4 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.validationframe;
   } else if (top.opener.top.opener.top) if (top.opener.top.opener.top.validationframe) {
      if (debug == 1) alert("5 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.validationframe;
   } else if (top.opener.top.opener.top.opener) if (top.opener.top.opener.top.opener.validationframe) {
      if (debug == 1) alert("6 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.opener.validationframe;
   } else if (top.opener.top.opener.top.opener.top) if (top.opener.top.opener.top.opener.top.validationframe) {
      if (debug == 1) alert("7 LEVEL [popWinGetSessionFrame]");
      return top.opener.top.opener.top.opener.top.validationframe;
   } else {
      if (debug == 1) alert("popWinGetSessionFrame - TOO MANY LEVELS");
      return null;
   }
}

// Run the given URL in background - cases where you want to execute a URL without redirecting to that url
function popWinBackground(p_URL)
{
	// Make Ajax request with URL
	//setTimeout(function() {
	//  location.href = p_URL;
	//}, 300);

	$.ajax({
		url: p_URL,
		cache: false,
		success:function(html)
		{
			alert("Data Processed successfully....");
		}
	});
}

