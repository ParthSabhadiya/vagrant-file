//Function to display Crew Info in the crew frame. The path to the crew frame depends on the
//	current page context, since it can be invoked from either list of employees for crew, or list
//	of employees for vehicle.

function callCrewInfo(form, but, crew_id, session_id, but_text, alert_text) {
	if (parent.crew) 
	{
		var vURL = "CrewMgmt.CrewInfo?p_session_id=" + session_id + "&p_id=" + escape(crew_id);
                if (arguments.length > 4) {
		      callURL(form, but, vURL, "parent.crew",but_text);
                } else {
                      callURL(form, but, vURL, "parent.crew","Working...");
                }
	}
	else 
	{ 
		if (parent.veh) 
		{
			var vURL = "CrewMgmt.AssembleContent?p_session_id=" + session_id + "&p_id=" + escape(crew_id);
                        if (arguments.length > 4) {
			     callURL(form, but, vURL, "parent",but_text);
                        } else {
                             callURL(form, but, vURL, "parent","Working...");
                        }
		} 
		else 
		{
                        if(arguments.length == 6) {
			     alert(alert_text); 
                        } else {
                             alert("Cannot find the frame PARENT.CREW.");
                        }
		}
	}
}



 function crewActivity() {
        var list="",crewAsString, crewid;
	   var table = $("#crewlist-table").DataTable();
        if (table.rows('.selected').data().length == 0)
    		{
     		 alert("Please select at least one row");
      		 return;
     	}
			
			for (var i = 0; i < table.rows('.selected').data().length; i++)
     	{
			crewAsString = table.rows('.selected').data()[i][1];
			crewid = table.rows('.selected').data()[i][2];
			list = list + crewid + "|"; 
     	}
	    list = list.substring(0, list.lastIndexOf("|"));
	    var sessionId = getUrlParameter("p_session_id");
         var vURL="StormCrew.CrewActUpdate?p_session_id="+ sessionId +"&p_list="+escape(list);

        var v_name_substr=vURL;
        vURL=""; 
        var v_name_tmp="";
        var v_pos=0; 
        while (v_pos!=-1) {
            v_pos=v_name_substr.indexOf("''");
            if (v_pos!=-1) { 
                     vURL=vURL+v_name_substr.substring(0,v_pos)+"\\''";
                     v_name_tmp=v_name_substr.substring(v_pos+1,v_name_substr.length);
                     v_name_substr=v_name_tmp; 
                     }
            } 
        vURL=vURL+v_name_substr;
         popWin(vURL, "netCADOPScrew" ,1100, 500);
        }

 function crewSuspend(trans_type,mesg1) {
       var list="", crewAsString, crewid;
       var vURL="";
	  var table = $("#crewlist-table").DataTable();
	  if (table.rows('.selected').data().length == 0)
		   {
          alert(mesg1);
          return;
       }
	   for (var i = 0; i < table.rows('.selected').data().length; i++)	    
		    {
			crewAsString = table.rows('.selected').data()[i][1];
			crewid = table.rows('.selected').data()[i][2];
			list = list + crewid + "|"; 
     	}

        list = list + "LIST";
		var sessionId = getUrlParameter("p_session_id");
        vURL="StormCrew.CheckCrewSuspend?p_session_id="+ sessionId +"&p_list="+escape(list)+"&p_trans="+trans_type;

       var v_name_substr=vURL;
       vURL="";
       var v_name_tmp="";
       var v_pos=0; 
       while (v_pos!=-1) { 
           v_pos=v_name_substr.indexOf("''"); 
           if (v_pos!=-1) { 
                    vURL=vURL+v_name_substr.substring(0,v_pos)+"\\''"; 
                    v_name_tmp=v_name_substr.substring(v_pos+1,v_name_substr.length);
                    v_name_substr=v_name_tmp;
                    } 
           } 
        vURL=vURL+v_name_substr;
        parent.hiddenframe.location.href=vURL;
	  }
	  
 function getCrewLog(mesg1) {
		var vID="",crewid;
		var table = $("#crewlist-table").DataTable();
	 	 if (table.rows('.selected').data().length == 0)
		{
			alert(mesg1);
          	return false;
		  }
			if (table.rows('.selected').data().length>1) 
			{
			   alert(mesg1);
			   return false;
			}
	    
		  for (var i=0; i<table.rows('.selected').data().length; i++) 
		  {
			crewid = table.rows('.selected').data()[i][1]; // crew id in field 1
		  }
          vID=crewid;
		if (vID=="") return false;
		var sessionId = getUrlParameter("p_session_id");		
		var vURL = "netccrewlog.ViewLog?p_session_id="+ sessionId +"&p_crew_id="+escape(vID);
          var v_name_substr=vURL;
          vURL = "";
          var v_name_tmp=""; 
          var v_pos=0;
          while (v_pos!=-1) { 
              v_pos=v_name_substr.indexOf("''");
              if (v_pos!=-1) { 
                       vURL=vURL+v_name_substr.substring(0,v_pos)+"\\''"; 
                       v_name_tmp=v_name_substr.substring(v_pos+1,v_name_substr.length);
                       v_name_substr=v_name_tmp; 
                       } 
              }
          vURL=vURL+v_name_substr;
         

         
          popWin(vURL,"netCADOPSPop", 1000, 600, "Y", 10, 10, "toolbar=no,location=no,directories=no,status=no,menubar=no" );
          }

