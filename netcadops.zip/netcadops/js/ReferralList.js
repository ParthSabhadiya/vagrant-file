
function getColumnNames(){
    var columns = []
    var params =  getParamsWithPrefix("field");

    for( param in params ){
        if ( param == "fields") continue;
        columns.push(params[param][0]);
    }
   return columns;
}

function getNumberOfDisplayedColumns(){
    var count = $("PARAM[name=display_fields]").attr("value");
    return parseInt(count);
}

function createDataTableColumns(){
    // Get the columns listed in page data
    var names = getColumnNames();

    // Get the number of displayed columns and display only first count columns
    var count = getNumberOfDisplayedColumns();
    if ( names.length > count ){
        names = names.slice(0, count);
    }
    
    // get link button column name and add it as the first column
    names.splice( 0, 0, $("PARAM[name=link_button]").attr("value") );

    var columns = [];
    for( var i = 0; i < names.length; i++ ){
        columns.push({
            title: names[i]
        });
    }
    console.log( "Number of columns:" + columns.length);
    return columns;
}

function createDataTableData(){
    var dataSet = [];
    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( param in rows ){
        if ( pattern.test(param)){
            var vURL = rows[param][13];
            rows[param][0] = "<input type='button' onclick='detailButtonClicked(event)' data-vurl='" + vURL + "' class='detailBtn' value='...'/>";
            dataSet.push(rows[param]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}

function detailButtonClicked(ev){
    var vURL = $(ev.target).data("vurl");
    popWin(vURL, "netCADOPSpop", 990, 500);
   }