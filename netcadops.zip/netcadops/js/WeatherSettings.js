 
var p_session_id;
var p_prev_sess_id;

function saveSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function getSelectedIds(){
    var nodes = $("#weathersettings").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

     function filter(mesg1)
     {
         var vURL = "";
         var length = "";
         var v_cnt = "1";
         var areaList ="";
         var v_elementId = parent.OpCenFrame.lastFocus;
         var v_transType ="I";
         var areaListArr =new Array();
         var v_prvSubAreaId ="";
         areaList = $("#weathersettings").fancytree("getTree").getSelectedNodes();
                if (areaList.length == 0)
                {
                   alert(mesg1);
                   return;
                 }
                 else
                 {
                    length = parent.OpCenFrame.frmOpCent.elements.length;
                
                   length = length/5;
                    for (var cnt=0; cnt < length;cnt++)
                    {
                         v_cnt = (cnt*5)+1;
                         for(var c=0; c<areaList.length; c++){
                               if(parent.OpCenFrame.frmOpCent.elements[v_cnt].value == areaList[c].key){
                               parent.OpCenFrame.addArray(parent.OpCenFrame.frmOpCent,
                               v_cnt-1,parent.OpCenFrame.frmOpCent.elements[v_cnt].value,
                               parent.OpCenFrame.frmOpCent.elements[v_cnt+1].value,
                               parent.OpCenFrame.frmOpCent.elements[v_cnt+2].value,
                               parent.OpCenFrame.frmOpCent.elements[v_cnt+3].value);
                               }
                         }
                    }
                 }
     }


$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $("#weathersettings").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});

 
