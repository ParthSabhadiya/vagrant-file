
var p_session_id;
var p_prev_sess_id;

function saveSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    } 
    else { 
        if (areasSelected==false) {
            sessionClose();
            return true; 
        } 
        else {
            return false;
        }
    }
}

function getSelectedIds(){
    var nodes = $("#system-messages").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function filter(mesg1,mesg2)
          {
               var vURL = "";
               var areaList ="";
               var v_elementId = parent.SysMsgFrame.lastFocus;
               var v_transType ="I";
               var areaListArr =new Array();
               var appletIndexFEEDER     = 11;
               var appletIndexSUBSTATION = 9;
               var appletIndexCREWAREA   = 7;
               var appletIndexSUBREGION  = 5;
               var appletIndexREGION     = 3;
               var appletIndexSYSTEM     = 1;
               var frmIndexMSGLEVEL      = 1;
               var frmIndexMSGLEVELID    = 2;
               var frmIndexSUBAREAID     = 3;
               var frmIndexREGION        = 4;
               var frmIndexSUBREGION     = 5;
               var frmIndexCREWAREA      = 6;
               var frmIndexSUBSTATION    = 7;
               var frmIndexFEEDER        = 8;
               var frmIndexSYSMSGCODE    = 9;
               var frmIndexSYSMSGTEXT    = 10;

               var v_prvSubAreaId ="";
               
               if (parent.SysMsgFrame.lastFocus!=-1) {
               areaList = $("#system-messages").fancytree("getTree").getSelectedNodes();
               if (areaList.length == 0) 
               {
                  alert(mesg1);
                  return;
               }
               if (areaList.length >1) 
               {
                  alert(mesg2);
                  return;
               }
               else
               {
              
              // areaListArr=areaList.split("|");
               var v_msg_level=0;
             var level=  $("#system-messages").fancytree("getTree").getSelectedNodes()[0].data.level;
             level=level.substring(1);
             var levelInt = parseInt(level, 10);
            
            var selectedNode=$("#system-messages").fancytree("getTree").getSelectedNodes()[0];
            var counter=levelInt-1;
            while(selectedNode.parent!=null)
            {
                areaListArr[counter]=selectedNode.title;
                selectedNode=selectedNode.parent;
                counter= counter-1;
            }

             levelInt=(levelInt*2)+1;
   
              var v_msg_level_name;
            
              switch (levelInt-2)
              {
                case appletIndexFEEDER:
                  v_msg_level_name= "FEEDER";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[5].substring(0,areaListArr[5].indexOf("-"));  
                  break;
                case appletIndexSUBSTATION:
                  v_msg_level_name= "SUBSTATION";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[4].substring(0,areaListArr[4].indexOf("-"));
                  break;
                case appletIndexCREWAREA:
                  v_msg_level_name= "CREWAREA";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[3].substring(0,areaListArr[3].indexOf("-"));  
                  break;
                case appletIndexSUBREGION:
                  v_msg_level_name= "SUBREGION";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[2].substring(0,areaListArr[2].indexOf("-"));  
                  break;
                case appletIndexREGION:
                  v_msg_level_name= "REGION";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[1].substring(0,areaListArr[1].indexOf("-"));  
                  break;
                default:
                  v_msg_level_name= "SYSTEM";
                  parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value=
                  areaListArr[0].substring(0,areaListArr[0].indexOf("-"));  
              } 

               if (!parent.SysMsgFrame.frmSysMsg.elements[v_elementId+1].value){
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId].checked=true;  
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSYSMSGCODE].focus();
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVEL].value = v_msg_level_name;

                 if (areaListArr[1]!=null)
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexREGION].value=
                 areaListArr[1].substring(areaListArr[1].indexOf("-")+1);

                 if (areaListArr[2]!=null)
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSUBREGION].value=
                 areaListArr[2].substring(areaListArr[2].indexOf("-")+1);

                if (areaListArr[3]!=null)
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexCREWAREA].value=
                 areaListArr[3].substring(areaListArr[3].indexOf("-")+1);

                if (areaListArr[4]!=null)
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSUBSTATION].value=
                 areaListArr[4].substring(areaListArr[4].indexOf("-")+1);

                if (areaListArr[5]!=null)
                 parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexFEEDER].value=
                 areaListArr[5].substring(areaListArr[5].indexOf("-")+1);

                 parent.SysMsgFrame.addArray( parent.SysMsgFrame.frmSysMsg,v_elementId,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVEL].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexMSGLEVELID].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSUBAREAID].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexREGION].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSUBREGION].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexCREWAREA].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSUBSTATION].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexFEEDER].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSYSMSGCODE].value,
                    parent.SysMsgFrame.frmSysMsg.elements[v_elementId+frmIndexSYSMSGTEXT].value
                    );
              }
          }
        }
      }


var treeSelector = "#system-messages"
$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});

