
function getColumnNames(){
    var columns = []
    var params =  getParamsWithPrefix("field");

    for( param in params ){
        if ( param == "fields") continue;
        columns.push(params[param][0]);
    }
   return columns;
}

function getNumberOfDisplayedColumns(){
    var count = $("PARAM[name=display_fields]").attr("value");
    return parseInt(count);
}

function createDataTableColumns(){
    // Get the columns listed in page data
    var names = getColumnNames();

    // Get the number of displayed columns and display only first count columns
    var count = getNumberOfDisplayedColumns();
    if ( names.length > count ){
        names = names.slice(0, count);
    }
    
    // get link button column name and add it as the first column
    names.splice( 0, 0, $("PARAM[name=link_button]").attr("value") );

    var columns = [];
    for( var i = 0; i < names.length; i++ ){
        columns.push({
            title: names[i]
        });
    }
    console.log( "Number of columns:" + columns.length);
    return columns;
}

function createDataTableData(){
    var dataSet = [];
    var count = getNumberOfDisplayedColumns();

    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( param in rows ){
        if ( pattern.test(param)){
            var url = rows[param][count + 1];
            rows[param][0] = "<input type='button' onclick='detailButtonClicked(event)'  data-url='" + url + "'  class='detailBtn' value='...'/>";
            dataSet.push(rows[param]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}

function detailButtonClicked(ev){
    var url = $(ev.target).data("url");
         window.location.href = url;

}

function reloadIt() {
    document.location = document.location;
}

// --Function to refresh lists(called from JavaScript functions LibJS.FreezeFun).
function refreshPage() {
    var g_refresh = parseInt($("#g_refresh").attr("value"));
    if (isNaN(g_refresh) || g_refresh < 1) {
        g_refresh = 5;
    }

     timerID = setTimeout("refreshPage()", g_refresh * 1000 );
     timerRunning = true;
     reloadIt();
}


$(document).ready(function(){
    var table = $("#outage-history-table").DataTable({
        columns: createDataTableColumns(),
        data: createDataTableData(),
        select: true,
        scrollX: true,
        scrollY: 500,
        "lengthMenu": [[20, 30, 40, 50, -1], [20, 30, 40, 50, "All"]],
        columnDefs: [
            { className: "tdbold", targets: "_all" }, // make all cells bold font - all table td elements
        ]
    });

$("#toggle-vis").on( 'click', function (e) {
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
        // Toggle the visibility
        column.visible( ! column.visible() );
    } )
});
