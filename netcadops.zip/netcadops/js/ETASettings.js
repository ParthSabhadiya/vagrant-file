
var p_session_id;
var p_prev_sess_id;

function saveSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    } 
    else { 
        if (areasSelected==false) {
            sessionClose();
            return true; 
        } 
        else {
            return false;
        }
    }
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all){
    saveSessionIds();

    areasSelected = true;

    var listIDs = "";
    if ( all == 0 ){
       listIDs = getSelectedIds();
       console.log(listIDs);
       if ( listIDs == ""){
           alert( "'" + txt_trans(908) + "'");
           return;
       }
    }
    else  {
        listIDs = "||";
    }

    if ( top.hiddenFrame){
        var vURL = "NetcMenu.UpdateUserDistricts?p_districts=" + listIDs + '&p_session_id=' + p_session_id;
        var baseframeURL = "NetcMenu.WhoAmI?p_session_id=" + p_session_id ;
        var treeframeURL = "NetcMenu.MenuGen?p_session_id=" + p_session_id;
        top.treeframe.location.href=treeframeURL;
        top.hiddenframe.location.href=vURL;
        top.baseframe.location.href=baseframeURL;
    }
    else {
        var vURL = "NetcMenu.SetUser?p_districts=" + listIDs 
            + "&p_session_id=" + p_session_id 
            + "&p_prev_sess_id=" + p_prev_sess_id
            + "&p_timezone=" + encodeURIComponent(jstz.determine().name());
        document.location.href=vURL;
    }
}

function getSelectedIds(){
    var nodes = $("#etasettings").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}


function etaLookUpRecord(p_element_id,p_subAreaCallTypeId, p_disableETA, p_defaultETAHr,p_subAreaId,p_subAreaName,p_calltypeId,p_calltypeName)
      {
        this.element_id= p_element_id;
        this.subAreaCallTypeId= p_subAreaCallTypeId;
        this.disableETA= p_disableETA;
        this.defaultETAHr = p_defaultETAHr;
        this.subAreaId = p_subAreaId;
        this.subAreaName = p_subAreaName;
        this.calltypeId = p_calltypeId;
        this.calltypeName = p_calltypeName;
     }


   function filter(form)
          {
            var areaListArr =new Array();
            var areaList ="";
            areaList = $("#etasettings").fancytree("getTree").getSelectedNodes();
            if (areaList.length == 0)
            {
              alert(form[0].value);
              return;
            }
            else
            {
              for (var i in areaList) {
                  for (var j in etaLookUpArray) {
                    if (etaLookUpArray[j].subAreaId == areaList[i].key) {
                      parent.ETAFrame.frmETASysPref.elements[etaLookUpArray[j].element_id].checked =true;
                      var v_element_id = etaLookUpArray[j].element_id;
                      parent.ETAFrame.addArray( parent.ETAFrame.frmETASysPref,etaLookUpArray[j].element_id,
                      etaLookUpArray[j].subAreaCallTypeId, eval("parent.ETAFrame.frmETASysPref.disableETA"+v_element_id+".value"),
                      eval("parent.ETAFrame.frmETASysPref.defaultETAhr"+v_element_id+".value"),
                      etaLookUpArray[j].subAreaId,etaLookUpArray[j].subAreaName,etaLookUpArray[j].calltypeId,
                      etaLookUpArray[j].calltypeName );
                  }
                }
              }
            }
          }

$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $("#etasettings").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }
	});
});
