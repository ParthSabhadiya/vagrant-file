//MultiSelect
//Insert a list of selected options values and text separated by the
//separator character,
//into form fields specified in arguments (second and third argument).
//If the forth argument is specified it contains the separator character.
//The default for the separator character is "|".
//Also returns selected options values in the return variable.

function MultiSelect(SelectObject) {
	var argv = MultiSelect.arguments;
	var argc = MultiSelect.arguments.length;  	
	var p_fieldValues = (argc > 1) ? argv[1] : null;  	
	var p_fieldText = (argc > 2) ? argv[2] : null;
	var p_sep = (argc > 3) ? argv[3] : "|";

	var listValues = "";
	var listText = "";
	for (var i=0; i<SelectObject.length; i++)
	{
		if (SelectObject.options[i].selected)
		{	
			listValues += p_sep + SelectObject.options[i].value;
			listText += p_sep + SelectObject.options[i].text;
		}
	}
	listValues = listValues.substring(1, listValues.length);
	listText = listText.substring(1, listText.length);

	if (p_fieldValues != null) eval(p_fieldValues + ".value = '" + listValues + "';");
	if (p_fieldText != null) eval(p_fieldText + ".value = '" + listText + "';");
	
	return(listValues);
}
