
// 10/03/02 JH: Used by NetcApplet package vec is an array of objects
function Quicksort(vec, loBound, hiBound) {
    var pivot, loSwap, hiSwap, temp;
    // Two items to sort
    if (hiBound - loBound == 1) {
    	if (vec[loBound].column_order > vec[hiBound].column_order) {
	    temp = vec[loBound];
	    vec[loBound] = vec[hiBound];
	    vec[hiBound] = temp;
	}
	return vec;
    }

    // Three or more items to sort
    pivot = vec[parseInt((loBound + hiBound) / 2)];
    vec[parseInt((loBound + hiBound) / 2)] = vec[loBound];
    vec[loBound] = pivot;
    loSwap = loBound + 1;
    hiSwap = hiBound;
    do {
    	// Find the right loSwap
	while (loSwap <= hiSwap && vec[loSwap].column_order <= pivot.column_order) 
	    loSwap++;
                   

	// Find the right hiSwap
	while (vec[hiSwap].column_order > pivot.column_order)
	    hiSwap--;

	// Swap values if loSwap is less than hiSwap
	if (loSwap < hiSwap) {
	    temp = vec[loSwap];
	    vec[loSwap] = vec[hiSwap];
	    vec[hiSwap] = temp;
	}
    } while (loSwap < hiSwap);

    vec[loBound] = vec[hiSwap];
    vec[hiSwap] = pivot;

    // Recursively call function
    if (loBound < hiSwap - 1) {
    	Quicksort(vec, loBound, hiSwap - 1);
    }

    if (hiSwap + 1 < hiBound) {
	Quicksort(vec, hiSwap + 1, hiBound);
    }
}
