// in csr:non-customer-calls:Assign to outage button
function assignToOutage(mesg1,mesg2,v_position,v_subArea) 
{
	var v_subarea=""; var pnolist="",pno="";
	var v_tree="TREE"; 
	var table = $("#non-cust-table").DataTable();
	//var tableColumnIndex;
	//tableColumnIndex['Device ID'] = table.column('Device ID').index();
	//tableColumnIndex['Report No'] = table.column('Report No').index();

	var sel_ob = table.rows('.selected').data();

	if (sel_ob.length == 0) {
		alert(mesg1); // Please select atleast one row
		return false;
	}

	v_position = parseInt(v_position);
	// Number.isInteger is not supported in MSIE, hence use the validations.js: isInteger
	if (!isInteger(v_position)) {
		alert('Arg v_position not an integer');
		return false;
	}

	for (var ii = 0; ii < sel_ob.length; ii++) {
		if (sel_ob[ii][v_position+1] != "") {  // column 'Device ID'
			alert(mesg2); // This call is assigned to a device.  Cannot assign to an outage.
			return;
		}
		pno = table.rows('.selected').data()[ii][1];
		pnolist =  pnolist + "|" + pno;
	}

	pnolist = pnolist.substring(1, pnolist.length);
	var sessionId = getUrlParameter("p_session_id");
	var vURL = "OutLstHierarchy.LowestLevelOutages?p_session_id="+ sessionId +"&p_list="+escape(v_subarea)+"&p_page="+v_tree+"&p_problem_no="+pnolist;

	popWin(vURL,"netCADOPSpop",1100,690,"Y",10,10,"menubar=0,scrollbars=1,titlebar=1,resizable=1" ); 
}

function DeAssign(mesg1,mesg2,v_position_deassign) 
{
	var doRefresh=0; var pnolist=""; varpURL="";
	var table = $("#non-cust-table").DataTable();
	if (table.rows('.selected').data().length == 0)
	{
	 alert(mesg1);
	 return false;
	}
	for (var i = 0; i < table.rows('.selected').data().length; i++)
	{
	if (table.rows('.selected').data()[i][v_position_deassign]!="") { 
	  doRefresh = 1;
		}
		else{
		  alert(mesg2); 
		  return;
		  
		}
	pno = table.rows('.selected').data()[i][1];
	pnolist =  pnolist + "|" + pno;
	}

	pnolist = pnolist.substring(1, pnolist.length);
	var sessionId = getUrlParameter("p_session_id");
	var outageNo = table.rows('.selected').data()[0][14];
	pURL="OutLists.NonCust?p_status=UNRESOLVED"+"&p_write=Y"+"&p_session_id="+ sessionId;
	if (outageNo="") pURL="OutLists.NonCust?p_out_no="+outageNo+"&p_write=Y"+"&p_session_id="+ sessionId;
	if ( doRefresh == 1 ){ 
	 var vURL = "OutLists.DeAssignOutage?p_problem_no="+escape(pnolist)+"&p_url="+escape(pURL)+"&p_session_id="+ sessionId;
	 document.location.href = vURL;
	}
}

function callLog(mesg1) {
var table = $("#non-cust-table").DataTable();
if (table.rows('.selected').data().length != 1)
    {
        alert(mesg1);
        return false;
    }
    var sessionId = getUrlParameter("p_session_id");
    var outageNo = table.rows('.selected').data()[0][1];
    var vURL="netcOutageLog.wrapper?p_session_id="+ sessionId +"&p_outage_no="+outageNo+"&p_type=NONCUST";
    popWin(vURL,"netCADOPSpop",900,600);
    }
    
