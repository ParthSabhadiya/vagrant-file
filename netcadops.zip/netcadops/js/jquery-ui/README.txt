Version of JQueryUI is : JqueryUI 1.12.1

The JqueryUI needs the jquery library.
This library is built on top of Jquery.

https://jqueryui.com

https://github.com/jquery/jquery-ui

