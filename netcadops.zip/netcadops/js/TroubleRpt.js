function callLog(mesg1) {
var table = $("#trouble-rpt-table").DataTable();
if (table.rows('.selected').data().length != 1)
		{
			alert(mesg1);
          	return false;
    }
var sessionId = getUrlParameter("p_session_id");
var outageNo = table.rows('.selected').data()[0][1];
var vURL="netcOutageLog.wrapper?p_session_id=" + sessionId +"&p_outage_no="+outageNo+"&p_type=CUST";
popWin(vURL,"netCADOPSpop",900,600);
}