
var areasSelected = false
var v_PrevSessID = null;
var p_archive;
var v_tree = "TREE";

function addOption(selectObject, val, text) {
   for (var i=0; i<selectObject.length; i++) {
      if (selectObject.options[i].value.length == 0) {
         count = i;
         break;
         }
      }
      selectObject.options[count].value = val;
      selectObject.options[count].text = text;
   }

 function removeOptions (SelectObject) { 
    for (var i=0; i<SelectObject.length; i++)
      {
       if (SelectObject.options[i].selected)
         {
         SelectObject.options[i].value = "";
         SelectObject.options[i].text = " ";
         }
      }
  }

 function addOptions(SelectObject) {
    var arrID=new Array();  var arrNames=new Array();
    //selRows();
    listID=getSelectedIds();
    listNames=  getSelectedNames();
    if(listID.lastIndexOf("|") >0)
    {
    arrID = listID.split("|");
    }
    else
    {
            arrID[0] = listID;
    }
    if(listNames.lastIndexOf("|") >0)
    {
    arrNames = listNames.split("|");
    }
    
    else
    {
            arrNames[0] = listNames;
    }
    for (var i = 0; i < arrID.length; i++) {
       addOption(SelectObject, arrID[i], arrNames[i]);
       }
  }

function getSelectedIds(){
    var nodes = $("#stormareatree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function getSelectedNames(){
    var nodes = $("#stormareatree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.title);
        });
    }
    return ids.join("|");
}



function parseNodeOnfo(nodeStr){
    var nodesInfo = nodeStr.split("|");
    var noOfNodes = nodesInfo.length/3;

    var currentParentByLevel = {};
    var data = [];
    for ( var i = 0; i < noOfNodes; i++){
        var level = nodesInfo[3*i];
        var intLevel = parseInt(level.substring(1));
        var id = nodesInfo[3*i+1];
        var name = nodesInfo[3*i+2];
        var node = {
            title: name,
            key: id,
            level: level,
            children: [],
        };
        if ( intLevel <= 2) node.expanded = true;
        currentParentByLevel[intLevel] = node;
        if ( intLevel == 1 ){
            data.push(node);
            node.folder = true;
        }
        else {
            var currentParent = currentParentByLevel[intLevel-1];
            if (currentParent){
                currentParent.children.push(node);
                currentParent.folder = true;
            }
        }
    }
    return data;
}


$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseNodeOnfo( $('param').attr('value') );
    $("#stormareatree").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});
