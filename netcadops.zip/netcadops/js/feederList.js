function changeFeeder(change)
   {
    var sessionId = getUrlParameter("p_session_id");

    var vURL="", param="", paramall="";
    var ridAsString="", feederIdAsString="", feederNameAsString="", feederSourceAsString="", feederSiteAsString="", feederFirstNodeAsString="", feederFirstLineAsString="";
    var table = $("#feeder-list").DataTable();


    if (change == "N")
    {
     vURL = "OutTables.NewFeeder?p_session_id="+ sessionId;
     popWin(vURL, "netCADOPSpop", 850, 530);
    }
    else
    {
     ridAsString = table.rows('.selected').data();
     
     if (ridAsString.length == 0)
     {
       alert("Please select a Feeder from the list.");
       return;
     }
     
  
     //Update Feeder proc calls UpdateFeederCont proc. So build the params as expected by UpdateFeederCont proc.
     for (var i = 0; i < table.rows('.selected').data().length; i++) 
     {
      
      feederIdAsString = table.rows('.selected').data()[i][1];
      paramall = paramall + feederIdAsString + "|"; 
      feederNameAsString = table.rows('.selected').data()[i][2];
      paramall = paramall + feederNameAsString + "|"; 
      feederSourceAsString = table.rows('.selected').data()[i][3];
      paramall = paramall + feederSourceAsString + "|";
      feederSiteAsString = table.rows('.selected').data()[i][4];
      paramall = paramall + feederSiteAsString + "|"; 
      feederFirstNodeAsString = table.rows('.selected').data()[i][5];
      paramall = paramall + feederFirstNodeAsString + "|"; 
      feederFirstLineAsString = table.rows('.selected').data()[i][6];
      paramall = paramall + feederFirstLineAsString + "|"; 
      feederTotalAcctsAsString = table.rows('.selected').data()[i][7];
      paramall = paramall + feederTotalAcctsAsString + "|"; 
      feederFirstNodeIdAsString = table.rows('.selected').data()[i][8];
      paramall = paramall + feederFirstNodeIdAsString + "|"; 
      feederFirstLineIdAsString = table.rows('.selected').data()[i][9];
      paramall = paramall + feederFirstLineIdAsString + "|"; 
      

      param = param + feederIdAsString + "|";
       
     }
     if (change == "U")      {
      vURL = "OutTables.UpdateFeeder?p_session_id="+ sessionId+"&p_par="+escape(paramall); 
      popWin(vURL, "netCADOPSpop", 850, 530);
     }
     else
     {
      vURL = "OutTables.ApplyFeeder?p_par="+escape(param)+"&p_act="+change+"&p_session_id="+ sessionId; 
      document.location.href = vURL;
     }
    }
   };
