function filter(to_field_id, to_field_name,mesg1) {
	var vURL = "";
	var areaList ="";
	var winop = "";
	var areaListArr = new Array();
	areaList = $("#sub_area").fancytree("getTree").getSelectedNodes();

	if (areaList.length == 0) {
		alert(mesg1);
		return;
	}

	if (window.opener) {
		winop = "window.opener.";
	}

	// check if the opener window's to_field_id is existing
	if (eval(winop+to_field_id) != null) {
		eval(winop+to_field_id+".value=" + 'areaList[0].key'+";");
		eval(winop+to_field_name+".value=" + 'areaList[0].title'+";");
	}

	if (window.opener) 
		self.close();
}

$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );

	// In case of csr:CallEntry:TR:sub area lookup icon
	var sel_ob = $("#sub_area");
	if (sel_ob.length > 0) { // The selector had found any element in the html doc matching
		sel_ob.fancytree({
			source: treeData,
			checkbox: true,
			selectMode: 2,
			autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
			activeVisible: false, // Make sure, active nodes are visible (expanded)
			icon: false, // Display node icons
			click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
				if (data.targetType === 'title') {
					data.node.toggleSelected();
				}
			}
		});
	}

});
