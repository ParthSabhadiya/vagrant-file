function showHide(elem, state)
{
   var visible = (document.getElementById ? 'visible' : 'show' );
   var hidden = (document.getElementById ? 'hidden' : 'hide');
   var daElem;

   if (document.getElementById)
   {
      daElem = document.getElementById(elem).style;
   }
   else if (document.layers)
   {
      daElem = document.layers[elem];
   }
   if ("show"==state)
   {
      daElem.visibility = visible;
      daElem.zIndex=5;
   }
   else
   {
      daElem.visibility = hidden;
      daElem.zIndex=0;
   }
}

document.showHide = showHide;

