
// File: formsgen.js - Used in formsgen.pkb
// Author: usalvas 29 Jul 2020
//
// 29-Jul-2020 AV	Bug 130339 NETCADOPS ADM_AUTHORIZE delete on SUB_AREA with turkish characters

// DS Global variable to store rows updated
var clicked = "";

// DS Function to update clicked global var when changes are made to a rowj
function updateClicked(row) {
	var row_val = row + "";
	var found = false;
	var arr = new Array();
	if (clicked.length > 0)
		arr = clicked.split("|");
	for (var i = 0; i < arr.length && !found; i++) {
		found = (arr[i] == row_val);
	}
	if (!found)
		clicked = clicked + "|" + row_val;
}

// Function to Commit the changes, called from applyChange()
function commitChange(form, change, param, where, p_session_id, p_tab, p_group) {
	//alert('commitChange() change = ' + change + ' param = ' + param + ' where = ' + where + ' p_session_id = ' + p_session_id + ' p_tab = ' + p_tab + ' p_group = ' + p_group);

	var vURL = "FormsGen.ApplyRecord?p_session_id=" + p_session_id + "&p_tab=" + p_tab + "&p_group=" + p_group + "&p_vals="
			+ escape(param) + "&p_act=" + change + "&p_wh=" + escape(where);
	callURL(form, "butApply", vURL);
}

// Updated apply function to use new clicked variable which tracks updated rows
// Now function only iterates through rows that have been updated and not all the fields as before 
// Validation is now also handled within this function.
function applyChange(form, change, no_fields, button, trans_511, trans_11, p_session_id, p_tab, p_group) {
	var par_val = "";
	var par_wh = "";
	var chsel = 0;
	var rowArr = new Array();

	//alert('applyChange() change = ' + change + ' trans_511 = ' + trans_511 + ' trans_11 = ' + trans_11 + ' p_session_id = ' + p_session_id + ' p_tab = ' + p_tab + ' p_group = ' + p_group + ' clicked = ' + clicked.length);

	if (clicked.length > 0) { // check clicked variable to see if any rows have been updated. If so, create array of rows
		clicked = clicked.substring(1, clicked.length); // removes first "|" in clicked string
		rowArr = clicked.split("|");
		chsel = 1;
	}
	for (var k = 0; k < rowArr.length; k++) { // iterate through the rows selected
		var row = rowArr[k];
		var i = (no_fields + 1) * row; // get the correct field index for row

		if (change == "U") {
			if (form.elements[i].value.length == 0) {
				alert("The row has not been inserted into the database.");
				return false;
				eval("button.value=' ';");
			}
		}

		for (var j = 1; j < no_fields + 1; j++) {
			if (change == "I" || change == "U") {
				if (form.elements[i + j].name.substr(0, 4) != "sel_") {
					var val = form.elements[i + j].value;
					if (val.length > 0) {
						if (val.indexOf("&") > -1 || val.indexOf("%") > -1
								|| val.indexOf("\"") > -1) {
							alert("Please do not use reserved characters \&, %, ', \"");
							document.location.reload(); // not pretty, but prevent an error message
						}
					}
				}
			}

			if (change == "D" || change == "U") {
				if (form.elements[i + j].name.substring(0, 3) == "pk_") {
					var pk_name = form.elements[i + j].name.substring(3);
					par_wh = par_wh + pk_name + "="
							+ form.elements[i + j].value + " and ";
				}
			}

			if (change != "D") {
				if (form.elements[i + j].name.substring(0, 4) == "sel_") {
					par_val = par_val
							+ form.elements[i + j][form.elements[i + j].selectedIndex].value
							+ "|";
				} else
					par_val = par_val + form.elements[i + j].value + "|";
			}
		}
		par_wh = par_wh + "|";
	}
	if (chsel == 0) {
		alert(trans_511); // No rows have been selected.
		return;
	}
	eval("button.value='" + trans_11 + "'"); // Working...
	commitChange(form, change, par_val, par_wh, p_session_id, p_tab, p_group);
}

// Function to change the state of the checkbox and put the check mark in the selector.
function togChbox(form, name, val, no) {
	if (val == "X")
		eval("form.chbox" + no + ".checked=false;");
	else {
		eval("form.chbox" + no + ".checked=true;");
		updateClicked(no);
	}
}
