 function copyXFMR(mesg1) {
 var xfmr="";
    var table = $("#xfmr-table").DataTable();
	 	if (table.rows('.selected').data().length == 0 || table.rows('.selected').data().length>1)
		{
			alert(mesg1);
          	return false;
        }

        for (var i=0; i<table.rows('.selected').data().length; i++) 
        {
          xfmr = table.rows('.selected').data()[i][1];
        }
        parent.opener.document.formXFMR.xfmr.value=xfmr;
        parent.close();
 }
