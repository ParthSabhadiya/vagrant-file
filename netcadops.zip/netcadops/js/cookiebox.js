// ----------------------------------------------------------------------------
// 
//     +---------------------------------+
//     |  Copyright (c) 2015             |
//     |  ABB Network Management Systems |
//     |  All rights reserved            |
//     +---------------------------------+
// 
// Modification History
// 2015-03-04  RW  SPR137615 - Set all cookies to use the path "/" to resolve an 
//                 issue with mod_netcadops_enc internal redirection
// 2018-02-26  AV  Bug 94456  OCC scan change the methods and code to avoid conflict of copy rights.
//                 This file has same functions as in session.js. Hence, delete this file and use session.js
//                 This file deleted. Use session.js instead.
// ----------------------------------------------------------------------------
