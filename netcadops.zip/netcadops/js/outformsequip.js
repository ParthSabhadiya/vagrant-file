function applyChange()
{
    saveSessionIds(); // will set the session_id
	var h_out_no = $("#h_out_no").attr("value");  // This has the outage_no or trouble_rpt_no, or ncc number
	var p_display_type = $("#display_type").attr("value");

	// session_id is got from global var
	console.log("p_session_id = " + p_session_id + " p_display_type = " + p_display_type + " h_out_no= " + h_out_no);

	var v_opts = $("#equip_for_outage option");
	//var v_opts_picked = $("#equip_for_outage option:selected"); // If you only want the ones that are selected

	var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	var equip_cat_no = '';
	for (ii = 0; ii < v_valarr.length; ii++) {
		equip_cat_no += v_valarr[ii] + "|";  // equip cat numbers are delimited with character | 
	}

	// The remove-equip-numbers are empty hence || below
	pRemove = '';

	// the very first variable is outage_no (or trouble rpt no, ncc no)
	pAdd = h_out_no + "|" + equip_cat_no;

	// p_addPar is like "outage_no|equip_cat_no1|equip_cat_no2|equip_cat_no3|equip_cat_no4| ...." so on
	var vURL = "OutFormsEquip.Apply?p_session_id=" + p_session_id + "&p_addPar=" + escape(pAdd) 
		+ "&p_removePar=" + escape(pRemove) + "&p_display_type=" + p_display_type;
	document.location.href = vURL;
}
                                                   
var g_selector;
function init() 
{   
	g_selector = new oAppSelector(document.formEquip.from,document.treeapplet);   
	fillArr();
}

function removeEquip()
{
	var selob = $("#equip_for_outage");
	var v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple") + " datanative = " + selob.attr("data-native-menu");
	console.log(v_msg);
	//var v_opts = $("#equip_for_outage option"); // if you want all that are selected
	var v_opts = $("#equip_for_outage option:selected"); // If you only want the ones that are selected
	var v_names = $.map(v_opts ,function(ele) {
    	return ele.text;
	});
	console.log("names = " + v_names);
	var v_values = $.map(v_opts ,function(ele) {
    	return ele.value;
	});
	//var v_vals = v_opts.each(function(name, val) { 
	//		var opt = val.text; 
	//	});
	//var v_namearr = v_opts.map(function() { return $(this).text(); }).get();
	//var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	//var v_valarr = v_values.split(","); // string to array
	//console.log("values = " + v_values + " valarr = " + v_valarr + " names = " + v_names + " namearr = " + v_namearr);
	v_opts.remove();
}

function addEquip(all, trans575) 
{
    saveSessionIds();

    var listIDs = "";
    var listNames = "";
    if ( all == 0 ){ // Few areas picked by user
       	listIDs = getSelectedIds(treeSelector);
       	listNames = getSelectedNames(treeSelector);
		console.log("listIDs = " + listIDs + " listNames = " + listNames);
       	if ( listIDs == "") {
			//-- txt_trans_tbl(575) = Please select a Equip category from the list.
			alert(trans575);
			return;
       	}
    }
	addToListPanel(listIDs, listNames);
}

// Add a given list of options to the select box - list box
// Pipe delimited vars strings optIDs like '1|2|3|'  and optNames like 'name1|name2|name3'
function addToListPanel(optIDs, optNames) 
{
	var selob = $("#equip_for_outage");
	var v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple");
	//alert(v_msg);
	console.log(v_msg);
	var v_opts = $("#equip_for_outage option");
	//var v_opts_picked = $("#equip_for_outage option:selected"); // If you only want the ones that are selected
	var v_names = $.map(v_opts ,function(ele) {
    	return ele.text;
	});
	console.log("names = " + v_names);
	var v_values = $.map(v_opts ,function(ele) {
    	return ele.value;
	});
	//var v_vals = v_opts.each(function(name, val) { 
	//		var opt = val.text; 
	//	});
	var v_namearr = v_opts.map(function() { return $(this).text(); }).get();
	var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	//var v_valarr = v_values.split(","); // string to array
	console.log("values = " + v_values + " valarr = " + v_valarr + " names = " + v_names + " namearr = " + v_namearr);
	selob.remove();


	/* 
	 * Dynamic adding of options below is not working be it is not enabling the MULTIPLE attribute
	 * Hence, use the full html append in next section below:
	// Before doing push into options and changing it, set the attributes
	selob.attr("multiple", "multiple");
	//selob.attr("data-native-menu", "false");
	selob.attr("data-role", "none");
	selob.attr("size", "35");

	// Add to the Equip Categories list box
	var options = [];
	// Clear the options first   
	// selob.each(function(index, option) {
	//	$(option).remove();
	//});
	//options.push("<option value=''>Choose</option>");
	//options.push("<option value='" + "mytest" + "'>" + "mytest" + "</option>");
	options.push("<option value=1>1</option>");
	selob.append(options.join("")).selectmenu();
	v_msg = "size is : " + selob.attr("size") + " multiple = " + selob.attr("multiple");
	//alert(v_msg);
	console.log(v_msg);
	//selob.attr("size").change();  change is not function error
	selob.selectmenu().change();
	selob.selectmenu('enable');
	selob.selectmenu("refresh");
	*/

	/* 
	 * Dynamic adding of options is not working be it is not enabling the MULTIPLE attribute
	 * Hence, use the full html append in the section below:
	*/
	var v_txt;
	//v_txt= "<h1>Text.</h1>"; // Create element with HTML
	//$("#outformsequip-list").append(txt1);
	
	// Create element with HTML - select option list box
	v_txt = "<div class='jl' id='outformsequip-list'> \
			<select name='equip_for_outage' id='equip_for_outage' \
				multiple='multiple' \
				size='35' \
			>";

	// Add the existing equip categories
	for (ii = 0; ii < v_namearr.length; ii++) {
		v_txt += "<option value=" + v_valarr[ii] + ">"+ v_namearr[ii] + "</option>";
	}

	// Add the currently user picked equip categories from right panel
    var pick_arr = optIDs.split('|');
    var names_arr = optNames.split('|');
	//v_txt += " <option value=1>one</option> \
	//		  <option value=2 selected='selected'>Two</option> \
	//		</select> ";
	for (ii = 0; ii < names_arr.length; ii++) {
	    if (isBlank(pick_arr[ii])) // if null or empty string skip
			continue; 
		if (v_valarr.indexOf(pick_arr[ii]) != -1) 
			continue; // if item already exists in the left panel then ignore
		if (pick_arr[ii] === "0") 
			continue; // Ignore top level nodes like Animals, Equipment, Thirdparty which have 0
		v_txt += " <option value=" + pick_arr[ii] + ">" + names_arr[ii] + "</option>";
	}
	v_txt += " </select> </div> ";
	console.log("v_txt = " + v_txt);
	$("#outformsequip-list").append(v_txt);
	//$("#outformsequip-list").append(v_txt).trigger('create');
	//$("outformsequip-list").change();
}

function applyChange_delete_later() 
{
    saveSessionIds(); // will set the session_id

	// session_id is got from global var
	console.log("p_session_id = " + p_session_id + " p_display_type = " + p_display_type);

	// The par_val is like this: 
	// p_par  -  three pipe (|) delimited strings are contained in this procedure,
	// very first is the string of outage_equip_validation_time
	// second is the string of equips to add (delimited by ]) like  Aa]Bbb]Cccc]
	// third string of equips to remove (delimited by ]) like  Aa]Bbb]Cccc]
	// fourth is outage number or trouble_rpt no, non cust call no.
	// For example:  p_par = outage_equip_validation_time|equips to add| equips to remove  | outage_no or trouble rpt no |

    var par_val = ""; 

	// For example value of par_val:
	//par_val = "<equip_date>|equip_no1]equip_no2]equip_no3]|removeequip_no1]remove_equip_no2]|trouble_rpt_no or outage_no or ncc_no|";
	//par_val = "|1700]800]805]||936062|";


	var equip_date = $("#txtCAUSDate").attr("value");
	var h_out_no = $("#h_out_no").attr("value");  // This has the outage_no or trouble_rpt_no, or ncc number

	var equip_cat_no = "";
	//var selob = $("#equip_for_outage");

	var v_opts = $("#equip_for_outage option");
	//var v_opts_picked = $("#equip_for_outage option:selected"); // If you only want the ones that are selected
	var v_valarr = v_opts.map(function() { return $(this).val(); }).get();
	for (ii = 0; ii < v_valarr.length; ii++) {
		equip_cat_no += v_valarr[ii] + "]";  // equip cat numbers are delimited with character ] 
	}

	// The remove-equip-numbers are empty hence || below
	par_val = equip_date + "|" + equip_cat_no + "||" + h_out_no + "|" ;

    //-- 04/08/05 EK  Added session id parameter
    var vURL = "OutFormsEquip.Apply?p_par=" + escape(par_val) + "&p_session_id=" + p_session_id + "&p_display_type=" + p_display_type;
    document.location.href = vURL

	//var vURL = "OutFormsEquip.Apply?p_session_id=" + p_session_id + "&p_addPar=" + escape(pAdd) 
	//	+ "&p_removePar=" + escape(pRemove) + "&p_display_type=" + p_display_type;
	//document.location.href = vURL;
}

// Gets the previous saved equips from the oracle database and displays in left panel
function retrieveSavedEquip() 
{
	/*
	var display_type = $("#display_type").attr("value");
	var equip_arr;
	// Get all the elements whose id is starting with "db_r"
	var optIDs = "", optNames = "";
	// pattern match with carret - find all id which start with db_r
	var prev_equips = $("[id^=db_r]").each(function() {
		// db_r will be like - "801| |Jumper|OH Conductor| |"
		equip_arr = $(this).attr("value").split('|');
		for (ii = 0; ii < equip_arr.length; ii++) {
			if (ii === 0) {
				v_val = equip_arr[0]
			} else if (ii === 2) {
				v_name = equip_arr[2]
				optIDs += v_val + "|";
				optNames += v_name + "|";
				v_val = ""; // reset
			}
		}
	});
	*/
	fillArr(); // This populates variables opt_id_list and opt_name_list

	addToListPanel(opt_id_list, opt_name_list);
}

var treeSelector = "#outformsequip-tree";
$(document).ready(function () 
{
    // create the tree data structure
	var v_tmp = '';

	// pattern match with carret - find all id which start with db_r
	// Get all NodeStr*  like NodeStr0, NodeStr1, NodeStr2....
	$("[id^=NodeStr]").each(function() {
		v_tmp += $(this).attr("value");
	})

    var treeData = parseTreeNodeInfo(v_tmp);

    $(treeSelector).fancytree({
        source: treeData,
        checkbox: true, // Show check boxes
        selectMode: 2, // 1:single, 2:multi, 3:multi-hier
        autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }
    });

    //var tree = $(treeSelector).fancytree("getTree");
    //tree.expandAll = false;
    //alert("We have " + tree.count() + " nodes.");
    //tree.reload();

    // Expand all tree nodes
    //tree.visit(function (node) {
     //   node.setExpanded(true);
    //});
    
    $(treeSelector).fancytree("getRootNode").visit(function (node) {
        node.setExpanded(false);
    });

	retrieveSavedEquip();
});
