
var p_session_id;
var p_prev_sess_id;

function saveSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() {
    popObject = window.createPopup();
    popObject.hide(); 
    formLogout.submit();
}

function CheckLogin() {
    if (top.sessionframe) {
        return false;
    } 
    else { 
        if (areasSelected==false) {
            sessionClose();
            return true; 
        } 
        else {
            return false;
        }
    }
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all){
    saveSessionIds();

    areasSelected = true;

    var listIDs = "";
    if ( all == 0 ){
       listIDs = getSelectedIds();
       console.log(listIDs);
       if ( listIDs == ""){
           alert( "'" + txt_trans(908) + "'");
           return;
       }
    }
    else  {
        listIDs = "||";
    }

    if ( top.hiddenFrame){
        var vURL = "NetcMenu.UpdateUserDistricts?p_districts=" + listIDs + '&p_session_id=' + p_session_id;
        var baseframeURL = "NetcMenu.WhoAmI?p_session_id=" + p_session_id ;
        var treeframeURL = "NetcMenu.MenuGen?p_session_id=" + p_session_id;
        top.treeframe.location.href=treeframeURL;
        top.hiddenframe.location.href=vURL;
        top.baseframe.location.href=baseframeURL;
    }
    else {
        var vURL = "NetcMenu.SetUser?p_districts=" + listIDs 
            + "&p_session_id=" + p_session_id 
            + "&p_prev_sess_id=" + p_prev_sess_id
            + "&p_timezone=" + encodeURIComponent(jstz.determine().name());
        document.location.href=vURL;
    }
}

function getSelectedIds(){
    var nodes = $("#etrsettings").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function filter(mesg1)
       {
           
            var vURL = "";
            var length = "";
            var v_cnt = "1";
            var areaList ="";
            var v_elementId = parent.OpCenFrame.lastFocus;
            var v_transType ="I";
            var areaListArr =new Array();
            var v_prvSubAreaId ="";
            areaList = $("#etrsettings").fancytree("getTree").getSelectedNodes();
                  if (areaList.length == 0)
                  {
                     alert(mesg1);
                     return;
                   }
                   else
                   {
                      length = parent.OpCenFrame.frmOpCent.elements.length; 
                      length = length/4;
                      for (var cnt=0; cnt < length;cnt++)
                      {
                           v_cnt = (cnt*4)+1;
                           for(var c=0; c<areaList.length; c++){
                                 if(parent.OpCenFrame.frmOpCent.elements[v_cnt].value == areaList[c].key){
                                  parent.OpCenFrame.addArray(parent.OpCenFrame.frmOpCent,
                                  v_cnt-1,parent.OpCenFrame.frmOpCent.elements[v_cnt].value,
                                  parent.OpCenFrame.frmOpCent.elements[v_cnt+1].value,
                                  parent.OpCenFrame.frmOpCent.elements[v_cnt+2].value);
                                 }
                           }
                      }
                   }
       }

$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo( $('param').attr('VALUE') );
    $("#etrsettings").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }
	});
});
