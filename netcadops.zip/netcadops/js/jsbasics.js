// Basic JS functions
// ---------------------------------------------------------------------------
// Copyright ABB Network Management SYSTEMS
// Modification History
// #  001     12-Nov-2010     alavoor UNITIL 107585 Saving "Callback options displayed" 
// #                                  in Call Entry Preferences caused Error on page when open TR
// #  002     17-Dec-2010     alavoor NIPSCO 110630 Add AJAX support for dynamic symptom select
// #  003     19-Dec-2010     MS      NIPSCO 110630 Removed the above  AJAX  function.
//                                    the functions are implmented in the calltrouble pkg.
// #  004     27-Feb-2014  AlDev ABB2013-129886 Webpage link 404 error: Maximo Form - Equipment Code
// #          10-Dec-2013  AlDev ABB2013-129886 Webpage link 404 error: Maximo Form - Equipment Code
// #          11-Dec-2013  AlDev ABB2013-129885 Webpage link 404 error: Call Entry - Non-Cust Call St Intersection
// ---------------------------------------------------------------------------

// jsAlert
// Display a message and redirect to another page if specified.
// Examples:
// htp.p( '<script>jsAlert("' || v_message || '","/netcadops/", "top");</script> ' );
// htp.p( '<script>jsAlert("' || v_message || '");</script> ' );
//

function jsAlert(p_message) {
//default values
	var p_url = (arguments.length > 1) ? arguments[1] : null;  	
	var p_target = (arguments.length > 2) ? arguments[2] : 'document';
	
	alert(p_message);
	if (p_url != null)
	{	
		eval(p_target + ".location.href='" + p_url + "';");
	}
}

function pageLauncher() {

   //
   // Current browser settings, defaulted...

   this.xMax      = 640;
   this.yMax      = 480;
   this.Left      = 100;
   this.Top       = 50;

   //
   // Page to launch info

   this.pageWidth  = 300;
   this.pageHeight = 300;
   this.url        = 'about:blank';
   this.title      = 'Popup';
   this.options    = "toolbar=no,location=no,directories=no,status=no,menubar=no";

   //
   // launch method

   this.launch = launcher;

} // pageLauncher

function launcher()
{

   if (self.innerHeight) // all except Explorer
   {
   	this.xMax = self.innerWidth;
   	this.yMax = self.innerHeight;
      this.Left = window.screenX;
      this.Top = window.screenY;
   }
   else if (document.documentElement && document.documentElement.clientHeight)
   	// Explorer 6 Strict Mode
   {
   	this.xMax = document.documentElement.clientWidth;
   	this.yMax = document.documentElement.clientHeight;
   	this.Left = window.screenLeft;
   	this.Top  = window.screenTop;
   }
   else if (document.body) // other Explorers
   {
   	this.xMax = document.body.clientWidth;
   	this.yMax = document.body.clientHeight;
   	this.Left = window.screenLeft;
   	this.Top  = window.screenTop;
   }

   var xOffset = this.Left + ((this.xMax - this.pageWidth)/2),  yOffset = this.Top + ((this.yMax - this.pageHeight) / 2)

   popWin(this.url,
          this.title,
          this.pageWidth,
          this.pageHeight,
          "N",
          xOffset,
          yOffset,
          this.options);
}


// reloadPage
function reloadPage() {
	document.location.href = document.location.href;
}


// stringReplace
function stringReplace(originalString, findText, replaceText) {
   var re = new RegExp(findText, "g");
   return originalString.replace(re,replaceText);
}

// callURL
//Change the caption of the calling button to "Working..." and call another page.
//OAS requires that there are no blank characters, so we replace them with %20.
function callURL (form, p_button, p_url, p_prefix, p_caption) {

   //default values
	var p_target = null;
	var v_caption = null;

	if (arguments.length > 4) {  
		p_target = arguments[3];
		v_caption = arguments[4];
	}
	else if (arguments.length == 4) {
		p_target = 'document';
		v_caption = arguments[3];
	}
	else {
   	p_target = 'document';
	   v_caption = null;
	}
	
	if (v_caption != null) {	eval("form." + p_button + ".value=v_caption;"); }
	else 	     {  eval("form." + p_button + ".value='Working...';"); }
	var v_url = stringReplace(p_url, " ", "%20");
	eval(p_target + ".location.href='" + v_url + "';");
}



//checkedToList
//Returns the | delimited list of values from HTML table.
//The returned values are taken from the field next to the checkbox field.  Can be
//a hidden field.  The checkbox name is "chbox".
function checkedToList (form) {
	var listArr = new Array();
	var list = "";
	var j = 0;
	for (var i=0; i<form.length; i++) {
		if (form.elements[i].name == "chbox" && form.elements[i].checked) {
			listArr[j] = form.elements[i+1].value;
			j++; // cannot skip numbers in j in order to use .join method
		}
	}
	list = listArr.join("|");
	return(list);
}


//fieldsToList
//Returns a | separated list of values in the form fields.
function fieldsToList (form) {
	var listArr = new Array();
	var list = "";
	for (var i=0; i<form.length; i++) {
		//alert(form.elements[i].name);
		if (form.elements[i].name.indexOf("select") > -1) {
			listArr[i] = form.elements[i].options[form.elements[i].selectedIndex].value;}
		else {
			listArr[i] = form.elements[i].value;}
	}
	list = listArr.join("|");
	return(list);
}



//calendar
//Displays a calendar pop-up window, returns the selected date to the
//"formname.fieldname".
//To call it use:
//'<A HREF="#" onClick="calendar(''formInput'', ''DATE1'');"><IMG SRC="/js/calendar.gif" BORDER=0></A>'
//The calling page must also include the popWin function:
//htp.p( '<script language="Javascript" src="/js/PopWin.js"></script>' );

function calendar(formname, fieldname) {
					//window.dateField = document.inputForm.DATE1;

   var form = document.getElementById(formname);
   window.dateField = eval("document." + formname + "." + fieldname);

   var pl = new pageLauncher();

   if (fieldname == "verif_rest_time")
   {
      pl.pageWidth  = 265;
      pl.pageHeight = 295;
      pl.url        = "LibUtil.CalendarSec";
      pl.title      = "Calendar";
   }
   else
   {
      pl.pageWidth  = 225;
      pl.pageHeight = 285;
      pl.url        = "LibUtil.Calendar";
      pl.title      = "Calendar";
   }
   
   pl.launch();

   pl = null;
}



//pickList
//Displays a pick-list pop-up window, returns the selected value to the
//formname.codefield, and the description to formname.descfield
//The calling page must also include the popWin function:
//htp.p( '<script language="Javascript" src="/js/PopWin.js"></script>' );

function pickList(formname, codefield, descfield, q) {

   //default values
	var hide_code = (arguments.length > 4) ? arguments[4] : 'N';
	var hide_desc = (arguments.length > 5) ? arguments[5] : 'N';

   if (hide_code != 'N') hide_code = '&p_hide_code=Y'; else hide_code = '';
   if (hide_desc != 'N') hide_desc = '&p_hide_desc=Y'; else hide_desc = '';

   window.codefield = eval("document." + formname + "." + codefield);
   window.descfield = eval("document." + formname + "." + descfield);
   
   var v_q = stringReplace(q, " ", "%20");

   var pl = new pageLauncher();

   pl.pageWidth  = 500;
   pl.pageHeight = 280;
   // You need to pass the session-id from OAS with  "p_q=somenumber&p_session_id=" || Request.Session
   pl.url        = "LibUtil.PickList?p_q="+v_q+hide_code+hide_desc;
   pl.title      = "PickList";
   pl.launch();

   pl = null;
}

// Function to display dynamic pick lists for selection based on the content of another field
// in the form.
// Supports up to two columns in the where clause. Parameter and_dyn_field contains the name of
// the second field to provide the value for the where clause.
// 06/13/05 Pick function to pop window to allow selection of Substation or Feeder added to jsbasics.js 
// D.Simmons

function pickListDyn(formname, codef, descf, q) {
   var argv = arguments;
   var argc = arguments.length;
   var hide_code = (argc > 4) ? argv[4] : "N";
   var hide_desc = (argc > 5) ? argv[5] : "N";
   var dyn_field = (argc > 6) ? argv[6] : "";
   var par_text  = (argc > 7) ? argv[7] : "";
   var par_title = (argc > 8) ? argv[8] : "";
   var and_dyn_field = (argc > 9) ? argv[9] : "";
   var p_session_id = (argc > 10) ? argv[10] : "";
   var p_v1 = (argc > 11) ? argv[11] : "";  // dynamic variables to pass some arg values
   var p_v2 = (argc > 12) ? argv[12] : "";  // dynamic variables to pass some arg values
   var p_v3 = (argc > 13) ? argv[13] : "";  // dynamic variables to pass some arg values

   if (hide_code != "N") hide_code = "&p_hide_code=Y"; else hide_code = "";
   if (hide_desc != "N") hide_desc = "&p_hide_desc=Y"; else hide_desc = "";
   var codefield = "document." + formname + "." + codef;
   var descfield = "document." + formname + "." + descf;

   var v_q = stringReplace(q, " ", "%20");

   if (dyn_field != "DYNFIELD") {
      var dyn_val=eval("document."+formname+"."+dyn_field+".value;");
      if (dyn_val.length==0) {
         alert(par_text);
         return;
      }
      v_q = stringReplace(v_q, "DYNVALUE", dyn_val);
   }

   // second dynamic value
   // commented just to pick up change visually ... 
   if (and_dyn_field != "") {
      var and_dyn_val=eval("document."+formname+"."+and_dyn_field+".value;");
      if (and_dyn_val.length==0) {
         alert(par_text);
         return;
      }
      v_q = stringReplace(v_q, "ANDVALUE", and_dyn_val);
   }

   eval("window.codefield = " + codefield);
   eval("window.descfield = " + descfield);

   var pl = new pageLauncher();

   pl.pageWidth  = 500;
   pl.pageHeight = 480;
   //pl.url        = "LibUtil.PickList?p_q="+v_q+hide_code+hide_desc+"&p_text="+par_title;

//alert("p_session_id = " + p_session_id + " v_q = " + v_q);

	if (descf == "maximo_equipment_code"){ 
	   pl.url        = "LibUtil.EquipPickList?p_q="+v_q+hide_code+hide_desc+"&p_text="+par_title+"&p_session_id="+p_session_id;
	}else{
	   if (p_session_id != "") {
			pl.url = "LibUtil.PickList?p_q="+v_q+hide_code+hide_desc+"&p_text="+par_title+"&p_session_id="+p_session_id;
		} else {
			// You need to pass the session-id from OAS with  "p_q=somenumber&p_session_id=" || Request.Session
			// Or use "p_q=somenumber&p_session_id=" || Request.Param('p_session_id')
			pl.url = "LibUtil.PickList?p_q="+v_q+hide_code+hide_desc+"&p_text="+par_title;
		}

	   // Add the dynamic variables only if they are not empty. Because the v_q may 
	   // already contain the dynamic variables p_v1, p_v2 or p_v3
	   if (p_v1 != "")
			pl.url = pl.url +"&p_v1="+p_v1;
	   if (p_v2 != "")
			pl.url = pl.url +"&p_v2="+p_v2;
	   if (p_v3 != "")
			pl.url = pl.url +"&p_v3="+p_v3;
	}

   pl.title      = "PickList";
   pl.launch();

   pl = null;
}

// Force a new definition of escape for IE browsers	
function localescape(str) {
    return encodeURIComponent(str);
}

//Check for browser version to select appropriate escape to be used
var isNS4 = (document.layers) ? true : false;
var isNS6 = (!document.all && document.getElementById) ? true : false;
var isIE4 = (document.all && !document.getElementById) ? true : false;
var isIE5 = (document.all && document.getElementById) ? true : false;

var escape = (isNS6 || isIE5) ? localescape : escape;


function isValidTime(value) {
   var hasMeridian = false;
   var re = /^\d{1,2}[:]\d{2}([:]\d{2})?( [aApP][mM]?)?$/;
   if (!re.test(value)) { return false; }
   if (value.toLowerCase().indexOf("p") != -1) { hasMeridian = true; }
   if (value.toLowerCase().indexOf("a") != -1) { hasMeridian = true; }
   var values = value.split(":");
   if ( (parseFloat(values[0]) < 0) || (parseFloat(values[0]) > 23) ) { return false; }
   if (hasMeridian) {
      if ( (parseFloat(values[0]) < 1) || (parseFloat(values[0]) > 12) ) { return false; }
   }
   if ( (parseFloat(values[1]) < 0) || (parseFloat(values[1]) > 59) ) { return false; }
   if (values.length > 2) {
      if ( (parseFloat(values[2]) < 0) || (parseFloat(values[2]) > 59) ) { return false; }
   }
   return true;
}

