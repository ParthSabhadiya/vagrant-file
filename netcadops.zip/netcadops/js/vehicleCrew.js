// These functions called in crewmgmtdet.pkb:Vehicles()
// Used to Add Vehicles to crew in netc:StormRoom:Crew Mgmt:Vehicles:Add
//
function addTo(what, txt_trans_10201, txt_trans_10223, txt_trans_10224, g_oncrew, g_avail, g_busy) {
    var vehlist = "", xfmr = "";

    document.formVeh.h_sync_crew_id.value = ""; //  to force refresh of this page after CrewMgmt.Apply
    var table = $("#vehicle-table").DataTable();

    if (table.rows('.selected').data().length == 0) {
        alert(txt_trans_10201); // "Please select a vehicle from the list"
        return false;
    }

    for (var i = 0; i < table.rows('.selected').data().length; i++) {
        xfmr = table.rows('.selected').data()[i][1];
        if (what == "A" || what == "REMOVE") {
            vehlist = vehlist + xfmr + "]";  // We use sq-bracket ] as the delimiter for multiple employees selected
        }
        //alert('Debug: xfmr = ' + xfmr + ' total rows = ' + table.rows('.selected').data().length + ' vehlist = ' + vehlist);
    }

    var crewform = parent.crew.document.formCrew;
    if (what == "A") { // Add
        crewform.h_veh_list.value = crewform.h_veh_list.value + vehlist;
        alert(txt_trans_10223 + crewform.h_veh_list.value); // Vehicle selected to be added, click on Apply to save.\n\nSelection is: 
        //alert('Debug:  crewform.h_veh_list.value =  ' + crewform.h_veh_list.value + ' vehlist = ' + vehlist);
    }
    if (what == "REMOVE") {
        crewform.h_veh_remove.value = crewform.h_veh_remove.value + vehlist;
        alert(txt_trans_10224 + crewform.h_veh_remove.value); // Vehicle selected to be removed, click on Apply to save.\n\nSelection is: 
    }
}

function applyChange(but, txt_trans_11, txt_trans_37, txt_trans_10337) {
    if (self.parent.frames.length != 0) {
        but.value = txt_trans_11; //  "Working..."
        parent.crew.applyChange(parent.crew.document.formCrew, "butApply", "U"); // calls the crewmgmt.pkb:CrewInfo()
        but.value = txt_trans_37; // "Apply"
    } else {
        alert(txt_trans_10337); // "Cannot find the parent frame."
    }
}
