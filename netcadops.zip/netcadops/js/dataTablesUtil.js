
function getDataRows(){
    var result = {};
    var selector = "PARAM[NAME^=r]";
    
    var pattern = /^r[0-9]+$/;

    $(selector).each(function(){
        var nameAttr = $(this).attr("NAME");
        var value = $(this).attr("value");
        if ( pattern.test(nameAttr )){
            if (value && value.indexOf("|") != 0 ) {
                value = "|" + value; //required by some grid data
            }
            var values = value.split("|");
            result[nameAttr ] = values;
        }
    });
    return result;
}

function getColumnNames(){
    var columns = [];

    var selector = "PARAM[NAME^=field]";
    var pattern = /^field[0-9]+$/;
    $(selector).each(function(){
        var nameAttr = $(this).attr("NAME");
        var value = $(this).attr("value");
        if (pattern.test(nameAttr)){
            var values = value.split("|");
            columns.push(values[0]);
        }
    });

    console.log("dtaTableUtil.js:getColumnNames() ColumnNames:" + columns);

   return columns;
}

function getNumberOfDisplayedColumns(){
    var count = $("PARAM[name=display_fields]").attr("value");
    return parseInt(count);
}

function createDataTableColumns(){
    // Get the columns listed in page data
    var names = getColumnNames();

    // Get the number of displayed columns and display only first count columns
    var count = getNumberOfDisplayedColumns();
    if ( names.length > count ){
        names = names.slice(0, count);
    }
    
    // get link button column name and add it as the first column
    names.splice( 0, 0, $("PARAM[name=link_button]").attr("value") );

    var columns = [];
    for( var i = 0; i < names.length; i++ ){
        columns.push({
            title: names[i]
        });
    }
    console.log( "Number of columns:" + columns.length);
    return columns;
}

function createDataTableData(options){
    var dataSet = [];

    var dataRows =  getDataRows();
    var sessionId = getUrlParameter("p_session_id");

    for ( counter in dataRows ){
        // if id column index is provided, use it to get the detail url and pass to detail btn 
        if ( options.hasOwnProperty("idColumnIndex") && options.hasOwnProperty("detailUrlFormat")){
            var itemId = dataRows[counter][options.idColumnIndex];

            // Replace all occurences of "SESSION_ID}"
            var detailUrl = options.detailUrlFormat;
            while( detailUrl.indexOf("{SESSION_ID}") >= 0 ) detailUrl = detailUrl.replace("{SESSION_ID}", sessionId);

            // Replace all occurences of {ITEM_ID}
            while( detailUrl.indexOf("{ITEM_ID}") >= 0 ) detailUrl = detailUrl.replace("{ITEM_ID}", itemId);

            // Add additional IDs if available
            if (options.hasOwnProperty("accountNoColumnIndex")){
                var accNo = dataRows[counter][options.accountNoColumnIndex];
                while( detailUrl.indexOf("{ACCOUNT_NO}") >= 0 ) detailUrl = detailUrl.replace("{ACCOUNT_NO}", accNo);
            }
            dataRows[counter][0] = "<input type='button' onclick='detailButtonClicked(event)' data-detail-url='" + detailUrl + "' class='detailBtn' value='...'/>";
        }

        // else if detailUrlIndex is provided use that to get the detail url
        else if ( options.hasOwnProperty("detailUrlIndex")){
            var detailUrl = dataRows[counter][options.detailUrlIndex];
            dataRows[counter][0] = "<input type='button' onclick='detailButtonClicked(event)' data-detail-url='" + detailUrl + "' class='detailBtn' value='...'/>";
        } 
        //idColumnCount is the range of columns used to build the param list for the url.
        else if ( options.hasOwnProperty("idColumnCount") && options.hasOwnProperty("detailUrlFormat"))
        {
           var itemId="" ;
           var indx = options.idColumnCount;

           for( var i = 1; i <= indx; i++ )
           {
             if(i == indx)
             {
               itemId = itemId + dataRows[counter][i];
             }
             else
             {
               itemId = itemId + dataRows[counter][i] + '|';
             }
               
           }
            var detailUrl = options.detailUrlFormat;
            while( detailUrl.indexOf("{SESSION_ID}") >= 0 ) detailUrl = detailUrl.replace("{SESSION_ID}", sessionId);
            while( detailUrl.indexOf("{ITEM_ID}") >= 0 ) detailUrl = detailUrl.replace("{ITEM_ID}", itemId);

            dataRows[counter][0] = "<input type='button' onclick='detailButtonClicked(event)' data-detail-url='" + detailUrl + "' class='detailBtn' value='...'/>";
        }          
        dataSet.push(dataRows[counter]);
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}

function detailButtonClicked(ev){
    var detailUrl = $(ev.target).data("detail-url");
    if ( detailUrl){
        window.location.href = detailUrl;
    }
}

//
// options is of the form
// {
//     selector:  the id of the datatable div in DOM - "#outage_table"
//     idColumnIndex: the position of column containing item id in any row -  2.
//     accountNoColumnIndex - position of account no (optional)
//     detailUrlFormat: format of the url that displays detail of the item - see detailBtnClicked for its format.
//     detailUrlIndex: the postion detail url in a row returned in the PARAM tag, usually the last enetry if avaiable.
//     height: height of the table
// }

function createDataTable(options){
    $(document).ready(function(){
        var table = $(options.selector).DataTable({
            columns: createDataTableColumns(),
            data: createDataTableData(options),
            select: true,
            scrollX: true,
            lengthMenu: options.hasOwnProperty("lengthMenu") ? options.lengthMenu : [[20, 30, 40, 50, -1], [20, 30, 40, 50, "All"]],
            scrollY: options.hasOwnProperty("height") ? options.height: 450,
            searching: options.hasOwnProperty("searching") ? options.searching: true,
            paging:  options.hasOwnProperty("paging") ? options.paging: true,
            info: options.hasOwnProperty("info") ? options.info : true,
            columnDefs: [
                { className: "tdbold", targets: "_all" }, // make all cells bold font
            ]
        });
    });
}

