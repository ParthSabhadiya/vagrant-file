
function getColumnNames(){
    var columns = []
    var params =  getParamsWithPrefix("field");

    for( param in params ){
        if ( param == "fields") continue;
        columns.push(params[param][0]);
    }
   return columns;
}

function getNumberOfDisplayedColumns(){
    var count = $("PARAM[name=display_fields]").attr("value");
    return parseInt(count);
}

function createDataTableColumns(){
    // Get the columns listed in page data
    var names = getColumnNames();

    // Get the number of displayed columns and display only first count columns
    var count = getNumberOfDisplayedColumns();
    if ( names.length > count ){
        names = names.slice(0, count);
    }
    
    // get link button column name and add it as the first column
    names.splice( 0, 0, $("PARAM[name=link_button]").attr("value") );

    var columns = [];
    for( var i = 0; i < names.length; i++ ){
        columns.push({
            title: names[i]
        });
    }
    console.log( "Number of columns:" + columns.length);
    return columns;
}

function createDataTableData(){
    var dataSet = [];

    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( param in rows ){
        if ( pattern.test(param)){
            var bulletNo = rows[param][1];
            rows[param][0] = "<input type='button' onclick='detailButtonClicked(event)' data-bulletno='" + bulletNo + "' class='detailBtn' value='...'/>";
            dataSet.push(rows[param]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}

function detailButtonClicked(ev){
    var sessionId = getUrlParameter("p_session_id")
    var bulletNo = $(ev.target).data("bulletno");
    window.location.href = "CreateBulletins.BullRpt?p_session_id=" + sessionId + "&p_bull_no=" + bulletNo;
}

$(document).ready(function(){
    var table = $("#displayBulletinTable").DataTable({
        columns: createDataTableColumns(),
        data: createDataTableData(),
        select: true,
        scrollX: true,
        scrollY: 500,
        "lengthMenu": [[20, 30, 40, 50, -1], [20, 30, 40, 50, "All"]],
        columnDefs: [
            { className: "tdbold", targets: "_all" }, // make all cells bold font
        ]
    });
});