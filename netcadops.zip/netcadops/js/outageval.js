function compare( firstIndex, secondIndex, v_entered, v_OutageMessageArr, v_earlier, v_later ){
   var tempMessage = "";
   var Datedifference = 0;
   if ( firstIndex < secondIndex ){
      if ( v_entered[ firstIndex ] != "" ){
         prevDateValue = v_entered[ secondIndex ];
         if ( prevDateValue != "" ){
            fromDate = new Date( v_entered[ firstIndex ] );
            toDate = new Date( prevDateValue );
            Datedifference = toDate- fromDate ;
            if ( Datedifference < 0 ){
               tempMessage = v_OutageMessageArr[ firstIndex ] + ": " + v_entered[ firstIndex ] + " " + v_later + " " +
               v_OutageMessageArr[ secondIndex ] + ": " + v_entered[ secondIndex ] + "\n";
               return tempMessage;
            }
         }
      }
   }else{
      if ( v_entered[ secondIndex ] != "" ){
         prevDateValue = v_entered[ firstIndex ];
         if ( prevDateValue != "" ){
            fromDate = new Date( prevDateValue );
            toDate = new Date( v_entered[ secondIndex] );
            Datedifference = toDate- fromDate ;
            if ( Datedifference > 0 ){
               tempMessage = v_OutageMessageArr[ firstIndex ] + ": " + v_entered[ firstIndex ] +" " + v_earlier + " " +
               v_OutageMessageArr[ secondIndex ] + ": " + v_entered[ secondIndex ] + "\n"
               return tempMessage;
            }
         }
      }
   }
   return tempMessage;
}

function OutageTMValidate( dateString, index, v_outread, v_OutageMessageArr, v_earlier, v_later, page_id, page_index  ){ 
   var Message = "";
   var Datedifference = 0;
   var v_index = 0;
   var v_entered = dateString.split( "|" );
   for ( v_index=0;v_index<=v_entered.length-1;v_index++){
      if ( v_entered[ v_index ] == "" ){
         if ( page_id == "outforms" ){
            if ( page_index != v_index )
               v_entered[ v_index ] = v_outread[ v_index ];
         }else
            v_entered[ v_index ] = v_outread[ v_index ];
      }
   }
   if ( index < 5 ){
      for ( v_index=0; v_index<=index-1;v_index++){
         if ( v_entered[ v_index ] != "" ){
            prevDateValue = v_entered[ v_index ];
            if ( prevDateValue != "" ){
               fromDate = new Date( prevDateValue );
               toDate = new Date( v_entered[ index] );
               Datedifference = toDate- fromDate ;
               if ( Datedifference < 0 ){
                  Message = Message + v_OutageMessageArr[ index ] + ": " + v_entered[ index ] + " " + v_earlier + " " +
                  v_OutageMessageArr[ v_index ] + ": " + v_entered[ v_index ] + "\n"
                  return Message;
               }
            }
         }
      }
      v_index = parseInt( index )+1;
      for ( v_index; v_index<=4;v_index++){
         if ( v_entered[ v_index ] != "" ){
            prevDateValue = v_entered[ v_index ];
            if ( prevDateValue != "" ){
               fromDate = new Date( v_entered[ index] );
               toDate = new Date( prevDateValue );
               Datedifference = toDate- fromDate ;
               if ( Datedifference < 0 ){
                  Message = Message + v_OutageMessageArr[ index ] + ": " + v_entered[ index ] + " " + v_later + " " +
                  v_OutageMessageArr[ v_index ] + ": " + v_entered[ v_index ] + "\n"
                  return Message;
               }
            }
         }
      }
   }
   else{
      if ( index == 5 ){
         Message = Message + compare( 5, 6, v_entered, v_OutageMessageArr, v_earlier, v_later );
         if ( Message != "" )
            return Message;
         Message = Message + compare( 5, 7, v_entered, v_OutageMessageArr, v_earlier, v_later );
         if ( Message != "" )
            return Message;
      }else if ( index == 6 ){
         Message = Message + compare( 6, 5, v_entered, v_OutageMessageArr, v_earlier, v_later );
         if ( Message != "" )
            return Message;
      }else if ( index == 7 ){
         Message = Message + compare( 7, 5, v_entered, v_OutageMessageArr, v_earlier, v_later );
         if ( Message != "" )
            return Message;
      }
   }
   return Message;
}