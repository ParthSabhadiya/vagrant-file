
function getColumnNames(){
    var columns = []
    var params =  getParamsWithPrefix("field");

    for( param in params ){
        if ( param == "fields") continue;
        columns.push(params[param][0]);
    }
   return columns;
}

function getNumberOfDisplayedColumns(){
    var count = $("PARAM[name=display_fields]").attr("value");
    return parseInt(count);
}

function createDataTableColumns(){
    // Get the columns listed in page data
    var names = getColumnNames();

    // Get the number of displayed columns and display only first count columns
    var count = getNumberOfDisplayedColumns();
    if ( names.length > count ){
        names = names.slice(0, count);
    }
    
    // get link button column name and add it as the first column
    names.splice( 0, 0, $("PARAM[name=link_button]").attr("value") );

    var columns = [];
    for( var i = 0; i < names.length; i++ ){
        columns.push({
            title: names[i]
        });
    }
    console.log( "Number of columns:" + columns.length);
    return columns;
}

function createDataTableData(){
    var dataSet = [];

    var rows =  getParamsWithPrefix("r");
    var pattern = /^r[0-9]+$/

    for ( param in rows ){
        if ( pattern.test(param)){
            // Set the first data to a button linked to outage detail
            var outageId = rows[param][2];
            rows[param][0] = "<input type='button' disabled class='detailBtn' value='...'/>";
            dataSet.push(rows[param]);
        }
    }
    console.log( "Number of rows:" + dataSet.length);
    return dataSet;
}


 function getDetail(form,mesg1)
   {
    var vURL = "", param = "";
    var ridAsString, codeAsString, catAsString, ridArr=new Array(), TransAsString;
    //ridAsString = document.gridapplet.getSelectedID();
    var table = $("#trans-admin-table").DataTable();
    ridAsString = ridAsString + ""; 
    if (table.rows('.selected').data().length == 0)
    {
      alert(mesg1);
      return;
     }
     for (var i = 0; i < table.rows('.selected').data().length; i++)
     {
        codeAsString = table.rows('.selected').data()[i][1];
        catAsString = table.rows('.selected').data()[i][2];
        param = param + codeAsString + "|" + catAsString + "|";
       //codeAsString = prefAsString.substring(0, prefAsString.indexOf("|"));
       //param = param + codeAsString + "|";
     }
     param = param + form[0].value + "|" + form[1].value + "|";
     var sessionId = getUrlParameter("p_session_id")
     vURL = "TransAdmin.TransFrameset?p_session_id="+ sessionId +"&p_par="+escape(param);
     popWin(vURL, "netCADOPSpop", 990, 500);
   }

$(document).ready(function(){
    var table = $("#trans-admin-table").DataTable({
        columns: createDataTableColumns(),
        data: createDataTableData(),
        select: true,
        scrollX: true,
        scrollY: 500,
        "lengthMenu": [[20, 30, 40, 50, -1], [20, 30, 40, 50, "All"]],
        columnDefs: [
            { className: "tdbold", targets: "_all" }, // make all cells bold font
        ]
    });

    $('#trans-admin-table tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
           
            $(this).addClass('selected');
            
        }
    } );
});