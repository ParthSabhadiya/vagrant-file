//           +-----------------------------------------------+
//           |                                               |
//           |               COPYRIGHT (c) 1990-2019         |
//           |                                               |
//           |       ABB Network Management SYSTEMS          |
//           |                                               |
//           |               All rights reserved             |
//           |                                               |
//           +-----------------------------------------------+
//  Java script file for project of replacing java applets with jquery
//  MODIFICATION HISTORY
//  001     27-Aug-2019  AV        B-168141 DMS 9.1.0.X_Ora122Java11 Netcadops Applet replacement with jquery
// -----------------------------------------------------------------------------

var p_session_id;
var p_prev_sess_id;

function saveSessionIds() 
{
    if (p_prev_sess_id !== p_session_id) {
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getSessionId();
    if (!p_prev_sess_id) {
        p_prev_sess_id = p_session_id;
    }
}

function sessionClose() 
{
    popObject = window.createPopup();
    popObject.hide();
    formLogout.submit();
}

function CheckLogin() 
{
    if (top.sessionframe) {
        return false;
    }
    else {
        if (areasSelected == false) {
            sessionClose();
            return true;
        }
        else {
            return false;
        }
    }
}

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all) 
{
    saveSessionIds();

    areasSelected = true;

    var listIDs = "";
    var listNames = "";
    if (all == 0) { // Few areas picked by user
        listIDs = getSelectedIds();
        listNames = getSelectedNames();
        console.log("listIDs = " + listIDs + " listNames = " + listNames);
        if (listIDs == "") {
            alert("listIDs is null. Please select at least one row.");
            return;
        }
    }
    else {  // ALL areas is picked by user
        listIDs = "||";
    }

    var vURL = "OutLstHierarchy.LowestLevelOutages?p_session_id=" + p_session_id + "&p_list=" + listIDs + "&p_page='TREE'";
    document.location.href = vURL;
}

function getSelectedIds() 
{
    var nodes = $("#tree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if (Array.isArray(nodes)) {
        nodes.forEach(function (node) {
            ids.push(node.key);
        });
    }
    return ids.join("|");
}

function getSelectedNames() 
{
    var nodes = $("#tree").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if (Array.isArray(nodes)) {
        nodes.forEach(function (node) {
            ids.push(node.title);  // key is Id, title is name
        });
    }
    return ids.join("|");
}

//-- For execinfo:Area Outages: screen
//
//-- 11/29/02 SQL* Java Script Function to get Outage Number from the list and call ViewLog procedure
//-- 04/10/03 EK   Changed to call log of outage, customer call, non-customer call.
//--               Also use getRows() from applet.js to not repeat the same statements in many places.
//-- Global JavaScript variables to be populated by function getRows() in applet.js
var ridAsString, ridArr = new Array(), pidAsString, pidArr = new Array();

//-- 12/05/02 SQL* : STS_Non Customer Call
//-- Java Script Function to select one outage that will be assigned to one or multiple non-customer calls
//-- 04/10/03 EK Simplified this function
function AssignOutage(p_problem_no, trans907) 
{
	var table = $("#subarea-outage-table").DataTable();
	if (table.rows('.selected').data().length != 1) {
		alert(trans907); // Please select one row
		return false;
	}
	var sessionId = getUrlParameter("p_session_id");
	var outageNo = table.rows('.selected').data()[0][2];
	var vURL = "OutLists.AssignOutage?p_outage_no="+outageNo+"&p_problem_no=" +problemNo  +"&p_session_id="+ sessionId;
	document.location.href = vURL;
}


function reloadIt() 
{
    document.location = document.location;
}

// Function to refresh lists (called from JavaScript functions LibJS.FreezeFun).
function refreshPage(g_refresh)
{
	var g_refresh = parseInt($("#g_refresh").attr("value"));
    if (isNaN(g_refresh) || g_refresh < 1) {
        g_refresh = 5;
    }

    timerID = setTimeout("refreshPage()", g_refresh * 1000);
    timerRunning = true;
    reloadIt();
}

function indusForm(v_verified_pos, v_outage_pos, v_sub_area_pos, trans907, trans245, trans115, trans853) 
{
	var table = $("#subarea-outage-table").DataTable();
	if (table.rows('.selected').data().length != 1) {
		alert(trans907); // Please select one row
		return false;
	}
    var sessionId = getUrlParameter("p_session_id");

    //-- If Verified=Yes and Restored=No then create parameter with
    //-- userID, outage_no, OUTAGE, subareaID, subareaName
    if ((pidArr[v_verified_pos] === trans245) && (pidArr[v_restored_pos] === trans115)) {
        var param = top.sessionframe.userID + "|" + pidArr[v_outage_pos] + "|OUTAGE|" + pidArr[v_sub_area_pos] + "|" + pidArr[pidArr.length - 2];
        var vURL = "NETCINDUSINTERFACE.Wrapper?p_session_id=" + sessionId + "&p_par=" + escape(param);
        popWin(vURL, "netCADOPSpop", 900, 600, "Y", 5, 5, "toolbar=no,location=no,menubar=no,resize=yes,status=no");
    } else {
        alert(trans853); // -- Indus Work Forms are available for verified/non-restored outages only.
        return;
    }
}

function getOutageLog(v_problem_no_pos, v_problem_type_pos, trans907) {
    var vType = "";
	var table = $("#subarea-outage-table").DataTable();
	if (table.rows('.selected').data().length != 1) {
		alert(trans907); // Please select one row
		return false;
	}
    var sessionId = getUrlParameter("p_session_id");

	for (var ii = 0; ii < table.rows('.selected').data().length; ii++) {
		var outageNo = table.rows('.selected').data()[ii][2];
		if (outageNo === "") {
            return false;
		} else {
			vType = "OUTAGE";
			if (table.rows('.selected').data()[ii][v_problem_type_pos] === "Customer Call")
				vType = "CUST";
			if (table.rows('.selected').data()[ii][v_problem_type_pos] === "Non-Customer Call")
				vType = "NONCUST";
		}

		break; // because just only one row is selected always
	}

    var vURL = "NETCOUTAGELOG.Wrapper?p_session_id=" + sessionId + "&p_outage_no=" + outageNo + "&p_type=" + vType;
    popWin(vURL, "netCADOPSpop", 900, 600, "Y", 10, 10, "toolbar=no,location=no,directories=no,status=no,menubar=no");
}

// 06 / 15 / 03 EK  Function to call group / ungroup procedure in package netcGrouping
// Same function in netcHist.
function groupOutage(vAction, trans798, trans808, trans801, trans809, trans802) {
    var vList = ""; var vMasterNo = ""; var vMasterFound = 0; var vMasterIncluded = 0;
    var vOutIndx = " v_OutageOrder ";
    var vMasterOutIndx = " v_MasterOutageOrder ";

	var table = $("#subarea-outage-table").DataTable();
	if (table.rows('.selected').data().length < 1 ) {
        alert('Please select a outage');
        return false; // No outages selected for grouping / ungrouping
	}
	if (table.rows('.selected').data().length < 2 && vAction === "G" ) {
        alert(trans798); // Please select more than one outage for grouping
        return false; // No outages selected for grouping / ungrouping
	}
    var sessionId = getUrlParameter("p_session_id");

	for (var ii = 0; ii < table.rows('.selected').data().length; ii++) {
		var outageNo = table.rows('.selected').data()[ii][2];
		if (outageNo === "") {
            alert(trans797); // Only outages can be grouped
            return false;
		}
        vList = vList + "|" + outageNo;

		var masteroutageNo = table.rows('.selected').data()[ii][3];
        if (masteroutageNo != "") {
            if (masteroutageNo === outageNo)
                vMasterIncluded = 1;

            if (vMasterFound == 0) {
                vMasterNo = masteroutageNo;
                vMasterFound = 1;
            } else {
                if (masteroutageNo != vMasterNo) {
                    alert(tbl808); // Only one master outage may be included
                    return false;
                }
            }
        }
        if (vAction == "U" && masteroutageNo === "") {
            alert(trans802  + outageNo); // Selected outage does not belong to a group
            return false;
        }
	}

    // confirmation to destroy the group
    if (vMasterNo != "" && vAction === "U" && vMasterIncluded === 1) {
        var conf_msg = trans801 + vMasterNo + " ?";  // Do you want to destroy the group for master

        if (!confirm(conf_msg))
            return false;
    }

    if (vAction === "G")
        var vURL = "netcGrouping.GroupOutages?p_session_id=" + sessionId + "&p_list=" + vList + "&p_master_outage_no=" + vMasterNo;
    else
        var vURL = "netcGrouping.UnGroupOutages?p_session_id=" + sessionId + "&p_list="
            + vList + "&p_master_outage_no=" + vMasterNo + "&p_err_msg=" + escape(trans809);

    popWin(vURL, "netCADOPSpop", 850, 600, "Y", 10, 10, "menubar=0,scrollbars=1,titlebar=1,resizable=1");
}


$(document).ready(function () {
    // create  the tree data  structure
    var treeData = parseTreeNodeInfo($('param').attr('VALUE'));

	// In case of execInfo:Area Outages:outage list you do not have tree ob, hence the check
	var sel_ob = $("#tree");
	if (sel_ob.length > 0) { // The selector had not found any element in the html doc matching
		sel_ob.fancytree({
			source: treeData,
			checkbox: true,
			selectMode: 2,
			autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
			activeVisible: false, // Make sure, active nodes are visible (expanded)
			icon: false, // Display node icons
			click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
				if (data.targetType === 'title') {
					data.node.toggleSelected();
				}
			}
		});
	}
});
