function callLog(mesg1) {
    var reportNo;
    var table = $("#trrpts-table").DataTable();
	 	if (table.rows('.selected').data().length == 0)
		{
			alert(mesg1);
          	return false;
        }

        if (table.rows('.selected').data().length>1) 
        {
           alert(mesg1);
           return false;
        }
          for (var i=0; i<table.rows('.selected').data().length; i++) 
		  {
			reportNo = table.rows('.selected').data()[i][1];
          }
          var sessionId = getUrlParameter("p_session_id");		
       var vURL="netcOutageLog.wrapper?p_session_id="+ sessionId +"&p_outage_no="+reportNo+"&p_type=CUST";
       popWin(vURL,"netCADOPSpop",900,600);
       }

function callUpdateXFMR(mesg1,position) {
       var vlist="",acclist="";
       var table = $("#trrpts-table").DataTable();
       if (table.rows('.selected').data().length == 0)
		{
			alert(mesg1);
          	return false;
		  }
       for (var i=0; i<table.rows('.selected').data().length; i++) 
          {
            acclist = table.rows('.selected').data()[i][position+1];
            vlist=vlist + "|" +acclist;
           }
           var sessionId = getUrlParameter("p_session_id");		
       var vURL="netcMgmt.CustomerTransformer?p_session_id="+ sessionId +
                 "&p_account="+vlist;
       document.location.href=vURL;
       }

function showPref() {
    var sessionId = getUrlParameter("p_session_id");		
    var vURL="NetcOptions.CallPrefs?p_session_id="+ sessionId + "&p_content=netcoptions.prefs?P_CAT=NETC.CUST_LISTS%26p_session_id="+ sessionId;
       popWin(vURL,"netCADOPSpop",900,400);
    }
