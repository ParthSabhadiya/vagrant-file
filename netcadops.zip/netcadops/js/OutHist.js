
var areasSelected = false
var v_PrevSessID = null;
var p_session_id;
var p_prev_sess_id;
var v_BeginDate;
var v_EndDate;
var v_rid2 = "";
var v_pref_serv;
var v_pref_refr;
var p_archive;

function getSessionIds(){
    if ( p_prev_sess_id !== p_session_id ){
        p_prev_sess_id = p_session_id;
    }
    p_session_id = getUrlParameter("p_session_id");
    if (!p_prev_sess_id){
        p_prev_sess_id = p_session_id;
    }
}

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

// Called when the form buttons are clicked. Assumes that p_session_id and p_prev_sess_id are defined somewhere in the code.
function formSubmitted(form, all){
    getSessionIds();
    var listIDs = "";
    if ( all == 0 ){
       listIDs = getSelectedIds();
       console.log(listIDs);
    }

    console.log( "listIDs is " + listIDs);

    if (!validateForm(form)) {
        return ;
        }
     else {
         v_BeginDate = form[0].value;
         v_EndDate = form[1].value;
         var vURL = "NetcHist.OutHistDetailTree?p_session_id="+p_session_id+'&p_BeginDate='+v_BeginDate+
                     '&p_EndDate='+v_EndDate+'&p_list='+listIDs+
                     '&p_serv='+form[4].value+ '&p_refr=' + form[5].value +  '&p_archive=' + form[6].value ;
         document.location.href = vURL;
     }
}

function getSelectedIds(){
    var nodes = $("#outhist").fancytree("getTree").getSelectedNodes();
    var ids = [];
    if ( Array.isArray(nodes)){
        nodes.forEach(function(node){
            ids.push(node.key);
        });
    }
    return ids.join("|");
}



function parseNodeOnfo(nodeStr){
    var nodesInfo = nodeStr.split("|");
    var noOfNodes = nodesInfo.length/3;

    var currentParentByLevel = {};
    var data = [];
    for ( var i = 0; i < noOfNodes; i++){
        var level = nodesInfo[3*i];
        var intLevel = parseInt(level.substring(1));
        var id = nodesInfo[3*i+1];
        var name = nodesInfo[3*i+2];
        var node = {
            title: name,
            key: id,
            level: level,
            children: [],
        };
        if ( intLevel <= 2) node.expanded = true;
        currentParentByLevel[intLevel] = node;
        if ( intLevel == 1 ){
            data.push(node);
            node.folder = true;
            //node.icon = "/images/folder.png";
        }
        else {
            var currentParent = currentParentByLevel[intLevel-1];
            if (currentParent){
                currentParent.children.push(node);
                currentParent.folder = true;
                //currentParent.icon = "images/folder.png";
            }
        }
    }
    return data;
}


$(document).ready(function(){
    // create  the tree data  structure
    var treeData = parseNodeOnfo( $('param').attr('value') );
    $("#outhist").fancytree({
        source: treeData,
        checkbox: true,
        selectMode: 2,
       	autoCollapse: false, // Automatically collapse all siblings, when a node is expanded
        activeVisible: false, // Make sure, active nodes are visible (expanded)
        icon: false, // Display node icons
        click: function (event, data) {  // when clicking on title or radio button to select Fancytree node
            if (data.targetType === 'title') {
                data.node.toggleSelected();
            }
        }

    });
});
